# Cloud Functions: ending a pairing

These are 2nd gen functions, written in TypeScript and running on Node 22, in region **`asia-south1`**. When a couple separates, they delete everything the couple shared and unpair both people. Each person's account and `users/{uid}` profile stay, so they can pair again. Auth accounts are never deleted.

| Function | Type | What it does |
|---|---|---|
| `processSeparations` | Scheduled, every 15 min | Ends every couple whose `separation.effectiveAt <= now`, up to 100 per run. `how` is `agreed` if `status == 'agreed'`, otherwise `oneSided`. |
| `finalizeSeparation` | Callable `{coupleId}` | The app calls it when it opens after the separation date. The caller must be a member and the date must have passed. Returns `{status, how}`. |
| `leaveNow` | Callable `{coupleId, confirm: 'LEAVE'}` | A member ends the pairing immediately (`how = 'leftNow'`), whether or not a separation exists. The app gates this behind the app lock or biometrics. |

All three call `endCouple(cid, how)` in `src/endCouple.ts`. It runs these steps in order:

1. **Claim:** writes a lease `ending: {how, startedAt, leaseExpiresAt, attempts}` on the couple doc.
2. **Storage:** deletes everything under `couples/{cid}/`, plus each member's `users/{uid}/backgrounds/`. It keeps `users/{uid}/profile/`.
3. **Subcollections:** deletes every subcollection of the couple doc recursively, including unknown ones.
4. **Invites and pair requests:** deletes `invites` and `pairRequests` docs where `coupleId == cid`.
5. **Users:** for each member, sets `coupleId: null`, deletes `chatLookMode`, `chatLook`, `chatClearedAt` and `mutePartner`, and sets `pairingEndedAt` and `pairingEndedHow`. It only does this if the user doc still points at this couple.
6. **Root doc:** deletes the couple doc last (a recursive delete, so it also catches late writes). A missing couple doc therefore means the job is finished.

Every step is idempotent. If another run holds a live lease, a second caller gets `inProgress`; once the lease expires (10 min, which is longer than any function timeout), the next run takes over and keeps the original `how`.

Callable results: `status` is `ended`, `alreadyEnded` or `inProgress`; `how` is a string or `null`. Errors use these codes: `unauthenticated`, `invalid-argument` (bad `coupleId`, or `confirm` isn't `'LEAVE'`), `permission-denied` (caller isn't a member), and `failed-precondition` (no separation, or "Not yet"; `details.effectiveAt` is an ISO date).

## Build and test

```sh
cd functions
npm install
npm run build          # tsc -> lib/
FIREBASE_BIN=/path/to/firebase npm test   # from functions/: build, then emulators:exec --only firestore,storage
```

The tests in `test/` use mocha and run against the Firestore and Storage emulators. They call `fn.run(request)` with fake auth contexts.

## Deploy (after enabling Blaze)

```sh
firebase deploy --only functions --project together-48033
```

`firebase.json` runs `npm run build` as predeploy, so the build happens first. The scheduler needs **Cloud Scheduler**, which is only available on Blaze; the deploy enables the API and creates the job. The first deploy may also ask to enable Cloud Build, Artifact Registry and Eventarc, and to set an Artifact Registry cleanup policy. Say yes to all of them.

## Cost at this scale (tiny)

- **Cloud Scheduler:** 3 jobs per billing account are free, and this uses 1.
- **Invocations:** about 2,900 scheduled runs a month, plus occasional callable calls. The free tier is 2M invocations a month.
- **Firestore:** each tick runs one query, which costs at least 1 read even with no results, so about 2,900 reads a month. The free tier is 50k reads a day. A separation costs roughly one delete per document the couple had.
- **Storage:** list and delete operations only.
- **Artifact Registry:** a few cents a month for the container images, or less with the cleanup policy.
