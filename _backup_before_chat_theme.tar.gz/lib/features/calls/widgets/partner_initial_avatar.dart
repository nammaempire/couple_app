import 'package:flutter/material.dart';

/// A translucent rose circle with the first letter of [name], used on the
/// call screens in place of a photo.
class PartnerInitialAvatar extends StatelessWidget {
  const PartnerInitialAvatar({
    super.key,
    required this.name,
    required this.size,
    required this.fontSize,
  });

  final String name;
  final double size;
  final double fontSize;

  @override
  Widget build(BuildContext context) {
    final initial = name.isEmpty ? '?' : name.characters.first.toUpperCase();

    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: const Color(0xFFE05C7B).withValues(alpha: .25),
      ),
      child: Center(
        child: Text(
          initial,
          style: TextStyle(
            color: Colors.white,
            fontSize: fontSize,
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
    );
  }
}
