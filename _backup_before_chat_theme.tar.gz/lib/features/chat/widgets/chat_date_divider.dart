import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

/// "Today" or the date, between messages sent on different days.
class ChatDateDivider extends StatelessWidget {
  const ChatDateDivider({super.key, required this.date});

  final DateTime? date;

  @override
  Widget build(BuildContext context) {
    if (date == null) return const SizedBox.shrink();

    final now = DateTime.now();
    final isToday =
        date!.year == now.year &&
        date!.month == now.month &&
        date!.day == now.day;
    final label = isToday ? 'Today' : DateFormat.yMMMd().format(date!);

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 12),
      child: Text(
        label,
        style: Theme.of(context).textTheme.labelSmall?.copyWith(
          color: Theme.of(context).colorScheme.onSurfaceVariant,
        ),
      ),
    );
  }
}
