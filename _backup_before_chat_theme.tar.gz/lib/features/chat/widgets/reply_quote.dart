import 'package:flutter/material.dart';

import 'package:couple_app/features/chat/models/message.dart';

/// The quoted message at the top of a reply.
class ReplyQuote extends StatelessWidget {
  const ReplyQuote({
    super.key,
    required this.reply,
    required this.label,
    required this.onMine,
    this.onTap,
  });

  final ReplyPreview reply;
  final String label;

  /// Drawn inside one of my (coloured) bubbles.
  final bool onMine;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final accent = onMine
        ? theme.colorScheme.onPrimary
        : theme.colorScheme.primary;
    final textColor = onMine
        ? theme.colorScheme.onPrimary.withValues(alpha: .85)
        : theme.colorScheme.onSurfaceVariant;

    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.fromLTRB(10, 6, 10, 6),
        decoration: BoxDecoration(
          color: onMine
              ? Colors.black.withValues(alpha: .12)
              : theme.colorScheme.primary.withValues(alpha: .08),
          borderRadius: BorderRadius.circular(10),
          border: Border(left: BorderSide(color: accent, width: 3)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              label,
              style: theme.textTheme.labelMedium?.copyWith(
                color: accent,
                fontWeight: FontWeight.w700,
              ),
            ),
            Text(
              reply.text.isEmpty ? 'Message' : reply.text,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: theme.textTheme.bodySmall?.copyWith(color: textColor),
            ),
          ],
        ),
      ),
    );
  }
}
