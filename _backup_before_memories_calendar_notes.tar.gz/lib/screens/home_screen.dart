import 'package:flutter/material.dart';

import '../models/app_user.dart';
import '../models/call_session.dart';
import '../models/couple.dart';
import '../models/daily_question.dart';
import '../models/important_date.dart';
import '../models/mood.dart';
import '../services/call_launcher.dart';
import '../services/call_service.dart';
import '../services/couple_service.dart';
import '../services/daily_question_service.dart';
import '../services/mood_service.dart';
import '../services/nudge_service.dart';
import '../widgets/daily_question_card.dart';
import '../widgets/home/coming_up_card.dart';
import '../widgets/home/couple_header.dart';
import '../widgets/home/love_taps_card.dart';
import '../widgets/home/quick_actions.dart';
import '../widgets/mood_card.dart';
import '../widgets/together_counter.dart';

/// The emotional centre of the app: who you are together, what is coming
/// up, how you are both doing, and one-tap ways to reach each other.
class HomeScreen extends StatefulWidget {
  const HomeScreen({
    super.key,
    required this.me,
    required this.couple,
    required this.partnerName,
    required this.coupleService,
    required this.moodService,
    required this.questionService,
    required this.nudgeService,
    this.partner,
    this.callService,
    this.onOpenChat,
    this.onOpenUs,
  });

  final AppUser me;
  final Couple couple;
  final String partnerName;

  /// The partner's live profile, for their photo and birthday.
  final AppUser? partner;

  final CoupleService coupleService;
  final MoodService moodService;
  final DailyQuestionService questionService;
  final NudgeService nudgeService;
  final CallService? callService;

  /// Switch to the Chat tab.
  final VoidCallback? onOpenChat;

  /// Switch to the Us tab, where dates are set.
  final VoidCallback? onOpenUs;

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  // Created once: the couple document updates on every message, and
  // recreating these would resubscribe each time.
  late final Stream<Map<String, MoodEntry>> _moods =
      widget.moodService.watchMoods(widget.couple.id);
  late final Stream<DailyQuestionEntry> _today =
      widget.questionService.watchToday(widget.couple.id);
  late final Stream<List<DailyQuestionEntry>> _history =
      widget.questionService.watchHistory(widget.couple.id);

  Couple get couple => widget.couple;
  String? get _partnerUid => couple.partnerIdFor(widget.me.uid);

  Future<void> _pickStartDate() async {
    final now = DateTime.now();
    final picked = await showDatePicker(
      context: context,
      initialDate: couple.startDate ?? now,
      firstDate: DateTime(1970),
      lastDate: now,
      helpText: 'When did you two start?',
    );
    if (picked == null) return;
    await widget.coupleService.setStartDate(coupleId: couple.id, date: picked);
  }

  Future<void> _sendLove(LoveTap tap) {
    return widget.nudgeService.send(
      coupleId: couple.id,
      senderId: widget.me.uid,
      kind: tap,
    );
  }

  void _call(CallType type) {
    placeCall(
      context,
      coupleId: couple.id,
      myUid: widget.me.uid,
      partnerUid: _partnerUid,
      partnerName: widget.partnerName,
      type: type,
      callService: widget.callService,
    );
  }

  @override
  Widget build(BuildContext context) {
    final partnerUid = _partnerUid;
    final paired = couple.isComplete;
    final dates = ImportantDate.upcoming(
      couple: couple,
      me: widget.me,
      partner: widget.partner,
      partnerName: widget.partnerName,
    );

    return Scaffold(
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 20, 16, 32),
          children: [
            CoupleHeader(
              greeting: _greeting(),
              subtitle: couple.coupleName ?? 'You and ${widget.partnerName}',
              myName: widget.me.displayName,
              partnerName: widget.partnerName,
              myPhotoUrl: widget.me.photoUrl,
              partnerPhotoUrl: widget.partner?.photoUrl,
              couplePhotoUrl: couple.photoUrl,
            ),
            const SizedBox(height: 16),

            QuickActions(
              actions: [
                QuickAction(
                  icon: Icons.chat_bubble_outline,
                  label: 'Message',
                  onPressed: widget.onOpenChat,
                ),
                QuickAction(
                  icon: Icons.call_outlined,
                  label: 'Call',
                  onPressed: paired ? () => _call(CallType.voice) : null,
                ),
                QuickAction(
                  icon: Icons.videocam_outlined,
                  label: 'Video',
                  onPressed: paired ? () => _call(CallType.video) : null,
                ),
                QuickAction(
                  icon: Icons.event_outlined,
                  label: 'Dates',
                  onPressed: widget.onOpenUs,
                ),
              ],
            ),
            const SizedBox(height: 16),

            TogetherCounter(
              couple: couple,
              onSetStartDate: _pickStartDate,
            ),
            const SizedBox(height: 16),

            LoveTapsCard(
              partnerName: widget.partnerName,
              enabled: paired,
              onSend: _sendLove,
            ),
            const SizedBox(height: 16),

            ComingUpCard(
              dates: dates,
              onAddDates: widget.onOpenUs ?? () {},
            ),
            const SizedBox(height: 16),

            StreamBuilder<Map<String, MoodEntry>>(
              stream: _moods,
              builder: (context, snapshot) {
                return MoodCard(
                  myUid: widget.me.uid,
                  partnerUid: partnerUid,
                  partnerName: widget.partnerName,
                  moods: snapshot.data ?? const {},
                  onPick: (mood, note) => widget.moodService.setMood(
                    coupleId: couple.id,
                    uid: widget.me.uid,
                    mood: mood,
                    note: note,
                  ),
                );
              },
            ),
            const SizedBox(height: 16),

            StreamBuilder<List<DailyQuestionEntry>>(
              stream: _history,
              builder: (context, historySnap) {
                final streak = QuestionBank.streak(
                  (historySnap.data ?? const []).map((e) => e.dateKey),
                  DateTime.now(),
                );
                return StreamBuilder<DailyQuestionEntry>(
                  stream: _today,
                  builder: (context, snapshot) {
                    final entry = snapshot.data ??
                        DailyQuestionEntry(
                          dateKey: QuestionBank.dateKeyFor(DateTime.now()),
                          prompt: QuestionBank.promptFor(
                            DateTime.now(),
                            couple.id,
                          ),
                        );
                    return DailyQuestionCard(
                      entry: entry,
                      myUid: widget.me.uid,
                      partnerUid: partnerUid,
                      partnerName: widget.partnerName,
                      streak: streak,
                      onAnswer: (text) => widget.questionService.answer(
                        coupleId: couple.id,
                        uid: widget.me.uid,
                        text: text,
                      ),
                    );
                  },
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  String _greeting() {
    final hour = DateTime.now().hour;
    final name = widget.me.nickname ?? widget.me.displayName;
    final base = hour < 12
        ? 'Good morning'
        : hour < 17
            ? 'Good afternoon'
            : hour < 21
                ? 'Good evening'
                : 'Still up';
    return hour < 21 ? '$base, $name' : '$base, $name?';
  }
}
