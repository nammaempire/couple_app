import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'package:couple_app/features/auth/providers/auth_providers.dart';
import 'package:couple_app/features/music/data/music_service.dart';
import 'package:couple_app/features/music/data/song_link_launcher.dart';
import 'package:couple_app/features/music/data/song_metadata_service.dart';
import 'package:couple_app/features/music/data/song_player.dart';
import 'package:couple_app/features/music/data/youtube_song_player.dart';
import 'package:couple_app/features/music/models/listening_session.dart';
import 'package:couple_app/features/music/models/song.dart';

final musicServiceProvider = Provider<MusicService>((ref) => MusicService());

final songMetadataServiceProvider = Provider<SongMetadataService>((ref) {
  final service = SongMetadataService();
  ref.onDispose(service.close);
  return service;
});

/// Every saved song, unsorted. Filter and sort with `SongLists`. After an
/// error the last good list is kept in `.value`.
final songsProvider = StreamProvider.autoDispose<List<Song>>(
  (ref) => ref
      .watch(musicServiceProvider)
      .watchSongs(ref.watch(currentCoupleIdProvider)),
);

/// The couple's listening session, or null if there has never been one.
/// The shell's banner watches it, so it stays subscribed while signed in.
final listeningSessionProvider = StreamProvider.autoDispose<ListeningSession?>(
  (ref) => ref
      .watch(musicServiceProvider)
      .watchSession(ref.watch(currentCoupleIdProvider)),
);

/// The live session (playing, paused or counting down), or null. A session
/// someone left running long ago with nobody listening counts as over
/// (see [ListeningSession.isStale]); this is checked whenever the session
/// changes or the provider is read again, which is often enough.
final liveSessionProvider = Provider.autoDispose<ListeningSession?>((ref) {
  final session = ref.watch(listeningSessionProvider).value;
  if (session == null) return null;
  final now = ref.watch(musicServiceProvider).clock.nowMs();
  return session.isActive(now) ? session : null;
});

/// Makes the in-app (YouTube) player. Tests and screenshots override it
/// with a fake that needs no web view.
final songPlayerFactoryProvider = Provider<SongPlayerFactory>(
  (ref) => YoutubeSongPlayer.new,
);

/// Opens song links in their own apps. Tests override it to record calls.
final songLinkLauncherProvider = Provider<SongLinkLauncher>(
  (ref) => launchSongLink,
);

/// Remembers which session start ("coupleId:version") already opened its
/// external app on this phone, so closing and reopening the player during
/// the same song doesn't open Spotify a second time.
class LaunchedSessionNotifier extends Notifier<String?> {
  @override
  String? build() => null;

  void mark(String key) => state = key;
}

final launchedSessionProvider =
    NotifierProvider<LaunchedSessionNotifier, String?>(
      LaunchedSessionNotifier.new,
    );
