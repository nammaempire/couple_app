import 'dart:async';

import 'package:flutter/material.dart';

import 'package:couple_app/features/music/data/media_shelf.dart';
import 'package:couple_app/features/music/data/server_clock.dart';
import 'package:couple_app/features/music/models/listening_session.dart';
import 'package:couple_app/features/music/widgets/song_artwork.dart';

/// "Starting…", "Playing" or "Paused".
String listeningStatusLabel(ListeningSession s, int nowMs) =>
    switch (s.status) {
      ListeningStatus.countdown when !s.countdownDone(nowMs) => 'Starting…',
      ListeningStatus.countdown || ListeningStatus.playing => 'Playing',
      ListeningStatus.paused => 'Paused',
      ListeningStatus.ended => 'Ended',
    };

/// The live session at the top of the library, with a way back in.
///
/// Ticks once a second while counting down, so "Starting…" turns into
/// "Playing" on time.
class ListeningNowCard extends StatefulWidget {
  const ListeningNowCard({
    super.key,
    required this.session,
    required this.clock,
    required this.partnerUid,
    required this.partnerName,
    required this.onOpen,
    this.shelf = MediaShelf.songs,
  });

  final ListeningSession session;
  final ServerClock clock;
  final MediaShelf shelf;
  final String? partnerUid;
  final String partnerName;
  final VoidCallback onOpen;

  @override
  State<ListeningNowCard> createState() => _ListeningNowCardState();
}

class _ListeningNowCardState extends State<ListeningNowCard> {
  Timer? _ticker;

  @override
  void initState() {
    super.initState();
    _updateTicker();
  }

  @override
  void didUpdateWidget(ListeningNowCard oldWidget) {
    super.didUpdateWidget(oldWidget);
    _updateTicker();
  }

  @override
  void dispose() {
    _ticker?.cancel();
    super.dispose();
  }

  bool get _counting {
    final s = widget.session;
    return s.status == ListeningStatus.countdown &&
        !s.countdownDone(widget.clock.nowMs());
  }

  void _updateTicker() {
    if (!_counting) {
      _ticker?.cancel();
      _ticker = null;
      return;
    }
    _ticker ??= Timer.periodic(const Duration(seconds: 1), (_) {
      if (!mounted) return;
      setState(() {});
      if (!_counting) {
        _ticker?.cancel();
        _ticker = null;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;
    final session = widget.session;
    final nowMs = widget.clock.nowMs();
    final partnerUid = widget.partnerUid;
    final partnerName = widget.partnerName;
    final partnerListening =
        partnerUid != null && session.isListening(partnerUid, nowMs);
    final who = partnerListening
        ? '$partnerName is ${widget.shelf.doing}'
        : '$partnerName isn’t ${widget.shelf.doing} yet';

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 12),
      child: Material(
        clipBehavior: Clip.antiAlias,
        borderRadius: BorderRadius.circular(22),
        child: Ink(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [scheme.primaryContainer, scheme.tertiaryContainer],
            ),
          ),
          child: InkWell(
            onTap: widget.onOpen,
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Row(
                children: [
                  SongArtwork(
                    url: session.thumbnailUrl,
                    source: session.source,
                    size: 56,
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          widget.shelf.togetherTitle,
                          style: theme.textTheme.labelMedium?.copyWith(
                            color: scheme.primary,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        Text(
                          session.displayTitle,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: theme.textTheme.titleMedium?.copyWith(
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        Text(
                          '${listeningStatusLabel(session, nowMs)} · $who',
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                          style: theme.textTheme.bodySmall?.copyWith(
                            color: scheme.onSurfaceVariant,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(width: 8),
                  FilledButton(
                    onPressed: widget.onOpen,
                    style: FilledButton.styleFrom(
                      minimumSize: const Size(72, 40),
                    ),
                    child: Text(partnerListening ? 'Join' : 'Open'),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
