import 'dart:io';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';

import '../models/app_user.dart';
import '../models/invite.dart';
import '../services/auth_service.dart';
import '../services/couple_service.dart';
import '../services/storage_service.dart';
import '../widgets/onboarding_progress.dart';
import '../widgets/photo_picker_avatar.dart';
import 'onboarding/qr_scan_screen.dart';

enum _Mode { choose, create, join, confirm }

/// Onboarding step 2: create a couple space, or join one with an invite.
///
/// All sub-steps live in this one widget rather than as pushed routes, so
/// when pairing succeeds and [AuthGate] swaps screens there is no stale route
/// left on the navigator.
class PairingScreen extends StatefulWidget {
  const PairingScreen({
    super.key,
    required this.authService,
    required this.uid,
    this.me,
    this.notice,
    this.coupleService,
    this.storageService,
  });

  final AuthService authService;
  final String uid;

  /// This user's profile, used to label the invite with their name.
  final AppUser? me;

  /// Optional message shown at the top, e.g. when a previous space is gone.
  final String? notice;

  final CoupleService? coupleService;
  final StorageService? storageService;

  @override
  State<PairingScreen> createState() => _PairingScreenState();
}

class _PairingScreenState extends State<PairingScreen> {
  late final CoupleService _couples =
      widget.coupleService ?? CoupleService();
  late final StorageService _storage =
      widget.storageService ?? StorageService();

  _Mode _mode = _Mode.choose;

  // Create
  final _coupleName = TextEditingController();
  DateTime? _startDate;
  File? _couplePhoto;

  // Join
  final _code = TextEditingController();
  Invite? _invite;

  bool _busy = false;
  String? _error;

  @override
  void dispose() {
    _coupleName.dispose();
    _code.dispose();
    super.dispose();
  }

  void _go(_Mode mode) {
    setState(() {
      _mode = mode;
      _error = null;
    });
  }

  Future<void> _run(Future<void> Function() action, String fallback) async {
    setState(() {
      _busy = true;
      _error = null;
    });
    try {
      await action();
    } on PairingException catch (e) {
      if (mounted) setState(() => _error = e.message);
    } catch (_) {
      if (mounted) setState(() => _error = fallback);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> _create() => _run(() async {
        final couple = await _couples.createCouple(
          widget.uid,
          inviterName: widget.me?.displayName ?? 'Your partner',
          inviterPhotoUrl: widget.me?.photoUrl,
          coupleName: _coupleName.text,
          startDate: _startDate,
        );

        // AuthGate moves to the invite screen as soon as `coupleId` lands, so
        // the photo finishes uploading in the background.
        final photo = _couplePhoto;
        if (photo != null) {
          _storage
              .uploadCouplePhoto(coupleId: couple.id, file: photo)
              .then((url) =>
                  _couples.setCouplePhoto(coupleId: couple.id, photoUrl: url))
              .catchError((_) {});
        }
      }, 'Could not create your space. Try again.');

  Future<void> _findInvite() async {
    final code = InviteCode.extract(_code.text);
    if (code == null) {
      setState(() => _error = 'Enter the 6-character code your partner sent.');
      return;
    }
    await _run(() async {
      final invite = await _couples.lookupInvite(uid: widget.uid, code: code);
      if (!mounted) return;
      setState(() {
        _invite = invite;
        _mode = _Mode.confirm;
      });
    }, 'Could not check that code. Check your connection and try again.');
  }

  Future<void> _scan() async {
    final code = await Navigator.of(context).push<String>(
      MaterialPageRoute(builder: (_) => const QrScanScreen()),
    );
    if (code == null || !mounted) return;
    _code.text = code;
    await _findInvite();
  }

  Future<void> _accept() => _run(
        () => _couples.acceptInvite(uid: widget.uid, invite: _invite!),
        'Could not connect. Try again.',
      );

  Future<void> _pickStartDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _startDate ?? DateTime.now(),
      firstDate: DateTime(1970),
      lastDate: DateTime.now(),
      helpText: 'When did you two start?',
    );
    if (picked != null) setState(() => _startDate = picked);
  }

  @override
  Widget build(BuildContext context) {
    final canGoBack = _mode != _Mode.choose;

    return PopScope(
      canPop: !canGoBack,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop && !_busy) {
          _go(_mode == _Mode.confirm ? _Mode.join : _Mode.choose);
        }
      },
      child: Scaffold(
        appBar: AppBar(
          automaticallyImplyLeading: false,
          leading: canGoBack
              ? BackButton(
                  onPressed: _busy
                      ? null
                      : () => _go(
                            _mode == _Mode.confirm ? _Mode.join : _Mode.choose,
                          ),
                )
              : null,
          title: Text(switch (_mode) {
            _Mode.choose => 'Connect',
            _Mode.create => 'Create your space',
            _Mode.join => 'Join your partner',
            _Mode.confirm => 'Accept invite',
          }),
          actions: [
            if (!canGoBack)
              TextButton(
                onPressed: _busy ? null : widget.authService.signOut,
                child: const Text('Sign out'),
              ),
          ],
        ),
        body: SafeArea(
          child: Align(
            alignment: Alignment.topCenter,
            child: SingleChildScrollView(
              padding: const EdgeInsets.fromLTRB(24, 8, 24, 32),
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 440),
                child: AnimatedSwitcher(
                  duration: const Duration(milliseconds: 220),
                  child: KeyedSubtree(
                    key: ValueKey(_mode),
                    child: switch (_mode) {
                      _Mode.choose => _buildChoose(context),
                      _Mode.create => _buildCreate(context),
                      _Mode.join => _buildJoin(context),
                      _Mode.confirm => _buildConfirm(context),
                    },
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _errorText(BuildContext context) {
    if (_error == null) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.only(top: 16),
      child: Text(
        _error!,
        textAlign: TextAlign.center,
        style: TextStyle(color: Theme.of(context).colorScheme.error),
      ),
    );
  }

  Widget _busyOr(String label) => _busy
      ? const SizedBox(
          width: 20,
          height: 20,
          child: CircularProgressIndicator(strokeWidth: 2),
        )
      : Text(label);

  // ---- Choose ------------------------------------------------------------

  Widget _buildChoose(BuildContext context) {
    final theme = Theme.of(context);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        const OnboardingProgress(step: OnboardingStep.space),
        if (widget.notice != null) ...[
          const SizedBox(height: 16),
          _Notice(text: widget.notice!),
        ],
        const SizedBox(height: 28),
        Text(
          'Connect with your partner',
          style: theme.textTheme.headlineSmall
              ?.copyWith(fontWeight: FontWeight.w600),
        ),
        const SizedBox(height: 6),
        Text(
          'One of you creates your shared space. The other joins with the invite.',
          style: theme.textTheme.bodyMedium?.copyWith(
            color: theme.colorScheme.onSurfaceVariant,
          ),
        ),
        const SizedBox(height: 24),
        _ChoiceCard(
          icon: Icons.favorite_outline,
          title: 'Create our space',
          body: 'Set it up and get an invite to send your partner.',
          onTap: () => _go(_Mode.create),
        ),
        const SizedBox(height: 12),
        _ChoiceCard(
          icon: Icons.qr_code_scanner,
          title: 'I have an invite',
          body: 'Enter or scan the code your partner shared.',
          onTap: () => _go(_Mode.join),
        ),
        const SizedBox(height: 24),
        const _HowItWorks(),
      ],
    );
  }

  // ---- Create ------------------------------------------------------------

  Widget _buildCreate(BuildContext context) {
    final theme = Theme.of(context);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        const OnboardingProgress(step: OnboardingStep.space),
        const SizedBox(height: 28),
        Center(
          child: PhotoPickerAvatar(
            file: _couplePhoto,
            icon: Icons.favorite_outline,
            label: 'Add a couple photo',
            onPicked: (file) => setState(() => _couplePhoto = file),
          ),
        ),
        const SizedBox(height: 10),
        Text(
          'A couple photo (optional)',
          textAlign: TextAlign.center,
          style: theme.textTheme.bodySmall?.copyWith(
            color: theme.colorScheme.onSurfaceVariant,
          ),
        ),
        const SizedBox(height: 24),
        TextField(
          controller: _coupleName,
          textCapitalization: TextCapitalization.words,
          maxLength: 24,
          decoration: const InputDecoration(
            labelText: 'Name your space (optional)',
            hintText: 'e.g. Sam & Alex',
            prefixIcon: Icon(Icons.edit_outlined),
            counterText: '',
          ),
        ),
        const SizedBox(height: 12),
        InkWell(
          onTap: _busy ? null : _pickStartDate,
          borderRadius: BorderRadius.circular(24),
          child: InputDecorator(
            decoration: const InputDecoration(
              labelText: 'When did you two start?',
              prefixIcon: Icon(Icons.calendar_today_outlined),
            ),
            child: Text(
              _startDate == null
                  ? 'Pick your date (optional)'
                  : DateFormat.yMMMMd().format(_startDate!),
              style: theme.textTheme.bodyLarge?.copyWith(
                color: _startDate == null
                    ? theme.colorScheme.onSurfaceVariant
                    : null,
              ),
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 6, 16, 0),
          child: Text(
            'Starts your days-together counter. You can change it later.',
            style: theme.textTheme.bodySmall?.copyWith(
              color: theme.colorScheme.onSurfaceVariant,
            ),
          ),
        ),
        _errorText(context),
        const SizedBox(height: 28),
        FilledButton(
          onPressed: _busy ? null : _create,
          child: _busyOr('Create and get invite'),
        ),
      ],
    );
  }

  // ---- Join --------------------------------------------------------------

  Widget _buildJoin(BuildContext context) {
    final theme = Theme.of(context);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        const OnboardingProgress(step: OnboardingStep.space),
        const SizedBox(height: 28),
        Text(
          'Enter the invite code',
          style: theme.textTheme.titleLarge
              ?.copyWith(fontWeight: FontWeight.w600),
        ),
        const SizedBox(height: 6),
        Text(
          'Your partner can find it on their invite screen.',
          style: theme.textTheme.bodyMedium?.copyWith(
            color: theme.colorScheme.onSurfaceVariant,
          ),
        ),
        const SizedBox(height: 24),
        TextField(
          controller: _code,
          autofocus: true,
          textCapitalization: TextCapitalization.characters,
          textAlign: TextAlign.center,
          maxLength: InviteCode.length,
          style: const TextStyle(
            fontSize: 26,
            letterSpacing: 10,
            fontWeight: FontWeight.w700,
          ),
          decoration: const InputDecoration(
            hintText: 'HJK456',
            counterText: '',
          ),
          inputFormatters: [
            FilteringTextInputFormatter.allow(RegExp('[A-Za-z0-9]')),
            UpperCaseFormatter(),
          ],
          onSubmitted: (_) => _findInvite(),
        ),
        _errorText(context),
        const SizedBox(height: 20),
        FilledButton(
          onPressed: _busy ? null : _findInvite,
          child: _busyOr('Continue'),
        ),
        const SizedBox(height: 12),
        OutlinedButton.icon(
          onPressed: _busy ? null : _scan,
          style: OutlinedButton.styleFrom(
            minimumSize: const Size.fromHeight(52),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16),
            ),
          ),
          icon: const Icon(Icons.qr_code_scanner),
          label: const Text('Scan their QR code'),
        ),
      ],
    );
  }

  // ---- Confirm -----------------------------------------------------------

  Widget _buildConfirm(BuildContext context) {
    final theme = Theme.of(context);
    final invite = _invite!;
    final photo = invite.inviterPhotoUrl;
    final initial = invite.inviterName.isEmpty
        ? '?'
        : invite.inviterName.characters.first.toUpperCase();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        const OnboardingProgress(step: OnboardingStep.space),
        const SizedBox(height: 32),
        Center(
          child: CircleAvatar(
            radius: 48,
            backgroundColor: theme.colorScheme.primaryContainer,
            backgroundImage: photo == null
                ? null
                : CachedNetworkImageProvider(photo),
            child: photo == null
                ? Text(
                    initial,
                    style: theme.textTheme.headlineMedium?.copyWith(
                      color: theme.colorScheme.onPrimaryContainer,
                    ),
                  )
                : null,
          ),
        ),
        const SizedBox(height: 18),
        Text(
          '${invite.inviterName} invited you',
          textAlign: TextAlign.center,
          style: theme.textTheme.headlineSmall
              ?.copyWith(fontWeight: FontWeight.w600),
        ),
        if (invite.coupleName != null) ...[
          const SizedBox(height: 4),
          Text(
            'to join “${invite.coupleName}”',
            textAlign: TextAlign.center,
            style: theme.textTheme.bodyLarge?.copyWith(
              color: theme.colorScheme.onSurfaceVariant,
            ),
          ),
        ],
        const SizedBox(height: 24),
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: theme.colorScheme.surfaceContainerHighest
                .withValues(alpha: .5),
            borderRadius: BorderRadius.circular(18),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'When you accept',
                style: theme.textTheme.titleSmall
                    ?.copyWith(fontWeight: FontWeight.w600),
              ),
              const SizedBox(height: 10),
              _Bullet('You and ${invite.inviterName} share one private space.'),
              const _Bullet('Only the two of you can see what is shared in it.'),
              const _Bullet(
                'The invite closes, so nobody else can join with this code.',
              ),
            ],
          ),
        ),
        _errorText(context),
        const SizedBox(height: 24),
        FilledButton(
          onPressed: _busy ? null : _accept,
          child: _busyOr('Accept and connect'),
        ),
        const SizedBox(height: 8),
        TextButton(
          onPressed: _busy ? null : () => _go(_Mode.join),
          child: const Text('Not them? Use another code'),
        ),
      ],
    );
  }
}

class _ChoiceCard extends StatelessWidget {
  const _ChoiceCard({
    required this.icon,
    required this.title,
    required this.body,
    required this.onTap,
  });

  final IconData icon;
  final String title;
  final String body;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Material(
      color: theme.colorScheme.primaryContainer.withValues(alpha: .55),
      borderRadius: BorderRadius.circular(22),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(22),
        child: Padding(
          padding: const EdgeInsets.all(18),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: theme.colorScheme.surface,
                  shape: BoxShape.circle,
                ),
                child: Icon(icon, color: theme.colorScheme.primary),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: theme.textTheme.titleMedium
                          ?.copyWith(fontWeight: FontWeight.w600),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      body,
                      style: theme.textTheme.bodySmall?.copyWith(
                        color: theme.colorScheme.onSurfaceVariant,
                      ),
                    ),
                  ],
                ),
              ),
              Icon(
                Icons.chevron_right,
                color: theme.colorScheme.onSurfaceVariant,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// Plain-language explanation of what a couple connection means.
class _HowItWorks extends StatelessWidget {
  const _HowItWorks();

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Theme(
      data: theme.copyWith(dividerColor: Colors.transparent),
      child: ExpansionTile(
        tilePadding: EdgeInsets.zero,
        leading: Icon(Icons.info_outline, color: theme.colorScheme.primary),
        title: Text(
          'How connecting works',
          style: theme.textTheme.titleSmall,
        ),
        childrenPadding: const EdgeInsets.only(bottom: 8),
        children: const [
          _Bullet('A space is made for exactly two people.'),
          _Bullet('You can be connected to one partner at a time.'),
          _Bullet('Each invite code works once. After your partner joins, it '
              'stops working.'),
          _Bullet('Chats, photos, moods and answers are visible only to the '
              'two of you.'),
        ],
      ),
    );
  }
}

class _Bullet extends StatelessWidget {
  const _Bullet(this.text);

  final String text;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.only(top: 3, right: 10),
            child: Icon(
              Icons.check_circle,
              size: 16,
              color: theme.colorScheme.primary,
            ),
          ),
          Expanded(child: Text(text, style: theme.textTheme.bodyMedium)),
        ],
      ),
    );
  }
}

class _Notice extends StatelessWidget {
  const _Notice({required this.text});

  final String text;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: theme.colorScheme.tertiaryContainer,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Text(
        text,
        style: theme.textTheme.bodyMedium?.copyWith(
          color: theme.colorScheme.onTertiaryContainer,
        ),
      ),
    );
  }
}

/// Forces invite-code input to uppercase as the user types.
class UpperCaseFormatter extends TextInputFormatter {
  @override
  TextEditingValue formatEditUpdate(
    TextEditingValue oldValue,
    TextEditingValue newValue,
  ) {
    return newValue.copyWith(text: newValue.text.toUpperCase());
  }
}
