import 'package:flutter/material.dart';

import 'package:couple_app/features/auth/models/app_user.dart';
import 'package:couple_app/features/avatar/widgets/profile_avatar.dart';

/// Full-screen "Us is locked" page with an Unlock button.
///
/// Drawn above the navigator, so it uses no tooltips or other widgets that
/// need an [Overlay].
class AppLockScreen extends StatelessWidget {
  const AppLockScreen({
    super.key,
    this.me,
    this.partner,
    required this.authenticating,
    required this.failed,
    required this.onUnlock,
  });

  /// The couple, for their pictures. Without both, the app's heart shows
  /// instead.
  final AppUser? me;
  final AppUser? partner;

  /// The system prompt is up; the button waits.
  final bool authenticating;

  /// The last attempt failed or was cancelled.
  final bool failed;

  final VoidCallback onUnlock;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;
    final me = this.me;
    final partner = this.partner;

    return Material(
      color: theme.scaffoldBackgroundColor,
      child: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(32),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 360),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  if (me != null && partner != null)
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        ProfileAvatar(user: me, size: 64),
                        Padding(
                          padding: const EdgeInsets.symmetric(horizontal: 12),
                          child: Icon(
                            Icons.favorite,
                            size: 24,
                            color: scheme.primary,
                          ),
                        ),
                        ProfileAvatar(user: partner, size: 64),
                      ],
                    )
                  else
                    Icon(Icons.favorite, size: 56, color: scheme.primary),
                  const SizedBox(height: 28),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.lock_outline, size: 20, color: scheme.primary),
                      const SizedBox(width: 8),
                      Text('Us is locked', style: theme.textTheme.titleLarge),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Use your fingerprint, face or phone PIN to open it.',
                    textAlign: TextAlign.center,
                    style: theme.textTheme.bodyMedium?.copyWith(
                      color: scheme.onSurfaceVariant,
                    ),
                  ),
                  if (failed) ...[
                    const SizedBox(height: 16),
                    Text(
                      'That didn\'t work. Try again.',
                      textAlign: TextAlign.center,
                      style: theme.textTheme.bodyMedium?.copyWith(
                        color: scheme.error,
                      ),
                    ),
                  ],
                  const SizedBox(height: 32),
                  FilledButton.icon(
                    onPressed: authenticating ? null : onUnlock,
                    icon: const Icon(Icons.fingerprint),
                    label: const Text('Unlock'),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
