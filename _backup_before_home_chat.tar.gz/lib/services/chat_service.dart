import 'dart:io';
import 'dart:ui' as ui;

import 'package:cloud_firestore/cloud_firestore.dart';

import '../models/message.dart';
import 'storage_service.dart';

/// Reads and writes messages in `couples/{coupleId}/messages`.
class ChatService {
  ChatService({FirebaseFirestore? firestore, StorageService? storage})
      : _db = firestore ?? FirebaseFirestore.instance,
        _storage = storage ?? StorageService();

  final FirebaseFirestore _db;
  final StorageService _storage;

  CollectionReference<Map<String, dynamic>> _messages(String coupleId) =>
      _db.collection('couples').doc(coupleId).collection('messages');

  /// Newest messages first, capped at [limit].
  Stream<List<Message>> watchMessages(String coupleId, {int limit = 100}) {
    return _messages(coupleId)
        .orderBy('sentAt', descending: true)
        .limit(limit)
        .snapshots()
        .map((snap) => snap.docs.map(Message.fromDoc).toList());
  }

  Future<void> sendText({
    required String coupleId,
    required String senderId,
    required String text,
  }) async {
    final trimmed = text.trim();
    if (trimmed.isEmpty) return;

    final message = Message(
      id: '',
      senderId: senderId,
      type: MessageType.text,
      text: trimmed,
    );

    await _messages(coupleId).add(message.toMap());
    await _touchCouple(coupleId, preview: trimmed);
  }

  /// Uploads [file] then writes the image message.
  Future<void> sendImage({
    required String coupleId,
    required String senderId,
    required File file,
    void Function(double progress)? onProgress,
  }) async {
    final aspectRatio = await _aspectRatioOf(file);
    final url = await _storage.uploadChatPhoto(
      coupleId: coupleId,
      file: file,
      onProgress: onProgress,
    );

    final message = Message(
      id: '',
      senderId: senderId,
      type: MessageType.image,
      imageUrl: url,
      imageAspectRatio: aspectRatio,
    );

    await _messages(coupleId).add(message.toMap());
    await _touchCouple(coupleId, preview: 'Photo');
  }

  /// Marks the partner's unread messages as seen.
  Future<void> markSeen({
    required String coupleId,
    required String readerId,
  }) async {
    final unread = await _messages(coupleId)
        .where('seen', isEqualTo: false)
        .limit(200)
        .get();

    final batch = _db.batch();
    var count = 0;
    for (final doc in unread.docs) {
      if (doc.data()['senderId'] == readerId) continue;
      batch.update(doc.reference, {'seen': true});
      count++;
    }
    if (count > 0) await batch.commit();
  }

  /// Adds [emoji] as this user's reaction, or removes it if it is already
  /// their reaction — so tapping the same emoji twice toggles it off.
  Future<void> toggleReaction({
    required String coupleId,
    required Message message,
    required String uid,
    required String emoji,
  }) {
    final alreadySet = message.reactions[uid] == emoji;
    return _messages(coupleId).doc(message.id).update({
      'reactions.$uid': alreadySet ? FieldValue.delete() : emoji,
    });
  }

  Future<void> deleteMessage({
    required String coupleId,
    required Message message,
  }) async {
    await _messages(coupleId).doc(message.id).delete();
    if (message.type == MessageType.image && message.imageUrl != null) {
      try {
        await _storage.deleteByUrl(message.imageUrl!);
      } catch (_) {
        // The document is gone; a leftover blob is not worth failing over.
      }
    }
  }

  Future<void> _touchCouple(String coupleId, {required String preview}) {
    return _db.collection('couples').doc(coupleId).set({
      'lastMessagePreview': preview,
      'lastMessageAt': FieldValue.serverTimestamp(),
    }, SetOptions(merge: true));
  }

  Future<double?> _aspectRatioOf(File file) async {
    try {
      final bytes = await file.readAsBytes();
      final descriptor = await ui.ImageDescriptor.encoded(
        await ui.ImmutableBuffer.fromUint8List(bytes),
      );
      final ratio = descriptor.width / descriptor.height;
      descriptor.dispose();
      return ratio;
    } catch (_) {
      return null;
    }
  }
}
