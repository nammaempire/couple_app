import 'package:cloud_firestore/cloud_firestore.dart';

/// A one-tap "thinking of you" buzz.
class Nudge {
  final String id;
  final String senderId;
  final DateTime? sentAt;

  const Nudge({required this.id, required this.senderId, this.sentAt});

  /// Nudges older than this are treated as history, not a live buzz, so
  /// reopening the app does not replay old ones.
  static const freshWindow = Duration(minutes: 2);

  bool get isFresh {
    final at = sentAt;
    if (at == null) return false;
    return DateTime.now().difference(at) < freshWindow;
  }
}

/// Sends and listens for nudges at `couples/{coupleId}/nudges`.
class NudgeService {
  NudgeService({FirebaseFirestore? firestore})
      : _db = firestore ?? FirebaseFirestore.instance;

  final FirebaseFirestore _db;

  CollectionReference<Map<String, dynamic>> _nudges(String coupleId) =>
      _db.collection('couples').doc(coupleId).collection('nudges');

  Future<void> send({required String coupleId, required String senderId}) {
    return _nudges(coupleId).add({
      'senderId': senderId,
      'sentAt': FieldValue.serverTimestamp(),
    });
  }

  /// The most recent nudge, whoever sent it.
  Stream<Nudge?> watchLatest(String coupleId) {
    return _nudges(coupleId)
        .orderBy('sentAt', descending: true)
        .limit(1)
        .snapshots()
        .map((snap) {
      if (snap.docs.isEmpty) return null;
      final doc = snap.docs.first;
      final data = doc.data();
      return Nudge(
        id: doc.id,
        senderId: (data['senderId'] as String?) ?? '',
        sentAt: (data['sentAt'] as Timestamp?)?.toDate(),
      );
    });
  }

  /// How many nudges each partner has sent, for the "Us" tab.
  Future<int> countSince(String coupleId, DateTime since) async {
    final snap = await _nudges(coupleId)
        .where('sentAt', isGreaterThan: Timestamp.fromDate(since))
        .count()
        .get();
    return snap.count ?? 0;
  }
}
