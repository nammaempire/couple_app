import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../models/message.dart';
import '../screens/photo_viewer.dart';
import '../theme.dart';

/// One chat message, aligned left (partner) or right (me).
class MessageBubble extends StatelessWidget {
  const MessageBubble({
    super.key,
    required this.message,
    required this.isMine,
    this.onLongPress,
    this.onDoubleTap,
  });

  final Message message;
  final bool isMine;
  final VoidCallback? onLongPress;
  final VoidCallback? onDoubleTap;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDark = theme.brightness == Brightness.dark;

    final bg = isMine
        ? theme.colorScheme.primary
        : (isDark ? AppTheme.bubbleTheirsDark : AppTheme.bubbleTheirsLight);
    final fg = isMine
        ? theme.colorScheme.onPrimary
        : theme.colorScheme.onSurface;

    final radius = BorderRadius.only(
      topLeft: const Radius.circular(20),
      topRight: const Radius.circular(20),
      bottomLeft: Radius.circular(isMine ? 20 : 4),
      bottomRight: Radius.circular(isMine ? 4 : 20),
    );

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 3),
      child: Row(
        mainAxisAlignment:
            isMine ? MainAxisAlignment.end : MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Flexible(
            child: GestureDetector(
              onLongPress: onLongPress,
              onDoubleTap: onDoubleTap,
              child: ConstrainedBox(
                constraints: BoxConstraints(
                  maxWidth: MediaQuery.sizeOf(context).width * 0.75,
                ),
                child: Stack(
                  clipBehavior: Clip.none,
                  children: [
                    Padding(
                      padding: EdgeInsets.only(
                        bottom: message.reactions.isEmpty ? 0 : 12,
                      ),
                      child: message.type == MessageType.image
                          ? _ImageContent(
                              message: message,
                              radius: radius,
                              isMine: isMine,
                            )
                          : Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 16,
                                vertical: 10,
                              ),
                              decoration: BoxDecoration(
                                color: bg,
                                borderRadius: radius,
                              ),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.end,
                                children: [
                                  Text(
                                    message.text,
                                    style: TextStyle(color: fg, fontSize: 16),
                                  ),
                                  const SizedBox(height: 2),
                                  _MetaRow(
                                    message: message,
                                    isMine: isMine,
                                    color: fg.withValues(alpha: .7),
                                  ),
                                ],
                              ),
                            ),
                    ),
                    if (message.reactions.isNotEmpty)
                      Positioned(
                        bottom: 0,
                        left: isMine ? 12 : null,
                        right: isMine ? null : 12,
                        child: _ReactionPill(emoji: message.reactionEmoji),
                      ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

/// The small floating cluster of emoji beneath a reacted-to message.
class _ReactionPill extends StatelessWidget {
  const _ReactionPill({required this.emoji});

  final List<String> emoji;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: theme.dividerColor.withValues(alpha: .4),
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: .08),
            blurRadius: 4,
            offset: const Offset(0, 1),
          ),
        ],
      ),
      child: Text(
        emoji.join(' '),
        style: const TextStyle(fontSize: 12),
      ),
    );
  }
}

class _ImageContent extends StatelessWidget {
  const _ImageContent({
    required this.message,
    required this.radius,
    required this.isMine,
  });

  final Message message;
  final BorderRadius radius;
  final bool isMine;

  @override
  Widget build(BuildContext context) {
    final url = message.imageUrl;
    if (url == null) return const SizedBox.shrink();

    return Stack(
      alignment: Alignment.bottomRight,
      children: [
        ClipRRect(
          borderRadius: radius,
          child: AspectRatio(
            aspectRatio: (message.imageAspectRatio ?? 1.0).clamp(0.5, 1.8).toDouble(),
            child: GestureDetector(
              onTap: () => Navigator.of(context).push(
                MaterialPageRoute(
                  builder: (_) => PhotoViewer(imageUrl: url),
                ),
              ),
              child: Hero(
                tag: url,
                child: CachedNetworkImage(
                  imageUrl: url,
                  fit: BoxFit.cover,
                  placeholder: (context, _) => Container(
                    color: Theme.of(context).colorScheme.surfaceContainerHighest,
                    child: const Center(
                      child: SizedBox(
                        width: 22,
                        height: 22,
                        child: CircularProgressIndicator(strokeWidth: 2),
                      ),
                    ),
                  ),
                  errorWidget: (context, _, _) => Container(
                    color: Theme.of(context).colorScheme.surfaceContainerHighest,
                    child: const Center(child: Icon(Icons.broken_image_outlined)),
                  ),
                ),
              ),
            ),
          ),
        ),
        Container(
          margin: const EdgeInsets.all(8),
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
          decoration: BoxDecoration(
            color: Colors.black.withValues(alpha: .45),
            borderRadius: BorderRadius.circular(12),
          ),
          child: _MetaRow(
            message: message,
            isMine: isMine,
            color: Colors.white,
          ),
        ),
      ],
    );
  }
}

class _MetaRow extends StatelessWidget {
  const _MetaRow({
    required this.message,
    required this.isMine,
    required this.color,
  });

  final Message message;
  final bool isMine;
  final Color color;

  @override
  Widget build(BuildContext context) {
    final sentAt = message.sentAt;
    final label = sentAt == null ? '' : DateFormat.jm().format(sentAt);

    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(label, style: TextStyle(fontSize: 11, color: color)),
        if (isMine) ...[
          const SizedBox(width: 4),
          Icon(
            message.seen ? Icons.done_all : Icons.done,
            size: 14,
            color: color,
          ),
        ],
      ],
    );
  }
}
