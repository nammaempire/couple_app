import 'package:flutter/material.dart';

/// Text field plus camera/gallery buttons at the bottom of the chat.
class ChatInput extends StatefulWidget {
  const ChatInput({
    super.key,
    required this.onSendText,
    required this.onPickCamera,
    required this.onPickGallery,
    this.enabled = true,
  });

  final Future<void> Function(String text) onSendText;
  final VoidCallback onPickCamera;
  final VoidCallback onPickGallery;
  final bool enabled;

  @override
  State<ChatInput> createState() => _ChatInputState();
}

class _ChatInputState extends State<ChatInput> {
  final _controller = TextEditingController();
  final _focus = FocusNode();
  bool _hasText = false;

  @override
  void initState() {
    super.initState();
    _controller.addListener(() {
      final has = _controller.text.trim().isNotEmpty;
      if (has != _hasText) setState(() => _hasText = has);
    });
  }

  @override
  void dispose() {
    _controller.dispose();
    _focus.dispose();
    super.dispose();
  }

  Future<void> _send() async {
    final text = _controller.text;
    if (text.trim().isEmpty) return;
    _controller.clear();
    await widget.onSendText(text);
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return SafeArea(
      top: false,
      child: Container(
        padding: const EdgeInsets.fromLTRB(8, 8, 8, 8),
        decoration: BoxDecoration(
          color: theme.colorScheme.surface,
          border: Border(
            top: BorderSide(color: theme.dividerColor.withValues(alpha: .5)),
          ),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            IconButton(
              tooltip: 'Take a photo',
              icon: const Icon(Icons.photo_camera_outlined),
              onPressed: widget.enabled ? widget.onPickCamera : null,
            ),
            IconButton(
              tooltip: 'Send a photo',
              icon: const Icon(Icons.image_outlined),
              onPressed: widget.enabled ? widget.onPickGallery : null,
            ),
            Expanded(
              child: TextField(
                controller: _controller,
                focusNode: _focus,
                enabled: widget.enabled,
                minLines: 1,
                maxLines: 5,
                textCapitalization: TextCapitalization.sentences,
                keyboardType: TextInputType.multiline,
                decoration: const InputDecoration(
                  hintText: 'Message',
                  contentPadding:
                      EdgeInsets.symmetric(horizontal: 18, vertical: 10),
                ),
              ),
            ),
            const SizedBox(width: 6),
            IconButton.filled(
              onPressed: (widget.enabled && _hasText) ? _send : null,
              icon: const Icon(Icons.send_rounded),
            ),
          ],
        ),
      ),
    );
  }
}
