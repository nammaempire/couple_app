import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../models/couple.dart';

/// Days together, the next milestone, and a countdown to the next meetup.
class TogetherCounter extends StatelessWidget {
  const TogetherCounter({
    super.key,
    required this.couple,
    required this.onSetStartDate,
  });

  final Couple couple;
  final VoidCallback onSetStartDate;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final days = couple.daysTogether;

    if (days == null) {
      return _Card(
        child: Column(
          children: [
            Icon(
              Icons.calendar_today_outlined,
              color: theme.colorScheme.onPrimaryContainer,
            ),
            const SizedBox(height: 12),
            Text(
              'When did you two start?',
              style: theme.textTheme.titleMedium?.copyWith(
                color: theme.colorScheme.onPrimaryContainer,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              'Set your date to start counting.',
              textAlign: TextAlign.center,
              style: theme.textTheme.bodySmall?.copyWith(
                color: theme.colorScheme.onPrimaryContainer
                    .withValues(alpha: .75),
              ),
            ),
            const SizedBox(height: 12),
            FilledButton.tonal(
              onPressed: onSetStartDate,
              child: const Text('Set our date'),
            ),
          ],
        ),
      );
    }

    final milestone = couple.nextMilestone;
    final untilMeetup = couple.daysUntilMeetup;

    return _Card(
      child: Column(
        children: [
          Text(
            'Together for',
            style: theme.textTheme.labelLarge?.copyWith(
              color:
                  theme.colorScheme.onPrimaryContainer.withValues(alpha: .8),
            ),
          ),
          const SizedBox(height: 4),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.baseline,
            textBaseline: TextBaseline.alphabetic,
            children: [
              Text(
                NumberFormat.decimalPattern().format(days),
                style: theme.textTheme.displayMedium?.copyWith(
                  fontWeight: FontWeight.bold,
                  color: theme.colorScheme.onPrimaryContainer,
                ),
              ),
              const SizedBox(width: 8),
              Text(
                days == 1 ? 'day' : 'days',
                style: theme.textTheme.titleMedium?.copyWith(
                  color: theme.colorScheme.onPrimaryContainer
                      .withValues(alpha: .8),
                ),
              ),
            ],
          ),
          if (couple.startDate != null) ...[
            const SizedBox(height: 2),
            Text(
              'since ${DateFormat.yMMMMd().format(couple.startDate!)}',
              style: theme.textTheme.bodySmall?.copyWith(
                color: theme.colorScheme.onPrimaryContainer
                    .withValues(alpha: .7),
              ),
            ),
          ],
          if (milestone != null) ...[
            const SizedBox(height: 16),
            _Chip(
              icon: Icons.celebration_outlined,
              label: milestone.daysAway == 0
                  ? '${milestone.milestone} days — today!'
                  : '${milestone.daysAway} days to ${milestone.milestone}',
            ),
          ],
          if (untilMeetup != null) ...[
            const SizedBox(height: 8),
            _Chip(
              icon: Icons.flight_takeoff,
              label: _meetupLabel(untilMeetup),
            ),
          ],
        ],
      ),
    );
  }

  String _meetupLabel(int days) {
    if (days > 1) return 'See each other in $days days';
    if (days == 1) return 'See each other tomorrow';
    if (days == 0) return 'You see each other today';
    return 'Time to plan the next visit';
  }
}

class _Card extends StatelessWidget {
  const _Card({required this.child});

  final Widget child;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(vertical: 24, horizontal: 20),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            theme.colorScheme.primaryContainer,
            Color.alphaBlend(
              theme.colorScheme.primary.withValues(alpha: .18),
              theme.colorScheme.primaryContainer,
            ),
          ],
        ),
      ),
      child: child,
    );
  }
}

class _Chip extends StatelessWidget {
  const _Chip({required this.icon, required this.label});

  final IconData icon;
  final String label;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
      decoration: BoxDecoration(
        color: theme.colorScheme.surface.withValues(alpha: .55),
        borderRadius: BorderRadius.circular(30),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 16, color: theme.colorScheme.onPrimaryContainer),
          const SizedBox(width: 7),
          Text(
            label,
            style: theme.textTheme.labelLarge?.copyWith(
              color: theme.colorScheme.onPrimaryContainer,
            ),
          ),
        ],
      ),
    );
  }
}
