import 'package:cloud_firestore/cloud_firestore.dart';

enum CallType { voice, video }

enum CallStatus {
  /// Caller has dialled; the other phone should be showing an incoming screen.
  ringing,

  /// Callee accepted. Both sides join the Agora channel.
  accepted,

  /// Callee actively rejected.
  declined,

  /// Either side hung up, or nobody answered in time.
  ended,
}

/// The single in-flight call for a couple.
///
/// A couple can only be in one call at a time, so this lives at a fixed
/// document path rather than a collection — which also means no stale
/// ringing documents pile up.
class CallSession {
  final String callerId;
  final String calleeId;
  final CallType type;
  final CallStatus status;

  /// Agora channel both sides join. Random per call.
  final String channelName;

  final DateTime? startedAt;
  final DateTime? answeredAt;
  final DateTime? endedAt;

  const CallSession({
    required this.callerId,
    required this.calleeId,
    required this.type,
    required this.status,
    required this.channelName,
    this.startedAt,
    this.answeredAt,
    this.endedAt,
  });

  bool get isVideo => type == CallType.video;
  bool get isRinging => status == CallStatus.ringing;
  bool get isActive => status == CallStatus.accepted;

  /// True once the call is over, however it ended.
  bool get isFinished =>
      status == CallStatus.ended || status == CallStatus.declined;

  bool isCaller(String uid) => callerId == uid;

  /// A ringing call this user should be shown an incoming screen for.
  bool isIncomingFor(String uid) => isRinging && calleeId == uid;

  /// Unanswered calls expire so a missed call does not ring forever if the
  /// caller's app was killed before it could write `ended`.
  static const ringTimeout = Duration(seconds: 45);

  bool get hasRungOut {
    final at = startedAt;
    if (at == null) return false;
    return DateTime.now().difference(at) > ringTimeout;
  }

  /// How long the call has been connected.
  Duration get elapsed {
    final from = answeredAt;
    if (from == null) return Duration.zero;
    return DateTime.now().difference(from);
  }

  factory CallSession.fromDoc(DocumentSnapshot<Map<String, dynamic>> doc) {
    final data = doc.data() ?? <String, dynamic>{};
    return CallSession(
      callerId: (data['callerId'] as String?) ?? '',
      calleeId: (data['calleeId'] as String?) ?? '',
      type: (data['type'] as String?) == 'video'
          ? CallType.video
          : CallType.voice,
      status: _statusFrom(data['status'] as String?),
      channelName: (data['channelName'] as String?) ?? '',
      startedAt: (data['startedAt'] as Timestamp?)?.toDate(),
      answeredAt: (data['answeredAt'] as Timestamp?)?.toDate(),
      endedAt: (data['endedAt'] as Timestamp?)?.toDate(),
    );
  }

  static CallStatus _statusFrom(String? raw) {
    switch (raw) {
      case 'ringing':
        return CallStatus.ringing;
      case 'accepted':
        return CallStatus.accepted;
      case 'declined':
        return CallStatus.declined;
      default:
        return CallStatus.ended;
    }
  }

  static String statusToString(CallStatus status) => switch (status) {
        CallStatus.ringing => 'ringing',
        CallStatus.accepted => 'accepted',
        CallStatus.declined => 'declined',
        CallStatus.ended => 'ended',
      };
}
