import 'package:cloud_firestore/cloud_firestore.dart';

enum MessageType { text, image }

/// A single chat message inside a couple's conversation.
class Message {
  final String id;
  final String senderId;
  final MessageType type;

  /// Text body for [MessageType.text]; empty for images.
  final String text;

  /// Download URL for [MessageType.image].
  final String? imageUrl;

  /// Aspect ratio (width / height) so bubbles can reserve space before load.
  final double? imageAspectRatio;

  final DateTime? sentAt;
  final bool seen;

  /// Emoji reactions keyed by the uid that left them. One each.
  final Map<String, String> reactions;

  const Message({
    required this.id,
    required this.senderId,
    required this.type,
    this.text = '',
    this.imageUrl,
    this.imageAspectRatio,
    this.sentAt,
    this.seen = false,
    this.reactions = const {},
  });

  /// Distinct emoji on this message, in a stable order.
  List<String> get reactionEmoji {
    final alreadyAdded = <String>{};
    final ordered = <String>[];
    for (final emoji in reactions.values) {
      if (alreadyAdded.add(emoji)) ordered.add(emoji);
    }
    return ordered;
  }

  factory Message.fromDoc(DocumentSnapshot<Map<String, dynamic>> doc) {
    final data = doc.data() ?? <String, dynamic>{};
    return Message(
      id: doc.id,
      senderId: (data['senderId'] as String?) ?? '',
      type: (data['type'] as String?) == 'image'
          ? MessageType.image
          : MessageType.text,
      text: (data['text'] as String?) ?? '',
      imageUrl: data['imageUrl'] as String?,
      imageAspectRatio: (data['imageAspectRatio'] as num?)?.toDouble(),
      sentAt: (data['sentAt'] as Timestamp?)?.toDate(),
      seen: (data['seen'] as bool?) ?? false,
      reactions: Map<String, String>.from(
        (data['reactions'] as Map<String, dynamic>?) ?? <String, dynamic>{},
      ),
    );
  }

  Map<String, dynamic> toMap() => {
        'senderId': senderId,
        'type': type == MessageType.image ? 'image' : 'text',
        'text': text,
        'imageUrl': imageUrl,
        'imageAspectRatio': imageAspectRatio,
        'sentAt': FieldValue.serverTimestamp(),
        'seen': seen,
        'reactions': reactions,
      };
}
