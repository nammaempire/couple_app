import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../models/app_user.dart';
import '../models/call_session.dart';
import '../models/couple.dart';
import '../services/auth_service.dart';
import '../services/call_service.dart';
import '../services/couple_service.dart';
import '../services/daily_question_service.dart';
import '../services/mood_service.dart';
import '../services/nudge_service.dart';
import 'chat_screen.dart';
import 'home_screen.dart';
import 'incoming_call_screen.dart';
import 'us_screen.dart';

/// Bottom-navigation shell holding Home, Chat, and Us.
///
/// It owns the couple stream and the incoming-nudge listener so both work no
/// matter which tab is on screen.
class MainShell extends StatefulWidget {
  const MainShell({
    super.key,
    required this.authService,
    required this.me,
    required this.coupleId,
  });

  final AuthService authService;
  final AppUser me;
  final String coupleId;

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  final _couples = CoupleService();
  final _moods = MoodService();
  final _questions = DailyQuestionService();
  final _nudges = NudgeService();
  final _calls = CallService();

  int _tabIndex = 0;

  /// The partner's own display name, fetched once. A nickname set by this
  /// user overrides it for display.
  String _partnerRealName = 'Your partner';
  String? _fetchedPartnerFor;

  /// The name last rendered, so the nudge listener can use it outside build.
  String _shownPartnerName = 'Your partner';

  /// What this user should see their partner called.
  String _displayNameFor(Couple couple) =>
      couple.nicknameChosenBy(widget.me.uid) ?? _partnerRealName;

  StreamSubscription<Nudge?>? _nudgeSub;
  String? _lastNudgeId;

  StreamSubscription<CallSession?>? _callSub;

  /// True while an incoming-call screen is on top, so a rebuild of the
  /// stream does not push a second copy of it.
  bool _showingIncomingCall = false;

  @override
  void initState() {
    super.initState();
    _listenForNudges();
    _listenForCalls();
  }

  @override
  void dispose() {
    _nudgeSub?.cancel();
    _callSub?.cancel();
    super.dispose();
  }

  void _listenForCalls() {
    _callSub = _calls.watchCall(widget.coupleId).listen((session) async {
      if (!mounted || session == null) return;

      // Only the callee gets the incoming screen, and only while it is still
      // ringing and has not sat unanswered past the timeout.
      if (!session.isIncomingFor(widget.me.uid)) return;
      if (_showingIncomingCall || session.hasRungOut) return;

      _showingIncomingCall = true;
      await Navigator.of(context).push(
        MaterialPageRoute(
          fullscreenDialog: true,
          builder: (_) => IncomingCallScreen(
            coupleId: widget.coupleId,
            myUid: widget.me.uid,
            partnerName: _shownPartnerName,
            session: session,
            callService: _calls,
          ),
        ),
      );
      _showingIncomingCall = false;
    });
  }

  void _listenForNudges() {
    _nudgeSub = _nudges.watchLatest(widget.coupleId).listen((nudge) {
      if (nudge == null || !mounted) return;

      // Ignore the first value on start-up and our own nudges, and only react
      // to ones that arrived just now rather than replaying history.
      final isFirstEmission = _lastNudgeId == null;
      final isNew = nudge.id != _lastNudgeId;
      _lastNudgeId = nudge.id;

      if (isFirstEmission || !isNew) return;
      if (nudge.senderId == widget.me.uid) return;
      if (!nudge.isFresh) return;

      _playNudge();
    });
  }

  Future<void> _playNudge() async {
    await HapticFeedback.heavyImpact();
    await Future<void>.delayed(const Duration(milliseconds: 140));
    await HapticFeedback.heavyImpact();

    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        behavior: SnackBarBehavior.floating,
        content: Text('💭  $_shownPartnerName is thinking of you'),
        duration: const Duration(seconds: 4),
      ),
    );
  }

  void _ensurePartnerName(Couple couple) {
    final partnerId = couple.partnerIdFor(widget.me.uid);
    if (partnerId == null || _fetchedPartnerFor == partnerId) return;

    _fetchedPartnerFor = partnerId;
    _couples.fetchUser(partnerId).then((user) {
      if (mounted && user != null) {
        setState(() => _partnerRealName = user.displayName);
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<Couple?>(
      stream: _couples.watchCouple(widget.coupleId),
      builder: (context, snapshot) {
        final couple = snapshot.data;

        if (couple == null) {
          return const Scaffold(
            body: Center(child: CircularProgressIndicator()),
          );
        }

        _ensurePartnerName(couple);
        final partnerName = _displayNameFor(couple);
        _shownPartnerName = partnerName;

        final tabs = [
          HomeScreen(
            me: widget.me,
            couple: couple,
            partnerName: partnerName,
            coupleService: _couples,
            moodService: _moods,
            questionService: _questions,
            nudgeService: _nudges,
          ),
          ChatScreen(
            authService: widget.authService,
            me: widget.me,
            coupleId: widget.coupleId,
            partnerName: partnerName,
            partnerUid: couple.partnerIdFor(widget.me.uid),
          ),
          UsScreen(
            me: widget.me,
            couple: couple,
            partnerName: partnerName,
            authService: widget.authService,
            coupleService: _couples,
            questionService: _questions,
          ),
        ];

        return Scaffold(
          body: IndexedStack(index: _tabIndex, children: tabs),
          bottomNavigationBar: NavigationBar(
            selectedIndex: _tabIndex,
            onDestinationSelected: (index) =>
                setState(() => _tabIndex = index),
            destinations: const [
              NavigationDestination(
                icon: Icon(Icons.home_outlined),
                selectedIcon: Icon(Icons.home),
                label: 'Home',
              ),
              NavigationDestination(
                icon: Icon(Icons.chat_bubble_outline),
                selectedIcon: Icon(Icons.chat_bubble),
                label: 'Chat',
              ),
              NavigationDestination(
                icon: Icon(Icons.favorite_outline),
                selectedIcon: Icon(Icons.favorite),
                label: 'Us',
              ),
            ],
          ),
        );
      },
    );
  }
}
