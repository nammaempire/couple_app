import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../models/call_session.dart';
import '../services/call_service.dart';
import 'call_screen.dart';

/// Full-screen incoming call, with accept and decline.
///
/// Pulses haptics while ringing, since without push notifications this only
/// appears when the app is already open.
class IncomingCallScreen extends StatefulWidget {
  const IncomingCallScreen({
    super.key,
    required this.coupleId,
    required this.myUid,
    required this.partnerName,
    required this.session,
    required this.callService,
  });

  final String coupleId;
  final String myUid;
  final String partnerName;
  final CallSession session;
  final CallService callService;

  @override
  State<IncomingCallScreen> createState() => _IncomingCallScreenState();
}

class _IncomingCallScreenState extends State<IncomingCallScreen> {
  StreamSubscription<CallSession?>? _callSub;
  Timer? _buzzTimer;
  bool _answering = false;

  @override
  void initState() {
    super.initState();
    _startBuzzing();

    // If the caller gives up, close this screen rather than ringing forever.
    _callSub = widget.callService.watchCall(widget.coupleId).listen((session) {
      if (!mounted) return;
      if (session == null || session.isFinished || !session.isRinging) {
        if (!_answering) _dismiss();
      }
    });
  }

  @override
  void dispose() {
    _callSub?.cancel();
    _buzzTimer?.cancel();
    super.dispose();
  }

  void _startBuzzing() {
    HapticFeedback.heavyImpact();
    _buzzTimer = Timer.periodic(const Duration(seconds: 2), (_) {
      HapticFeedback.heavyImpact();
    });
  }

  void _dismiss() {
    _buzzTimer?.cancel();
    if (mounted) Navigator.of(context).maybePop();
  }

  Future<void> _accept() async {
    setState(() => _answering = true);
    _buzzTimer?.cancel();

    await widget.callService.acceptCall(widget.coupleId);
    if (!mounted) return;

    // Replace this screen so back does not land on a stale ringing view.
    await Navigator.of(context).pushReplacement(
      MaterialPageRoute(
        builder: (_) => CallScreen(
          coupleId: widget.coupleId,
          myUid: widget.myUid,
          partnerName: widget.partnerName,
          session: CallSession(
            callerId: widget.session.callerId,
            calleeId: widget.session.calleeId,
            type: widget.session.type,
            status: CallStatus.accepted,
            channelName: widget.session.channelName,
            startedAt: widget.session.startedAt,
            answeredAt: DateTime.now(),
          ),
          callService: widget.callService,
          isOutgoing: false,
        ),
      ),
    );
  }

  Future<void> _decline() async {
    _buzzTimer?.cancel();
    await widget.callService.declineCall(widget.coupleId);
    _dismiss();
  }

  @override
  Widget build(BuildContext context) {
    final isVideo = widget.session.isVideo;
    final initial = widget.partnerName.isEmpty
        ? '?'
        : widget.partnerName.characters.first.toUpperCase();

    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop) _decline();
      },
      child: Scaffold(
        backgroundColor: const Color(0xFF14100F),
        body: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [Color(0xFF3B2229), Color(0xFF14100F)],
            ),
          ),
          child: SafeArea(
            child: Column(
              children: [
                const Spacer(flex: 2),

                Container(
                  width: 128,
                  height: 128,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: const Color(0xFFE05C7B).withValues(alpha: .25),
                  ),
                  child: Center(
                    child: Text(
                      initial,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 50,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 24),

                Text(
                  widget.partnerName,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 28,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 8),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      isVideo ? Icons.videocam : Icons.call,
                      size: 16,
                      color: Colors.white.withValues(alpha: .7),
                    ),
                    const SizedBox(width: 8),
                    Text(
                      isVideo ? 'Incoming video call' : 'Incoming voice call',
                      style: TextStyle(
                        color: Colors.white.withValues(alpha: .7),
                        fontSize: 15,
                      ),
                    ),
                  ],
                ),

                const Spacer(flex: 3),

                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 48),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      _AnswerButton(
                        icon: Icons.call_end,
                        label: 'Decline',
                        color: const Color(0xFFE23D50),
                        onPressed: _answering ? null : _decline,
                      ),
                      _AnswerButton(
                        icon: isVideo ? Icons.videocam : Icons.call,
                        label: 'Accept',
                        color: const Color(0xFF3BBF6B),
                        onPressed: _answering ? null : _accept,
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 56),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _AnswerButton extends StatelessWidget {
  const _AnswerButton({
    required this.icon,
    required this.label,
    required this.color,
    required this.onPressed,
  });

  final IconData icon;
  final String label;
  final Color color;
  final VoidCallback? onPressed;

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Material(
          color: color,
          shape: const CircleBorder(),
          child: InkWell(
            customBorder: const CircleBorder(),
            onTap: onPressed,
            child: Padding(
              padding: const EdgeInsets.all(22),
              child: Icon(icon, color: Colors.white, size: 32),
            ),
          ),
        ),
        const SizedBox(height: 10),
        Text(
          label,
          style: TextStyle(
            color: Colors.white.withValues(alpha: .8),
            fontSize: 14,
          ),
        ),
      ],
    );
  }
}
