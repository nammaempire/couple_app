import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../models/app_user.dart';
import '../models/couple.dart';
import '../models/daily_question.dart';
import '../models/mood.dart';
import '../services/couple_service.dart';
import '../services/daily_question_service.dart';
import '../services/mood_service.dart';
import '../services/nudge_service.dart';
import '../widgets/daily_question_card.dart';
import '../widgets/mood_card.dart';
import '../widgets/together_counter.dart';

/// The landing tab: counter, moods, daily question, and the nudge button.
class HomeScreen extends StatelessWidget {
  const HomeScreen({
    super.key,
    required this.me,
    required this.couple,
    required this.partnerName,
    required this.coupleService,
    required this.moodService,
    required this.questionService,
    required this.nudgeService,
  });

  final AppUser me;
  final Couple couple;
  final String partnerName;
  final CoupleService coupleService;
  final MoodService moodService;
  final DailyQuestionService questionService;
  final NudgeService nudgeService;

  String? get _partnerUid => couple.partnerIdFor(me.uid);

  Future<void> _pickStartDate(BuildContext context) async {
    final now = DateTime.now();
    final picked = await showDatePicker(
      context: context,
      initialDate: couple.startDate ?? now,
      firstDate: DateTime(1970),
      lastDate: now,
      helpText: 'When did you two start?',
    );
    if (picked == null) return;
    await coupleService.setStartDate(coupleId: couple.id, date: picked);
  }

  Future<void> _sendNudge(BuildContext context) async {
    await HapticFeedback.mediumImpact();
    await nudgeService.send(coupleId: couple.id, senderId: me.uid);
    if (!context.mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Sent $partnerName a thinking-of-you 💭')),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final partnerUid = _partnerUid;

    return Scaffold(
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 20, 16, 32),
          children: [
            Text(
              _greeting(),
              style: theme.textTheme.headlineSmall
                  ?.copyWith(fontWeight: FontWeight.w600),
            ),
            const SizedBox(height: 4),
            Text(
              couple.isComplete
                  ? 'You and $partnerName'
                  : 'Share code ${couple.inviteCode} to pair',
              style: theme.textTheme.bodyMedium?.copyWith(
                color: theme.colorScheme.onSurfaceVariant,
              ),
            ),
            const SizedBox(height: 20),

            TogetherCounter(
              couple: couple,
              onSetStartDate: () => _pickStartDate(context),
            ),
            const SizedBox(height: 16),

            StreamBuilder<Map<String, MoodEntry>>(
              stream: moodService.watchMoods(couple.id),
              builder: (context, snapshot) {
                return MoodCard(
                  myUid: me.uid,
                  partnerUid: partnerUid,
                  partnerName: partnerName,
                  moods: snapshot.data ?? const {},
                  onPick: (mood, note) => moodService.setMood(
                    coupleId: couple.id,
                    uid: me.uid,
                    mood: mood,
                    note: note,
                  ),
                );
              },
            ),
            const SizedBox(height: 16),

            StreamBuilder<DailyQuestionEntry>(
              stream: questionService.watchToday(couple.id),
              builder: (context, snapshot) {
                final entry = snapshot.data ??
                    DailyQuestionEntry(
                      dateKey: QuestionBank.dateKeyFor(DateTime.now()),
                      prompt: QuestionBank.promptFor(
                        DateTime.now(),
                        couple.id,
                      ),
                    );
                return DailyQuestionCard(
                  entry: entry,
                  myUid: me.uid,
                  partnerUid: partnerUid,
                  partnerName: partnerName,
                  onAnswer: (text) => questionService.answer(
                    coupleId: couple.id,
                    uid: me.uid,
                    text: text,
                  ),
                );
              },
            ),
            const SizedBox(height: 16),

            _NudgeButton(
              partnerName: partnerName,
              enabled: couple.isComplete,
              onPressed: () => _sendNudge(context),
            ),
          ],
        ),
      ),
    );
  }

  String _greeting() {
    final hour = DateTime.now().hour;
    if (hour < 12) return 'Good morning';
    if (hour < 17) return 'Good afternoon';
    if (hour < 21) return 'Good evening';
    return 'Still up?';
  }
}

class _NudgeButton extends StatelessWidget {
  const _NudgeButton({
    required this.partnerName,
    required this.enabled,
    required this.onPressed,
  });

  final String partnerName;
  final bool enabled;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return InkWell(
      onTap: enabled ? onPressed : null,
      borderRadius: BorderRadius.circular(24),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 22, horizontal: 20),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(24),
          border: Border.all(
            color: theme.colorScheme.primary.withValues(alpha: .35),
            width: 1.5,
          ),
        ),
        child: Row(
          children: [
            Text('💭', style: TextStyle(fontSize: 28, color: theme.colorScheme.primary)),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Thinking of you',
                    style: theme.textTheme.titleMedium
                        ?.copyWith(fontWeight: FontWeight.w600),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    enabled
                        ? 'One tap and $partnerName\'s phone buzzes.'
                        : 'Available once you\'re paired.',
                    style: theme.textTheme.bodySmall?.copyWith(
                      color: theme.colorScheme.onSurfaceVariant,
                    ),
                  ),
                ],
              ),
            ),
            Icon(
              Icons.chevron_right,
              color: theme.colorScheme.onSurfaceVariant,
            ),
          ],
        ),
      ),
    );
  }
}
