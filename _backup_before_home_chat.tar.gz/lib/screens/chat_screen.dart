import 'dart:io';

import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';

import '../agora_config.dart';
import '../models/app_user.dart';
import '../models/call_session.dart';
import '../models/couple.dart';
import '../models/message.dart';
import '../services/auth_service.dart';
import '../services/call_service.dart';
import '../services/chat_service.dart';
import '../services/couple_service.dart';
import 'call_screen.dart';
import '../widgets/chat_input.dart';
import '../widgets/message_bubble.dart';

/// The conversation between the two partners.
class ChatScreen extends StatefulWidget {
  const ChatScreen({
    super.key,
    required this.authService,
    required this.me,
    required this.coupleId,
    required this.partnerName,
    required this.partnerUid,
    this.chatService,
    this.coupleService,
  });

  final AuthService authService;
  final AppUser me;
  final String coupleId;

  /// Already resolved by the shell, nickname applied.
  final String partnerName;

  /// Null until the couple is complete.
  final String? partnerUid;

  final ChatService? chatService;
  final CoupleService? coupleService;

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  late final ChatService _chat = widget.chatService ?? ChatService();
  late final CoupleService _couples = widget.coupleService ?? CoupleService();
  final _calls = CallService();
  final _picker = ImagePicker();

  double? _uploadProgress;

  /// Id of the newest message we have already run a seen-sweep for, so
  /// rebuilds don't trigger repeated Firestore reads.
  String? _lastSeenSweepId;

  @override
  void initState() {
    super.initState();
    _chat.markSeen(coupleId: widget.coupleId, readerId: widget.me.uid);
  }

  Future<void> _sendText(String text) async {
    try {
      await _chat.sendText(
        coupleId: widget.coupleId,
        senderId: widget.me.uid,
        text: text,
      );
    } catch (e) {
      _showError('Message not sent. Check your connection.');
    }
  }

  Future<void> _sendPhoto(ImageSource source) async {
    final XFile? picked;
    try {
      picked = await _picker.pickImage(
        source: source,
        imageQuality: 82,
        maxWidth: 2000,
      );
    } catch (e) {
      _showError('Could not open ${source == ImageSource.camera ? 'the camera' : 'your photos'}.');
      return;
    }
    if (picked == null) return;

    setState(() => _uploadProgress = 0);
    try {
      await _chat.sendImage(
        coupleId: widget.coupleId,
        senderId: widget.me.uid,
        file: File(picked.path),
        onProgress: (p) {
          if (mounted) setState(() => _uploadProgress = p);
        },
      );
    } on FirebaseException catch (e) {
      // Storage is optional: the app is usable for text before it is enabled.
      if (e.plugin == 'firebase_storage') {
        _showError(
          'Photo sending needs Firebase Storage enabled on this project.',
        );
      } else {
        _showError('Photo failed to send.');
      }
    } catch (e) {
      _showError('Photo failed to send.');
    } finally {
      if (mounted) setState(() => _uploadProgress = null);
    }
  }

  void _showError(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(message)));
  }

  /// Places a call and opens the outgoing screen. The callee's app shows the
  /// incoming screen from its own signalling listener.
  Future<void> _startCall(CallType type) async {
    if (!AgoraConfig.isConfigured) {
      _showError('Calling is not set up yet: no Agora App ID.');
      return;
    }

    final partnerId = widget.partnerUid;
    if (partnerId == null) {
      _showError('You need to be paired before you can call.');
      return;
    }

    try {
      final session = await _calls.startCall(
        coupleId: widget.coupleId,
        callerId: widget.me.uid,
        calleeId: partnerId,
        type: type,
      );
      if (!mounted) return;

      await Navigator.of(context).push(
        MaterialPageRoute(
          fullscreenDialog: true,
          builder: (_) => CallScreen(
            coupleId: widget.coupleId,
            myUid: widget.me.uid,
            partnerName: widget.partnerName,
            session: session,
            callService: _calls,
            isOutgoing: true,
          ),
        ),
      );
    } catch (e) {
      _showError('Could not start the call.');
    }
  }

  static const _reactionChoices = ['❤️', '😍', '😂', '🥺', '👍', '🔥'];

  /// Long-press sheet: react with an emoji, and delete if it's your own.
  Future<void> _openMessageActions(Message message) async {
    final isMine = message.senderId == widget.me.uid;

    await showModalBottomSheet<void>(
      context: context,
      builder: (sheetContext) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 16),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: _reactionChoices.map((emoji) {
                  final isActive =
                      message.reactions[widget.me.uid] == emoji;
                  return GestureDetector(
                    onTap: () {
                      Navigator.pop(sheetContext);
                      _react(message, emoji);
                    },
                    child: Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: isActive
                            ? Theme.of(context)
                                .colorScheme
                                .primary
                                .withValues(alpha: .18)
                            : Colors.transparent,
                      ),
                      child: Text(
                        emoji,
                        style: const TextStyle(fontSize: 28),
                      ),
                    ),
                  );
                }).toList(),
              ),
            ),
            const Divider(height: 1),
            if (isMine)
              ListTile(
                leading: const Icon(Icons.delete_outline),
                title: const Text('Delete message'),
                onTap: () {
                  Navigator.pop(sheetContext);
                  _delete(message);
                },
              ),
            ListTile(
              leading: const Icon(Icons.close),
              title: const Text('Cancel'),
              onTap: () => Navigator.pop(sheetContext),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _react(Message message, String emoji) async {
    await HapticFeedback.selectionClick();
    try {
      await _chat.toggleReaction(
        coupleId: widget.coupleId,
        message: message,
        uid: widget.me.uid,
        emoji: emoji,
      );
    } catch (e) {
      _showError('Could not add that reaction.');
    }
  }

  Future<void> _delete(Message message) async {
    try {
      await _chat.deleteMessage(coupleId: widget.coupleId, message: message);
    } catch (e) {
      _showError('Could not delete that message.');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: StreamBuilder<Couple?>(
          stream: _couples.watchCouple(widget.coupleId),
          builder: (context, snap) {
            final couple = snap.data;

            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(widget.partnerName),
                if (couple != null && !couple.isComplete)
                  Text(
                    'Waiting for your partner · code ${couple.inviteCode}',
                    style: Theme.of(context).textTheme.bodySmall,
                  ),
              ],
            );
          },
        ),
        actions: [
          IconButton(
            tooltip: 'Voice call',
            icon: const Icon(Icons.call_outlined),
            onPressed: () => _startCall(CallType.voice),
          ),
          IconButton(
            tooltip: 'Video call',
            icon: const Icon(Icons.videocam_outlined),
            onPressed: () => _startCall(CallType.video),
          ),
        ],
      ),
      body: Column(
        children: [
          if (_uploadProgress != null)
            LinearProgressIndicator(
              value: _uploadProgress == 0 ? null : _uploadProgress,
            ),
          Expanded(
            child: StreamBuilder<List<Message>>(
              stream: _chat.watchMessages(widget.coupleId),
              builder: (context, snapshot) {
                if (snapshot.hasError) {
                  return const _CenteredNote(
                    icon: Icons.cloud_off,
                    text: 'Could not load messages.',
                  );
                }
                if (!snapshot.hasData) {
                  return const Center(child: CircularProgressIndicator());
                }

                final messages = snapshot.data!;
                if (messages.isEmpty) {
                  return const _CenteredNote(
                    icon: Icons.favorite_border,
                    text: 'Say something sweet to start.',
                  );
                }

                // Mark incoming messages read, but only once per new arrival.
                final newest = messages.first;
                if (newest.id != _lastSeenSweepId) {
                  _lastSeenSweepId = newest.id;
                  _chat.markSeen(
                    coupleId: widget.coupleId,
                    readerId: widget.me.uid,
                  );
                }

                return ListView.builder(
                  reverse: true,
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  itemCount: messages.length,
                  itemBuilder: (context, index) {
                    final message = messages[index];
                    final isMine = message.senderId == widget.me.uid;

                    // messages is newest-first, so "older" is the next index.
                    final older = index + 1 < messages.length
                        ? messages[index + 1]
                        : null;
                    final showDate = _needsDateDivider(message, older);

                    return Column(
                      children: [
                        if (showDate) _DateDivider(date: message.sentAt),
                        MessageBubble(
                          message: message,
                          isMine: isMine,
                          onLongPress: () => _openMessageActions(message),
                          onDoubleTap: () => _react(message, '❤️'),
                        ),
                      ],
                    );
                  },
                );
              },
            ),
          ),
          ChatInput(
            enabled: _uploadProgress == null,
            onSendText: _sendText,
            onPickCamera: () => _sendPhoto(ImageSource.camera),
            onPickGallery: () => _sendPhoto(ImageSource.gallery),
          ),
        ],
      ),
    );
  }

  bool _needsDateDivider(Message current, Message? older) {
    final currentDate = current.sentAt;
    if (currentDate == null) return false;
    if (older?.sentAt == null) return true;

    final previousDate = older!.sentAt!;
    return currentDate.year != previousDate.year ||
        currentDate.month != previousDate.month ||
        currentDate.day != previousDate.day;
  }
}

class _DateDivider extends StatelessWidget {
  const _DateDivider({required this.date});

  final DateTime? date;

  @override
  Widget build(BuildContext context) {
    if (date == null) return const SizedBox.shrink();

    final now = DateTime.now();
    final isToday = date!.year == now.year &&
        date!.month == now.month &&
        date!.day == now.day;
    final label = isToday ? 'Today' : DateFormat.yMMMd().format(date!);

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 12),
      child: Text(
        label,
        style: Theme.of(context).textTheme.labelSmall?.copyWith(
              color: Theme.of(context).colorScheme.onSurfaceVariant,
            ),
      ),
    );
  }
}

class _CenteredNote extends StatelessWidget {
  const _CenteredNote({required this.icon, required this.text});

  final IconData icon;
  final String text;

  @override
  Widget build(BuildContext context) {
    final color = Theme.of(context).colorScheme.onSurfaceVariant;
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 44, color: color),
          const SizedBox(height: 12),
          Text(text, style: TextStyle(color: color)),
        ],
      ),
    );
  }
}
