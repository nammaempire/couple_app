import 'dart:async';

import 'package:agora_rtc_engine/agora_rtc_engine.dart';
import 'package:flutter/material.dart';

import '../models/call_session.dart';
import '../services/agora_service.dart';
import '../services/call_service.dart';

/// The in-call screen, for both the caller and the callee.
///
/// It owns the Agora engine for the duration of the call and watches the
/// signalling document so a hang-up on either side closes both screens.
class CallScreen extends StatefulWidget {
  const CallScreen({
    super.key,
    required this.coupleId,
    required this.myUid,
    required this.partnerName,
    required this.session,
    required this.callService,
    required this.isOutgoing,
  });

  final String coupleId;
  final String myUid;
  final String partnerName;
  final CallSession session;
  final CallService callService;

  /// True when this user placed the call and is waiting for an answer.
  final bool isOutgoing;

  @override
  State<CallScreen> createState() => _CallScreenState();
}

class _CallScreenState extends State<CallScreen> {
  final _agora = AgoraService();

  StreamSubscription<CallSession?>? _callSub;
  Timer? _ticker;
  Duration _elapsed = Duration.zero;

  bool _joining = false;
  bool _hasJoined = false;
  String? _error;

  @override
  void initState() {
    super.initState();
    _agora.addListener(_onAgoraChanged);
    _watchSignalling();

    // The callee already accepted before this screen opened, so connect now.
    // The caller waits for the accept to land.
    if (widget.session.isActive) _connect();
  }

  @override
  void dispose() {
    _callSub?.cancel();
    _ticker?.cancel();
    _agora.removeListener(_onAgoraChanged);
    _agora.dispose();
    super.dispose();
  }

  void _onAgoraChanged() {
    if (mounted) setState(() {});
  }

  void _watchSignalling() {
    _callSub = widget.callService.watchCall(widget.coupleId).listen((session) {
      if (!mounted) return;

      // The other side hung up, declined, or the document was cleared.
      if (session == null || session.isFinished) {
        _close(
          message: session?.status == CallStatus.declined
              ? '${widget.partnerName} declined'
              : null,
        );
        return;
      }

      // Caller side: the callee just accepted, so join the channel.
      if (session.isActive && !_hasJoined && !_joining) {
        _startTicker(session);
        _connect();
      }
    });
  }

  void _startTicker(CallSession session) {
    _ticker?.cancel();
    _ticker = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!mounted) return;
      setState(() => _elapsed = session.elapsed);
    });
  }

  Future<void> _connect() async {
    if (_joining || _hasJoined) return;
    setState(() => _joining = true);

    try {
      await _agora.join(
        channelName: widget.session.channelName,
        video: widget.session.isVideo,
      );
      if (mounted) setState(() => _hasJoined = true);
    } on CallSetupException catch (e) {
      if (mounted) setState(() => _error = e.message);
      await widget.callService.endCall(widget.coupleId);
    } catch (e) {
      if (mounted) setState(() => _error = 'Could not connect the call.');
      await widget.callService.endCall(widget.coupleId);
    } finally {
      if (mounted) setState(() => _joining = false);
    }
  }

  Future<void> _hangUp() async {
    await widget.callService.endCall(widget.coupleId);
    _close();
  }

  void _close({String? message}) {
    if (!mounted) return;
    _ticker?.cancel();
    Navigator.of(context).maybePop();
    if (message != null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(message)),
      );
    }
  }

  String get _statusLabel {
    if (_error != null) return 'Call failed';
    if (!_hasJoined) {
      return widget.isOutgoing ? 'Ringing…' : 'Connecting…';
    }
    if (_agora.remoteUid == null) {
      return _agora.partnerHasJoined ? 'Reconnecting…' : 'Connecting…';
    }
    return _formatDuration(_elapsed);
  }

  String _formatDuration(Duration d) {
    final minutes = d.inMinutes.toString().padLeft(2, '0');
    final seconds = (d.inSeconds % 60).toString().padLeft(2, '0');
    return '$minutes:$seconds';
  }

  @override
  Widget build(BuildContext context) {
    final isVideo = widget.session.isVideo;
    final connected = _agora.remoteUid != null;

    return PopScope(
      // Leaving by back-swipe should hang up, not silently orphan the call.
      canPop: false,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop) _hangUp();
      },
      child: Scaffold(
        backgroundColor: const Color(0xFF14100F),
        body: Stack(
          children: [
            if (isVideo && connected)
              _RemoteVideo(
                agora: _agora,
                uid: _agora.remoteUid!,
                channelName: widget.session.channelName,
              )
            else
              _AvatarBackdrop(name: widget.partnerName),

            if (isVideo && _hasJoined && !_agora.cameraOff)
              Positioned(
                top: 60,
                right: 16,
                width: 110,
                height: 160,
                child: _LocalVideo(agora: _agora),
              ),

            Positioned(
              top: 60,
              left: 0,
              right: 0,
              child: Column(
                children: [
                  Text(
                    widget.partnerName,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 26,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    _statusLabel,
                    style: TextStyle(
                      color: Colors.white.withValues(alpha: .7),
                      fontSize: 15,
                    ),
                  ),
                  if (_error != null) ...[
                    const SizedBox(height: 12),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 32),
                      child: Text(
                        _error!,
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          color: Color(0xFFFF9B9B),
                          fontSize: 14,
                        ),
                      ),
                    ),
                  ],
                ],
              ),
            ),

            Positioned(
              left: 0,
              right: 0,
              bottom: 48,
              child: _CallControls(
                agora: _agora,
                isVideo: isVideo,
                onHangUp: _hangUp,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _RemoteVideo extends StatelessWidget {
  const _RemoteVideo({
    required this.agora,
    required this.uid,
    required this.channelName,
  });

  final AgoraService agora;
  final int uid;
  final String channelName;

  @override
  Widget build(BuildContext context) {
    final engine = agora.engine;
    if (engine == null) return const SizedBox.shrink();

    return AgoraVideoView(
      controller: VideoViewController.remote(
        rtcEngine: engine,
        canvas: VideoCanvas(uid: uid),
        connection: RtcConnection(channelId: channelName),
      ),
    );
  }
}

class _LocalVideo extends StatelessWidget {
  const _LocalVideo({required this.agora});

  final AgoraService agora;

  @override
  Widget build(BuildContext context) {
    final engine = agora.engine;
    if (engine == null) return const SizedBox.shrink();

    return ClipRRect(
      borderRadius: BorderRadius.circular(16),
      child: AgoraVideoView(
        controller: VideoViewController(
          rtcEngine: engine,
          canvas: const VideoCanvas(uid: 0),
        ),
      ),
    );
  }
}

/// Shown for voice calls, and for video before the far side connects.
class _AvatarBackdrop extends StatelessWidget {
  const _AvatarBackdrop({required this.name});

  final String name;

  @override
  Widget build(BuildContext context) {
    final initial = name.isEmpty ? '?' : name.characters.first.toUpperCase();

    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Color(0xFF3B2229), Color(0xFF14100F)],
        ),
      ),
      child: Center(
        child: Container(
          width: 132,
          height: 132,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: const Color(0xFFE05C7B).withValues(alpha: .25),
          ),
          child: Center(
            child: Text(
              initial,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 52,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _CallControls extends StatelessWidget {
  const _CallControls({
    required this.agora,
    required this.isVideo,
    required this.onHangUp,
  });

  final AgoraService agora;
  final bool isVideo;
  final VoidCallback onHangUp;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        _ControlButton(
          icon: agora.micMuted ? Icons.mic_off : Icons.mic,
          active: agora.micMuted,
          tooltip: agora.micMuted ? 'Unmute' : 'Mute',
          onPressed: agora.isReady ? agora.toggleMic : null,
        ),
        const SizedBox(width: 14),

        if (isVideo) ...[
          _ControlButton(
            icon: agora.cameraOff ? Icons.videocam_off : Icons.videocam,
            active: agora.cameraOff,
            tooltip: agora.cameraOff ? 'Camera on' : 'Camera off',
            onPressed: agora.isReady ? agora.toggleCamera : null,
          ),
          const SizedBox(width: 14),
          _ControlButton(
            icon: Icons.cameraswitch,
            tooltip: 'Flip camera',
            onPressed: agora.isReady ? agora.switchCamera : null,
          ),
        ] else
          _ControlButton(
            icon: agora.speakerOn ? Icons.volume_up : Icons.phone_in_talk,
            active: agora.speakerOn,
            tooltip: agora.speakerOn ? 'Speaker off' : 'Speaker on',
            onPressed: agora.isReady ? agora.toggleSpeaker : null,
          ),

        const SizedBox(width: 14),
        _ControlButton(
          icon: Icons.call_end,
          background: const Color(0xFFE23D50),
          iconColor: Colors.white,
          tooltip: 'End call',
          onPressed: onHangUp,
        ),
      ],
    );
  }
}

class _ControlButton extends StatelessWidget {
  const _ControlButton({
    required this.icon,
    required this.tooltip,
    required this.onPressed,
    this.active = false,
    this.background,
    this.iconColor,
  });

  final IconData icon;
  final String tooltip;
  final VoidCallback? onPressed;
  final bool active;
  final Color? background;
  final Color? iconColor;

  @override
  Widget build(BuildContext context) {
    final bg = background ??
        (active ? Colors.white : Colors.white.withValues(alpha: .16));
    final fg = iconColor ?? (active ? Colors.black87 : Colors.white);

    return Tooltip(
      message: tooltip,
      child: Material(
        color: bg,
        shape: const CircleBorder(),
        child: InkWell(
          customBorder: const CircleBorder(),
          onTap: onPressed,
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Icon(icon, color: fg, size: 26),
          ),
        ),
      ),
    );
  }
}
