# Us — a private chat app for two

A Flutter app where two partners pair with an invite code and share a single
private conversation: text messages and photos, synced live.

**Built in this pass:** authentication, pairing, real-time chat, photo sending.
**Next:** voice and video calling (the call buttons are in the app bar, currently stubbed).

---

## What you must do before it runs

The app expects a Firebase project. Nothing in `lib/` needs editing — the setup
is all configuration.

### 1. Install the tooling

```bash
dart pub global activate flutterfire_cli
npm install -g firebase-tools
firebase login
```

### 2. Create a Firebase project

At <https://console.firebase.google.com>, create a project. Then enable:

- **Authentication → Sign-in method → Email/Password**
- **Firestore Database** (start in production mode; rules come from this repo)
- **Storage** (same)

### 3. Connect the app

From the project root:

```bash
flutterfire configure
```

This writes `lib/firebase_options.dart` and `android/app/google-services.json`.

If you use `firebase_options.dart`, change `main.dart` to:

```dart
await Firebase.initializeApp(
  options: DefaultFirebaseOptions.currentPlatform,
);
```

(As written it calls `Firebase.initializeApp()` with no arguments, which works
on Android via `google-services.json`.)

### 4. Add the Google Services Gradle plugin

In `android/settings.gradle.kts`, inside the `plugins { }` block:

```kotlin
id("com.google.gms.google-services") version "4.4.2" apply false
```

In `android/app/build.gradle.kts`, inside its `plugins { }` block:

```kotlin
id("com.google.gms.google-services")
```

### 5. Deploy the security rules

The rules in this repo restrict every message and photo to the two members of a
couple. Deploy them:

```bash
firebase deploy --only firestore:rules,storage:rules
```

You may need a `firebase.json` pointing at the files:

```json
{
  "firestore": { "rules": "firestore.rules" },
  "storage": { "rules": "storage.rules" }
}
```

### 6. Run

```bash
flutter pub get
flutter run
```

---

## How pairing works

1. Partner A signs up, taps **Create an invite code**, gets a 6-character code.
2. Partner B signs up on their own device and enters that code.
3. Firestore writes `coupleId` onto both user profiles, and the app moves
   straight to the chat.

A code can only be used once — the join runs in a transaction that rejects a
couple already holding two members.

---

## Data model

```
users/{uid}
  displayName, photoUrl, coupleId, email, createdAt

couples/{coupleId}
  inviteCode, memberIds[], createdAt, lastMessagePreview, lastMessageAt,
  startDate, nextMeetup,
  nicknames: { <setterUid>: "what that person calls their partner" }

couples/{coupleId}/moods/{uid}
  mood, note, updatedAt

couples/{coupleId}/dailyQuestions/{yyyy-MM-dd}
  prompt, date, answers: { <uid>: { text, answeredAt } }

couples/{coupleId}/nudges/{nudgeId}
  senderId, sentAt

couples/{coupleId}/call/current
  callerId, calleeId, type ("voice" | "video"),
  status ("ringing" | "accepted" | "declined" | "ended"),
  channelName, startedAt, answeredAt, endedAt

couples/{coupleId}/messages/{messageId}
  senderId, type ("text" | "image"), text, imageUrl,
  imageAspectRatio, sentAt, seen
```

## Project layout

```
lib/
  main.dart              app entry, Firebase init, theme
  theme.dart             colour palette and Material 3 theme
  models/                AppUser, Couple, Message
  services/
    auth_service.dart    sign up / sign in / profile stream
    couple_service.dart  create and join couples by invite code
    chat_service.dart    message stream, send text, send image, seen, delete
    storage_service.dart photo upload to Firebase Storage
  screens/
    auth_gate.dart       routes: sign-in → pairing → chat
    sign_in_screen.dart
    pairing_screen.dart
    chat_screen.dart
    photo_viewer.dart    full-screen pinch-zoom photo
  widgets/
    message_bubble.dart
    chat_input.dart
```

## Features

- Email/password sign up, sign in, password reset
- Invite-code pairing, single-use, transactional
- Three tabs: Home, Chat, Us
- Days-together counter, milestones, and a countdown to the next meetup
- Mood check-in shared between partners
- Daily question that unlocks only once both have answered
- Thinking-of-you buzz with haptic feedback
- Live message stream, newest at the bottom
- Reactions: double-tap to heart, long-press for the full picker
- Photos from camera or gallery, with upload progress
- Delivered/seen ticks on your own messages
- Nicknames: each partner sets their own pet name for the other
- Date dividers, tap-to-zoom photos, long-press to delete your own message
- Light and dark themes following the system setting

## Nicknames

Nicknames are one-directional on purpose. `nicknames` on the couple document is
keyed by the uid of the person who *set* the name, and the value is what that
person calls their partner. So you can call her "Bubu" while she calls you
"Chotu", and neither has to agree with the other's choice. Clearing a nickname
falls back to the partner's own display name.

Set both from the **Us** tab, under Names.

## Voice and video calls

Calling uses [Agora](https://console.agora.io) for the media and Firestore for
the signalling, so there is no call server to run.

### Setup

1. Sign up at <https://console.agora.io> and create a project.
2. Set its authentication mode to **Testing mode: APP ID**. This is what lets
   the app connect without a token server.
3. Copy the App ID.
4. Pass it at run or build time:

```bash
flutter run --dart-define=AGORA_APP_ID=your_app_id_here
flutter build apk --release --dart-define=AGORA_APP_ID=your_app_id_here
```

The `--dart-define` keeps the id out of version control. Without it the call
buttons explain that calling is not configured rather than failing obscurely.

The free tier is 10,000 minutes a month, which two people will not exhaust.
Video minutes count more heavily than voice.

### How it works

`couples/{coupleId}/call/current` is the signalling document. The caller writes
`status: ringing`; the callee's `MainShell` listener sees it and pushes the
incoming-call screen; accepting flips the status to `accepted` and both sides
join the same Agora channel. Either side writing `ended` closes both screens.

Channel names are random UUIDs generated per call, so testing mode's lack of
tokens is not a practical exposure — nobody can guess a live channel.

### The limitation

There are no push notifications yet, so **a call only rings if the other
person has the app open.** Android freezes background apps, so a closed app
will not ring. Fixing that needs FCM plus a Cloud Function to send the push on
call creation, which requires the Blaze plan. The call code itself would not
change — only the delivery of the ring.
