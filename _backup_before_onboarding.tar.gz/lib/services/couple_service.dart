import 'dart:math';

import 'package:cloud_firestore/cloud_firestore.dart';

import '../models/app_user.dart';
import '../models/couple.dart';

/// Thrown when joining with a code that is invalid or already used up.
class PairingException implements Exception {
  PairingException(this.message);
  final String message;
  @override
  String toString() => message;
}

/// Creates and joins the two-person "couple" that owns a conversation.
class CoupleService {
  CoupleService({FirebaseFirestore? firestore})
      : _db = firestore ?? FirebaseFirestore.instance;

  final FirebaseFirestore _db;

  static const _codeAlphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';

  String _generateCode([int length = 6]) {
    final rand = Random.secure();
    return List.generate(
      length,
      (_) => _codeAlphabet[rand.nextInt(_codeAlphabet.length)],
    ).join();
  }

  Stream<Couple?> watchCouple(String coupleId) {
    return _db
        .collection('couples')
        .doc(coupleId)
        .snapshots()
        .map((doc) => doc.exists ? Couple.fromDoc(doc) : null);
  }

  Future<AppUser?> fetchUser(String uid) async {
    final doc = await _db.collection('users').doc(uid).get();
    return doc.exists ? AppUser.fromDoc(doc) : null;
  }

  /// Creates a new couple owned by [uid] and returns its invite code.
  Future<Couple> createCouple(String uid) async {
    final coupleRef = _db.collection('couples').doc();
    final code = _generateCode();

    final batch = _db.batch();
    batch.set(coupleRef, {
      'inviteCode': code,
      'memberIds': [uid],
      'createdAt': FieldValue.serverTimestamp(),
    });
    batch.update(_db.collection('users').doc(uid), {'coupleId': coupleRef.id});
    await batch.commit();

    return Couple(id: coupleRef.id, inviteCode: code, memberIds: [uid]);
  }

  /// Joins the couple identified by [code]. Fails if it is full or unknown.
  Future<Couple> joinCouple({required String uid, required String code}) async {
    final normalized = code.trim().toUpperCase();
    final query = await _db
        .collection('couples')
        .where('inviteCode', isEqualTo: normalized)
        .limit(1)
        .get();

    if (query.docs.isEmpty) {
      throw PairingException('No invite found for code $normalized.');
    }

    final coupleRef = query.docs.first.reference;

    await _db.runTransaction((tx) async {
      final snap = await tx.get(coupleRef);
      final members = List<String>.from(
        (snap.data()?['memberIds'] as List<dynamic>?) ?? const <dynamic>[],
      );

      if (members.contains(uid)) return; // Already joined; nothing to do.
      if (members.length >= 2) {
        throw PairingException('That invite has already been used.');
      }

      tx.update(coupleRef, {
        'memberIds': FieldValue.arrayUnion([uid]),
      });
      tx.update(_db.collection('users').doc(uid), {'coupleId': coupleRef.id});
    });

    final fresh = await coupleRef.get();
    return Couple.fromDoc(fresh);
  }

  /// Sets the day the relationship started, for the days-together counter.
  Future<void> setStartDate({
    required String coupleId,
    required DateTime? date,
  }) {
    return _db.collection('couples').doc(coupleId).set({
      'startDate': date == null ? null : Timestamp.fromDate(date),
    }, SetOptions(merge: true));
  }

  /// Sets the next date the two of you will be together.
  Future<void> setNextMeetup({
    required String coupleId,
    required DateTime? date,
  }) {
    return _db.collection('couples').doc(coupleId).set({
      'nextMeetup': date == null ? null : Timestamp.fromDate(date),
    }, SetOptions(merge: true));
  }

  /// Sets what [uid] calls their partner. Passing null or blank clears it,
  /// falling the app back to the partner's own display name.
  Future<void> setPartnerNickname({
    required String coupleId,
    required String uid,
    required String? nickname,
  }) {
    final trimmed = nickname?.trim();
    final ref = _db.collection('couples').doc(coupleId);

    if (trimmed == null || trimmed.isEmpty) {
      return ref.update({'nicknames.$uid': FieldValue.delete()});
    }
    return ref.set({
      'nicknames': {uid: trimmed},
    }, SetOptions(merge: true));
  }

  /// Unlinks [uid] from their couple. The conversation itself is kept.
  Future<void> leaveCouple({required String uid, required String coupleId}) async {
    final batch = _db.batch();
    batch.update(_db.collection('couples').doc(coupleId), {
      'memberIds': FieldValue.arrayRemove([uid]),
    });
    batch.update(_db.collection('users').doc(uid), {'coupleId': null});
    await batch.commit();
  }
}
