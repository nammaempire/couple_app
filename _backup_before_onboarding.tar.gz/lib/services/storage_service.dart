import 'dart:io';

import 'package:firebase_storage/firebase_storage.dart';
import 'package:uuid/uuid.dart';

/// Uploads chat photos to Firebase Storage under `couples/{coupleId}/photos/`.
class StorageService {
  StorageService({FirebaseStorage? storage})
      : _storage = storage ?? FirebaseStorage.instance;

  final FirebaseStorage _storage;
  static final _uuid = Uuid();

  /// Uploads [file] and returns its public download URL.
  ///
  /// [onProgress] receives a value from 0.0 to 1.0.
  Future<String> uploadChatPhoto({
    required String coupleId,
    required File file,
    void Function(double progress)? onProgress,
  }) async {
    final ext = _extensionOf(file.path);
    final ref = _storage.ref('couples/$coupleId/photos/${_uuid.v4()}$ext');

    final task = ref.putFile(
      file,
      SettableMetadata(contentType: _contentTypeFor(ext)),
    );

    if (onProgress != null) {
      task.snapshotEvents.listen((snap) {
        if (snap.totalBytes > 0) {
          onProgress(snap.bytesTransferred / snap.totalBytes);
        }
      });
    }

    await task;
    return ref.getDownloadURL();
  }

  Future<void> deleteByUrl(String url) async {
    await _storage.refFromURL(url).delete();
  }

  String _extensionOf(String path) {
    final dot = path.lastIndexOf('.');
    if (dot == -1 || dot == path.length - 1) return '.jpg';
    return path.substring(dot).toLowerCase();
  }

  String _contentTypeFor(String ext) {
    switch (ext) {
      case '.png':
        return 'image/png';
      case '.gif':
        return 'image/gif';
      case '.webp':
        return 'image/webp';
      case '.heic':
        return 'image/heic';
      default:
        return 'image/jpeg';
    }
  }
}
