import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

import '../models/app_user.dart';

/// Email/password auth plus the matching `users/{uid}` profile document.
class AuthService {
  AuthService({FirebaseAuth? auth, FirebaseFirestore? firestore})
      : _auth = auth ?? FirebaseAuth.instance,
        _db = firestore ?? FirebaseFirestore.instance;

  final FirebaseAuth _auth;
  final FirebaseFirestore _db;

  User? get currentUser => _auth.currentUser;

  String? get uid => _auth.currentUser?.uid;

  /// Emits on sign-in and sign-out.
  Stream<User?> authStateChanges() => _auth.authStateChanges();

  /// Live profile document for the signed-in user (includes `coupleId`).
  Stream<AppUser?> watchProfile(String uid) {
    return _db
        .collection('users')
        .doc(uid)
        .snapshots()
        .map((doc) => doc.exists ? AppUser.fromDoc(doc) : null);
  }

  Future<AppUser> signUp({
    required String email,
    required String password,
    required String displayName,
  }) async {
    final cred = await _auth.createUserWithEmailAndPassword(
      email: email.trim(),
      password: password,
    );
    final uid = cred.user!.uid;
    await cred.user!.updateDisplayName(displayName.trim());

    final user = AppUser(uid: uid, displayName: displayName.trim());
    await _db.collection('users').doc(uid).set({
      ...user.toMap(),
      'email': email.trim(),
      'createdAt': FieldValue.serverTimestamp(),
    });
    return user;
  }

  Future<void> signIn({required String email, required String password}) async {
    await _auth.signInWithEmailAndPassword(
      email: email.trim(),
      password: password,
    );
    // Backfill a profile doc if one is somehow missing.
    final uid = _auth.currentUser!.uid;
    final ref = _db.collection('users').doc(uid);
    final snap = await ref.get();
    if (!snap.exists) {
      await ref.set({
        'displayName': _auth.currentUser?.displayName ?? 'Me',
        'photoUrl': null,
        'coupleId': null,
        'email': email.trim(),
        'createdAt': FieldValue.serverTimestamp(),
      });
    }
  }

  /// Renames the signed-in user, in both the auth record and their profile.
  Future<void> updateDisplayName(String displayName) async {
    final trimmed = displayName.trim();
    if (trimmed.isEmpty) return;

    final user = _auth.currentUser;
    if (user == null) return;

    await user.updateDisplayName(trimmed);
    await _db
        .collection('users')
        .doc(user.uid)
        .set({'displayName': trimmed}, SetOptions(merge: true));
  }

  Future<void> sendPasswordReset(String email) =>
      _auth.sendPasswordResetEmail(email: email.trim());

  Future<void> signOut() => _auth.signOut();
}
