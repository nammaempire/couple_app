import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';

import '../models/app_user.dart';
import '../models/couple.dart';
import '../models/daily_question.dart';
import '../services/auth_service.dart';
import '../services/couple_service.dart';
import '../services/daily_question_service.dart';
import '../widgets/name_edit_dialog.dart';

/// Relationship settings and the archive of answered daily questions.
class UsScreen extends StatelessWidget {
  const UsScreen({
    super.key,
    required this.me,
    required this.couple,
    required this.partnerName,
    required this.authService,
    required this.coupleService,
    required this.questionService,
  });

  final AppUser me;
  final Couple couple;
  final String partnerName;
  final AuthService authService;
  final CoupleService coupleService;
  final DailyQuestionService questionService;

  String? get _partnerUid => couple.partnerIdFor(me.uid);

  Future<void> _editMyName(BuildContext context) async {
    final name = await showNameEditDialog(
      context: context,
      title: 'Your name',
      label: 'Name',
      initialValue: me.displayName,
      helperText: 'This is what your partner sees by default.',
    );
    if (name == null || name.isEmpty) return;
    await authService.updateDisplayName(name);
  }

  Future<void> _editPartnerNickname(BuildContext context) async {
    final nickname = await showNameEditDialog(
      context: context,
      title: 'What you call them',
      label: 'Nickname',
      initialValue: couple.nicknameChosenBy(me.uid),
      helperText: 'Only changes what you see. They pick their own name for you.',
      allowEmpty: true,
    );
    if (nickname == null) return;
    await coupleService.setPartnerNickname(
      coupleId: couple.id,
      uid: me.uid,
      nickname: nickname,
    );
  }

  Future<void> _pickDate(
    BuildContext context, {
    required String helpText,
    required DateTime? initial,
    required DateTime firstDate,
    required DateTime lastDate,
    required Future<void> Function(DateTime?) onPicked,
  }) async {
    final picked = await showDatePicker(
      context: context,
      initialDate: initial ?? DateTime.now(),
      firstDate: firstDate,
      lastDate: lastDate,
      helpText: helpText,
    );
    if (picked == null) return;
    await onPicked(picked);
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final startDate = couple.startDate;
    final meetup = couple.nextMeetup;

    return Scaffold(
      appBar: AppBar(title: const Text('Us')),
      body: ListView(
        padding: const EdgeInsets.symmetric(vertical: 8),
        children: [
          const _SectionHeader(label: 'Our dates'),

          ListTile(
            leading: const Icon(Icons.favorite_outline),
            title: const Text('The day we started'),
            subtitle: Text(
              startDate == null
                  ? 'Not set'
                  : DateFormat.yMMMMd().format(startDate),
            ),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => _pickDate(
              context,
              helpText: 'When did you two start?',
              initial: startDate,
              firstDate: DateTime(1970),
              lastDate: DateTime.now(),
              onPicked: (date) =>
                  coupleService.setStartDate(coupleId: couple.id, date: date),
            ),
          ),

          ListTile(
            leading: const Icon(Icons.flight_takeoff),
            title: const Text('Next time we meet'),
            subtitle: Text(
              meetup == null ? 'Not set' : DateFormat.yMMMMd().format(meetup),
            ),
            trailing: meetup == null
                ? const Icon(Icons.chevron_right)
                : IconButton(
                    icon: const Icon(Icons.clear),
                    tooltip: 'Clear',
                    onPressed: () => coupleService.setNextMeetup(
                      coupleId: couple.id,
                      date: null,
                    ),
                  ),
            onTap: () => _pickDate(
              context,
              helpText: 'When do you see each other next?',
              initial: meetup,
              firstDate: DateTime.now(),
              lastDate: DateTime.now().add(const Duration(days: 365 * 5)),
              onPicked: (date) =>
                  coupleService.setNextMeetup(coupleId: couple.id, date: date),
            ),
          ),

          const Divider(height: 32),
          const _SectionHeader(label: 'Names'),

          ListTile(
            leading: const Icon(Icons.favorite),
            title: const Text('What you call them'),
            subtitle: Text(
              couple.nicknameChosenBy(me.uid) ?? partnerName,
            ),
            trailing: const Icon(Icons.edit_outlined),
            enabled: couple.isComplete,
            onTap: () => _editPartnerNickname(context),
          ),

          ListTile(
            leading: const Icon(Icons.local_florist_outlined),
            title: const Text('What they call you'),
            subtitle: Text(
              _partnerUid == null
                  ? 'Not paired yet'
                  : couple.nicknameChosenBy(_partnerUid!) ??
                      'They haven\'t picked one',
            ),
          ),

          const Divider(height: 32),
          const _SectionHeader(label: 'Answered questions'),

          StreamBuilder<List<DailyQuestionEntry>>(
            stream: questionService.watchHistory(couple.id),
            builder: (context, snapshot) {
              final history = snapshot.data ?? const <DailyQuestionEntry>[];
              if (history.isEmpty) {
                return Padding(
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
                  child: Text(
                    'Once you both answer a daily question, it will be kept here.',
                    style: theme.textTheme.bodyMedium?.copyWith(
                      color: theme.colorScheme.onSurfaceVariant,
                    ),
                  ),
                );
              }

              final partnerUid = couple.partnerIdFor(me.uid);
              return Column(
                children: history.map((entry) {
                  return ExpansionTile(
                    title: Text(
                      entry.prompt,
                      style: theme.textTheme.bodyMedium,
                    ),
                    subtitle: Text(
                      entry.dateKey,
                      style: theme.textTheme.labelSmall,
                    ),
                    children: [
                      _ArchivedAnswer(
                        label: 'You',
                        text: entry.answerFor(me.uid)?.text ?? '',
                      ),
                      _ArchivedAnswer(
                        label: partnerName,
                        text: partnerUid == null
                            ? ''
                            : entry.answerFor(partnerUid)?.text ?? '',
                      ),
                    ],
                  );
                }).toList(),
              );
            },
          ),

          const Divider(height: 32),
          const _SectionHeader(label: 'Account'),

          ListTile(
            leading: const Icon(Icons.person_outline),
            title: const Text('Your name'),
            subtitle: Text(me.displayName),
            trailing: const Icon(Icons.edit_outlined),
            onTap: () => _editMyName(context),
          ),

          ListTile(
            leading: const Icon(Icons.qr_code),
            title: const Text('Invite code'),
            subtitle: Text(couple.inviteCode),
            trailing: IconButton(
              icon: const Icon(Icons.copy),
              onPressed: () {
                Clipboard.setData(ClipboardData(text: couple.inviteCode));
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Code copied')),
                );
              },
            ),
          ),

          ListTile(
            leading: Icon(Icons.logout, color: theme.colorScheme.error),
            title: Text(
              'Sign out',
              style: TextStyle(color: theme.colorScheme.error),
            ),
            onTap: authService.signOut,
          ),

          const SizedBox(height: 24),
        ],
      ),
    );
  }
}

class _SectionHeader extends StatelessWidget {
  const _SectionHeader({required this.label});

  final String label;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
      child: Text(
        label.toUpperCase(),
        style: theme.textTheme.labelSmall?.copyWith(
          letterSpacing: 1.2,
          color: theme.colorScheme.primary,
          fontWeight: FontWeight.w700,
        ),
      ),
    );
  }
}

class _ArchivedAnswer extends StatelessWidget {
  const _ArchivedAnswer({required this.label, required this.text});

  final String label;
  final String text;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 0, 20, 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            label,
            style: theme.textTheme.labelSmall?.copyWith(
              color: theme.colorScheme.onSurfaceVariant,
            ),
          ),
          const SizedBox(height: 2),
          Text(text, style: theme.textTheme.bodyMedium),
        ],
      ),
    );
  }
}
