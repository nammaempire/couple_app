import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import '../models/app_user.dart';
import '../services/auth_service.dart';
import 'main_shell.dart';
import 'pairing_screen.dart';
import 'sign_in_screen.dart';

/// Routes between sign-in, pairing, and chat based on auth + profile state.
class AuthGate extends StatelessWidget {
  const AuthGate({super.key, required this.authService});

  final AuthService authService;

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
      stream: authService.authStateChanges(),
      builder: (context, authSnap) {
        if (authSnap.connectionState == ConnectionState.waiting) {
          return const _Splash();
        }

        final user = authSnap.data;
        if (user == null) {
          return SignInScreen(authService: authService);
        }

        return StreamBuilder<AppUser?>(
          stream: authService.watchProfile(user.uid),
          builder: (context, profileSnap) {
            if (profileSnap.connectionState == ConnectionState.waiting) {
              return const _Splash();
            }

            final profile = profileSnap.data;
            if (profile == null || !profile.isPaired) {
              return PairingScreen(
                authService: authService,
                uid: user.uid,
              );
            }

            return MainShell(
              authService: authService,
              me: profile,
              coupleId: profile.coupleId!,
            );
          },
        );
      },
    );
  }
}

class _Splash extends StatelessWidget {
  const _Splash();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              Icons.favorite,
              size: 56,
              color: Theme.of(context).colorScheme.primary,
            ),
            const SizedBox(height: 24),
            const SizedBox(
              width: 24,
              height: 24,
              child: CircularProgressIndicator(strokeWidth: 2),
            ),
          ],
        ),
      ),
    );
  }
}
