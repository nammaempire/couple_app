import 'package:cloud_firestore/cloud_firestore.dart';

/// A signed-in user of the app.
class AppUser {
  final String uid;
  final String displayName;
  final String? photoUrl;

  /// Id of the couple document this user belongs to, or null if unpaired.
  final String? coupleId;

  const AppUser({
    required this.uid,
    required this.displayName,
    this.photoUrl,
    this.coupleId,
  });

  bool get isPaired => coupleId != null;

  factory AppUser.fromDoc(DocumentSnapshot<Map<String, dynamic>> doc) {
    final data = doc.data() ?? <String, dynamic>{};
    return AppUser(
      uid: doc.id,
      displayName: (data['displayName'] as String?) ?? 'Me',
      photoUrl: data['photoUrl'] as String?,
      coupleId: data['coupleId'] as String?,
    );
  }

  Map<String, dynamic> toMap() => {
        'displayName': displayName,
        'photoUrl': photoUrl,
        'coupleId': coupleId,
      };

  AppUser copyWith({String? displayName, String? photoUrl, String? coupleId}) {
    return AppUser(
      uid: uid,
      displayName: displayName ?? this.displayName,
      photoUrl: photoUrl ?? this.photoUrl,
      coupleId: coupleId ?? this.coupleId,
    );
  }
}
