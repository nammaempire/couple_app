import 'package:flutter/material.dart';

import '../agora_config.dart';
import '../models/call_session.dart';
import '../screens/call_screen.dart';
import 'call_service.dart';

/// Places a call and opens the outgoing call screen. Used by both the chat
/// app bar and the Home quick actions. The partner's phone shows the incoming
/// screen from its own signalling listener in `MainShell`.
Future<void> placeCall(
  BuildContext context, {
  required String coupleId,
  required String myUid,
  required String? partnerUid,
  required String partnerName,
  required CallType type,
  CallService? callService,
}) async {
  void showError(String message) {
    if (!context.mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  if (!AgoraConfig.isConfigured) {
    showError('Calling is not set up yet: no Agora App ID.');
    return;
  }
  if (partnerUid == null) {
    showError('You need to be paired before you can call.');
    return;
  }

  final calls = callService ?? CallService();
  try {
    final session = await calls.startCall(
      coupleId: coupleId,
      callerId: myUid,
      calleeId: partnerUid,
      type: type,
    );
    if (!context.mounted) return;

    await Navigator.of(context).push(
      MaterialPageRoute(
        fullscreenDialog: true,
        builder: (_) => CallScreen(
          coupleId: coupleId,
          myUid: myUid,
          partnerName: partnerName,
          session: session,
          callService: calls,
          isOutgoing: true,
        ),
      ),
    );
  } catch (_) {
    showError('Could not start the call.');
  }
}
