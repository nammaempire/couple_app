import 'package:cloud_firestore/cloud_firestore.dart';

/// The kinds of one-tap love message a partner can send.
enum LoveTap {
  thinking('thinking', '💭', 'Thinking of you', 'is thinking of you'),
  love('love', '❤️', 'Love you', 'sent you love'),
  missYou('miss', '🥺', 'Miss you', 'misses you'),
  hug('hug', '🤗', 'Hug', 'sent you a hug'),
  kiss('kiss', '😘', 'Kiss', 'sent you a kiss');

  const LoveTap(this.id, this.emoji, this.label, this.receivedText);

  final String id;
  final String emoji;
  final String label;

  /// Completes "[partner name] …" on the receiving phone.
  final String receivedText;

  /// Older nudges have no kind and were all "thinking of you".
  static LoveTap fromId(String? id) {
    for (final tap in LoveTap.values) {
      if (tap.id == id) return tap;
    }
    return LoveTap.thinking;
  }
}

/// A one-tap love message ("nudge") that buzzes the partner's phone.
class Nudge {
  final String id;
  final String senderId;
  final DateTime? sentAt;
  final LoveTap kind;

  const Nudge({
    required this.id,
    required this.senderId,
    this.sentAt,
    this.kind = LoveTap.thinking,
  });

  /// Nudges older than this are treated as history, not a live buzz, so
  /// reopening the app does not replay old ones.
  static const freshWindow = Duration(minutes: 2);

  bool get isFresh {
    final at = sentAt;
    if (at == null) return false;
    return DateTime.now().difference(at) < freshWindow;
  }
}

/// Sends and listens for nudges at `couples/{coupleId}/nudges`.
class NudgeService {
  NudgeService({FirebaseFirestore? firestore})
      : _db = firestore ?? FirebaseFirestore.instance;

  final FirebaseFirestore _db;

  CollectionReference<Map<String, dynamic>> _nudges(String coupleId) =>
      _db.collection('couples').doc(coupleId).collection('nudges');

  Future<void> send({
    required String coupleId,
    required String senderId,
    LoveTap kind = LoveTap.thinking,
  }) {
    return _nudges(coupleId).add({
      'senderId': senderId,
      'sentAt': FieldValue.serverTimestamp(),
      'kind': kind.id,
    });
  }

  /// The most recent nudge, whoever sent it.
  Stream<Nudge?> watchLatest(String coupleId) {
    return _nudges(coupleId)
        .orderBy('sentAt', descending: true)
        .limit(1)
        .snapshots()
        .map((snap) {
      if (snap.docs.isEmpty) return null;
      final doc = snap.docs.first;
      final data = doc.data();
      return Nudge(
        id: doc.id,
        senderId: (data['senderId'] as String?) ?? '',
        sentAt: (data['sentAt'] as Timestamp?)?.toDate(),
        kind: LoveTap.fromId(data['kind'] as String?),
      );
    });
  }

  /// How many nudges each partner has sent, for the "Us" tab.
  Future<int> countSince(String coupleId, DateTime since) async {
    final snap = await _nudges(coupleId)
        .where('sentAt', isGreaterThan: Timestamp.fromDate(since))
        .count()
        .get();
    return snap.count ?? 0;
  }
}
