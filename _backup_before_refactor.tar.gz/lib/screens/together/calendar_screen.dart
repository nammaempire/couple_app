import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../../models/app_user.dart';
import '../../models/calendar_event.dart';
import '../../models/couple.dart';
import '../../services/event_service.dart';
import 'event_editor_screen.dart';

/// The shared calendar: a month grid, the selected day's events and what is
/// coming up. Birthdays, the anniversary and the next meetup appear
/// automatically.
class CalendarScreen extends StatefulWidget {
  const CalendarScreen({
    super.key,
    required this.couple,
    required this.me,
    required this.partner,
    required this.partnerName,
    required this.eventService,
  });

  final Couple couple;
  final AppUser me;
  final AppUser? partner;
  final String partnerName;
  final EventService eventService;

  @override
  State<CalendarScreen> createState() => _CalendarScreenState();
}

class _CalendarScreenState extends State<CalendarScreen> {
  late final Stream<List<CalendarEvent>> _events =
      widget.eventService.watchEvents(widget.couple.id, widget.me.uid);

  late DateTime _month = DateTime(DateTime.now().year, DateTime.now().month);
  late DateTime _selected = _today;

  DateTime get _today {
    final n = DateTime.now();
    return DateTime(n.year, n.month, n.day);
  }

  List<CalendarEvent> _withAutomatic(List<CalendarEvent> stored) => [
        ...stored,
        ...EventService.automaticEvents(
          couple: widget.couple,
          me: widget.me,
          partner: widget.partner,
          partnerName: widget.partnerName,
        ),
      ];

  void _openEditor({CalendarEvent? event, DateTime? day}) {
    Navigator.of(context).push(
      MaterialPageRoute(
        fullscreenDialog: true,
        builder: (_) => EventEditorScreen(
          coupleId: widget.couple.id,
          myUid: widget.me.uid,
          eventService: widget.eventService,
          event: event,
          initialDay: day ?? _selected,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<List<CalendarEvent>>(
      stream: _events,
      builder: (context, snapshot) {
        final events = _withAutomatic(snapshot.data ?? const []);
        final dayEvents = _eventsOn(events, _selected);
        final upcoming = _upcoming(events);

        return Scaffold(
          floatingActionButton: FloatingActionButton.extended(
            heroTag: 'add-event',
            onPressed: () => _openEditor(),
            icon: const Icon(Icons.add),
            label: const Text('Add event'),
          ),
          body: ListView(
            padding: const EdgeInsets.only(bottom: 96),
            children: [
              _MonthHeader(
                month: _month,
                onPrevious: () => setState(() =>
                    _month = DateTime(_month.year, _month.month - 1)),
                onNext: () => setState(() =>
                    _month = DateTime(_month.year, _month.month + 1)),
                onToday: () => setState(() {
                  _month = DateTime(_today.year, _today.month);
                  _selected = _today;
                }),
              ),
              _MonthGrid(
                month: _month,
                selected: _selected,
                today: _today,
                events: events,
                onSelect: (day) => setState(() => _selected = day),
              ),
              const Divider(height: 24),
              _DaySection(
                day: _selected,
                events: dayEvents,
                onOpen: (entry) => _showDetails(entry.$1, entry.$2),
                onAdd: () => _openEditor(day: _selected),
              ),
              if (upcoming.isNotEmpty) ...[
                const _SectionTitle(label: 'Upcoming'),
                for (final (event, at) in upcoming)
                  _EventTile(
                    event: event,
                    when: at,
                    showDate: true,
                    onTap: () => _showDetails(event, at),
                  ),
              ],
            ],
          ),
        );
      },
    );
  }

  List<(CalendarEvent, DateTime)> _eventsOn(
    List<CalendarEvent> events,
    DateTime day,
  ) {
    final list = <(CalendarEvent, DateTime)>[];
    for (final e in events) {
      for (final when in e.occurrencesBetween(day, day)) {
        list.add((e, when));
      }
    }
    list.sort((a, b) => a.$2.compareTo(b.$2));
    return list;
  }

  /// The next 60 days, soonest first, at most 8.
  List<(CalendarEvent, DateTime)> _upcoming(List<CalendarEvent> events) {
    final from = _today;
    final to = from.add(const Duration(days: 60));
    final list = <(CalendarEvent, DateTime)>[];
    for (final e in events) {
      for (final when in e.occurrencesBetween(from, to)) {
        if (!DateTime(when.year, when.month, when.day).isBefore(from)) {
          list.add((e, when));
        }
      }
    }
    list.sort((a, b) => a.$2.compareTo(b.$2));
    return list.take(8).toList();
  }

  Future<void> _showDetails(CalendarEvent event, DateTime at) async {
    final action = await showModalBottomSheet<String>(
      context: context,
      showDragHandle: true,
      isScrollControlled: true,
      builder: (sheetContext) => _EventDetails(
        event: event,
        when: at,
        canEdit: !event.isAutomatic &&
            (!event.isPrivate || event.createdBy == widget.me.uid),
      ),
    );
    if (!mounted) return;
    if (action == 'edit') _openEditor(event: event);
    if (action == 'delete') {
      try {
        await widget.eventService.delete(
          coupleId: widget.couple.id,
          eventId: event.id,
        );
      } catch (_) {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Could not delete that event.')),
        );
      }
    }
  }
}

class _MonthHeader extends StatelessWidget {
  const _MonthHeader({
    required this.month,
    required this.onPrevious,
    required this.onNext,
    required this.onToday,
  });

  final DateTime month;
  final VoidCallback onPrevious;
  final VoidCallback onNext;
  final VoidCallback onToday;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Padding(
      padding: const EdgeInsets.fromLTRB(8, 8, 8, 0),
      child: Row(
        children: [
          IconButton(
            tooltip: 'Previous month',
            icon: const Icon(Icons.chevron_left),
            onPressed: onPrevious,
          ),
          Expanded(
            child: Text(
              DateFormat.yMMMM().format(month),
              textAlign: TextAlign.center,
              style: theme.textTheme.titleLarge
                  ?.copyWith(fontWeight: FontWeight.w600),
            ),
          ),
          TextButton(onPressed: onToday, child: const Text('Today')),
          IconButton(
            tooltip: 'Next month',
            icon: const Icon(Icons.chevron_right),
            onPressed: onNext,
          ),
        ],
      ),
    );
  }
}

class _MonthGrid extends StatelessWidget {
  const _MonthGrid({
    required this.month,
    required this.selected,
    required this.today,
    required this.events,
    required this.onSelect,
  });

  final DateTime month;
  final DateTime selected;
  final DateTime today;
  final List<CalendarEvent> events;
  final ValueChanged<DateTime> onSelect;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final localizations = MaterialLocalizations.of(context);
    final firstWeekday = localizations.firstDayOfWeekIndex; // 0 = Sunday

    final first = DateTime(month.year, month.month);
    final daysInMonth = DateTime(month.year, month.month + 1, 0).day;
    // DateTime.weekday: Mon=1..Sun=7 → 0..6 with Sunday = 0.
    final leading = (first.weekday % 7 - firstWeekday + 7) % 7;
    final cells = leading + daysInMonth;
    final rows = (cells / 7).ceil();

    // Which days in this month have events, for the dots.
    final lastDay = DateTime(month.year, month.month, daysInMonth);
    final marks = <int, List<EventType>>{};
    for (final e in events) {
      for (final occurrence in e.occurrencesBetween(first, lastDay)) {
        for (var i = 0; i < e.spanDays; i++) {
          final d = DateTime(
            occurrence.year,
            occurrence.month,
            occurrence.day + i,
          );
          if (d.month != month.month || d.year != month.year) continue;
          (marks[d.day] ??= []).add(e.type);
        }
      }
    }

    final weekdayNames = localizations.narrowWeekdays;

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      child: Column(
        children: [
          Row(
            children: [
              for (var i = 0; i < 7; i++)
                Expanded(
                  child: Center(
                    child: Text(
                      weekdayNames[(i + firstWeekday) % 7],
                      style: theme.textTheme.labelMedium?.copyWith(
                        color: theme.colorScheme.onSurfaceVariant,
                      ),
                    ),
                  ),
                ),
            ],
          ),
          const SizedBox(height: 6),
          for (var row = 0; row < rows; row++)
            Row(
              children: [
                for (var col = 0; col < 7; col++)
                  Expanded(
                    child: _dayCell(
                      context,
                      row * 7 + col - leading + 1,
                      daysInMonth,
                      marks,
                    ),
                  ),
              ],
            ),
        ],
      ),
    );
  }

  Widget _dayCell(
    BuildContext context,
    int dayNumber,
    int daysInMonth,
    Map<int, List<EventType>> marks,
  ) {
    if (dayNumber < 1 || dayNumber > daysInMonth) {
      return const SizedBox(height: 48);
    }
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;
    final day = DateTime(month.year, month.month, dayNumber);
    final isSelected = day == selected;
    final isToday = day == today;
    final types = marks[dayNumber] ?? const <EventType>[];

    return Semantics(
      button: true,
      selected: isSelected,
      label: '${DateFormat.MMMMd().format(day)}'
          '${types.isEmpty ? '' : ', ${types.length} events'}',
      child: InkWell(
        onTap: () => onSelect(day),
        borderRadius: BorderRadius.circular(14),
        child: SizedBox(
          height: 48,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                width: 32,
                height: 32,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: isSelected ? scheme.primary : null,
                  border: isToday && !isSelected
                      ? Border.all(color: scheme.primary, width: 1.5)
                      : null,
                ),
                child: Text(
                  '$dayNumber',
                  style: theme.textTheme.bodyMedium?.copyWith(
                    color: isSelected ? scheme.onPrimary : null,
                    fontWeight:
                        isToday || isSelected ? FontWeight.w700 : null,
                  ),
                ),
              ),
              const SizedBox(height: 3),
              SizedBox(
                height: 5,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    for (final t in types.take(3))
                      Container(
                        width: 5,
                        height: 5,
                        margin: const EdgeInsets.symmetric(horizontal: 1),
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: _dotColor(t, scheme),
                        ),
                      ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  static Color _dotColor(EventType t, ColorScheme scheme) => switch (t) {
        EventType.birthday => const Color(0xFFE8945C),
        EventType.anniversary => scheme.primary,
        EventType.trip => const Color(0xFF5C9BE8),
        EventType.dateNight => const Color(0xFFC05CE8),
        EventType.meetup => const Color(0xFF3BBF6B),
        EventType.custom => scheme.outline,
      };
}

class _DaySection extends StatelessWidget {
  const _DaySection({
    required this.day,
    required this.events,
    required this.onOpen,
    required this.onAdd,
  });

  final DateTime day;
  final List<(CalendarEvent, DateTime)> events;
  final ValueChanged<(CalendarEvent, DateTime)> onOpen;
  final VoidCallback onAdd;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        _SectionTitle(label: DateFormat.MMMMEEEEd().format(day)),
        if (events.isEmpty)
          Padding(
            padding: const EdgeInsets.fromLTRB(20, 0, 20, 8),
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    'Nothing planned.',
                    style: theme.textTheme.bodyMedium?.copyWith(
                      color: theme.colorScheme.onSurfaceVariant,
                    ),
                  ),
                ),
                TextButton.icon(
                  onPressed: onAdd,
                  icon: const Icon(Icons.add, size: 18),
                  label: const Text('Plan something'),
                ),
              ],
            ),
          )
        else
          for (final entry in events)
            _EventTile(
              event: entry.$1,
              when: entry.$2,
              showDate: false,
              onTap: () => onOpen(entry),
            ),
      ],
    );
  }
}

class _SectionTitle extends StatelessWidget {
  const _SectionTitle({required this.label});

  final String label;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 6),
      child: Text(
        label,
        style: theme.textTheme.titleSmall?.copyWith(
          fontWeight: FontWeight.w700,
          color: theme.colorScheme.primary,
        ),
      ),
    );
  }
}

class _EventTile extends StatelessWidget {
  const _EventTile({
    required this.event,
    required this.when,
    required this.showDate,
    required this.onTap,
  });

  final CalendarEvent event;
  final DateTime when;
  final bool showDate;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final parts = <String>[
      if (showDate) DateFormat.MMMEd().format(when),
      if (!event.allDay) DateFormat.jm().format(when),
      if (event.spanDays > 1) '${event.spanDays} days',
      if (event.location != null) event.location!,
    ];

    return ListTile(
      onTap: onTap,
      leading: CircleAvatar(
        backgroundColor: theme.colorScheme.primaryContainer,
        child: Text(event.type.emoji),
      ),
      title: Text(event.title.isEmpty ? event.type.label : event.title),
      subtitle: parts.isEmpty ? null : Text(parts.join(' · ')),
      trailing: event.isPrivate
          ? Tooltip(
              message: 'Only you can see this',
              child: Icon(
                Icons.lock_outline,
                size: 18,
                color: theme.colorScheme.onSurfaceVariant,
              ),
            )
          : null,
    );
  }
}

/// Bottom sheet with an event's details. Pops with 'edit' or 'delete'.
class _EventDetails extends StatelessWidget {
  const _EventDetails({
    required this.event,
    required this.when,
    required this.canEdit,
  });

  final CalendarEvent event;
  final DateTime when;
  final bool canEdit;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final end = event.end;

    String dateLine() {
      final date = DateFormat.yMMMMEEEEd().format(when);
      if (event.spanDays > 1 && end != null) {
        final last = DateTime(when.year, when.month,
            when.day + event.spanDays - 1);
        return '$date – ${DateFormat.MMMMd().format(last)}';
      }
      if (event.allDay) return date;
      return '$date · ${DateFormat.jm().format(when)}';
    }

    Widget row(IconData icon, String text) => Padding(
          padding: const EdgeInsets.only(bottom: 10),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Icon(icon, size: 20, color: theme.colorScheme.primary),
              const SizedBox(width: 12),
              Expanded(child: Text(text, style: theme.textTheme.bodyLarge)),
            ],
          ),
        );

    return SafeArea(
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(24, 0, 24, 16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              '${event.type.emoji}  '
              '${event.title.isEmpty ? event.type.label : event.title}',
              style: theme.textTheme.titleLarge
                  ?.copyWith(fontWeight: FontWeight.w700),
            ),
            const SizedBox(height: 16),
            row(Icons.event_outlined, dateLine()),
            if (event.repeatYearly) row(Icons.repeat, 'Every year'),
            if (event.location != null)
              row(Icons.place_outlined, event.location!),
            if (event.budget != null)
              row(
                Icons.account_balance_wallet_outlined,
                'Budget ${NumberFormat.currency(locale: 'en_IN', symbol: '₹', decimalDigits: 0).format(event.budget)}',
              ),
            if (event.reminder != ReminderOption.none)
              row(Icons.notifications_none, event.reminder.label),
            if (event.isPrivate)
              row(Icons.lock_outline, 'Private: only you can see this'),
            if (event.notes.isNotEmpty) row(Icons.notes, event.notes),
            if (event.isAutomatic)
              Text(
                'Added automatically from your profiles and dates. Change it '
                'in the Us tab.',
                style: theme.textTheme.bodySmall?.copyWith(
                  color: theme.colorScheme.onSurfaceVariant,
                ),
              ),
            if (canEdit) ...[
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: () => Navigator.pop(context, 'delete'),
                      icon: const Icon(Icons.delete_outline),
                      label: const Text('Delete'),
                      style: OutlinedButton.styleFrom(
                        minimumSize: const Size.fromHeight(48),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: FilledButton.icon(
                      onPressed: () => Navigator.pop(context, 'edit'),
                      icon: const Icon(Icons.edit_outlined),
                      label: const Text('Edit'),
                    ),
                  ),
                ],
              ),
            ],
          ],
        ),
      ),
    );
  }
}
