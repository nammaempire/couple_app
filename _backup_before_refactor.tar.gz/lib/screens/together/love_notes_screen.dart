import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../../models/app_user.dart';
import '../../models/couple.dart';
import '../../models/love_note.dart';
import '../../services/love_note_service.dart';
import 'note_composer_screen.dart';
import 'note_reader_screen.dart';

/// Love notes: letters that arrive now or on a date, and "Open when…"
/// envelopes to keep for the right moment.
class LoveNotesScreen extends StatefulWidget {
  const LoveNotesScreen({
    super.key,
    required this.couple,
    required this.me,
    required this.partner,
    required this.partnerName,
    required this.noteService,
  });

  final Couple couple;
  final AppUser me;
  final AppUser? partner;
  final String partnerName;
  final LoveNoteService noteService;

  @override
  State<LoveNotesScreen> createState() => _LoveNotesScreenState();
}

class _LoveNotesScreenState extends State<LoveNotesScreen> {
  late final Stream<List<LoveNote>> _notes =
      widget.noteService.watchNotes(widget.couple.id);

  String? get _partnerUid => widget.couple.partnerIdFor(widget.me.uid);

  void _compose({OpenWhen? template}) {
    final partnerUid = _partnerUid;
    if (partnerUid == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Pair with your partner first.')),
      );
      return;
    }
    Navigator.of(context).push(
      MaterialPageRoute(
        fullscreenDialog: true,
        builder: (_) => NoteComposerScreen(
          coupleId: widget.couple.id,
          myUid: widget.me.uid,
          partnerUid: partnerUid,
          partnerName: widget.partnerName,
          partnerBirthday: widget.partner?.birthday,
          anniversary: widget.couple.startDate,
          noteService: widget.noteService,
          template: template,
        ),
      ),
    );
  }

  void _open(LoveNote note) {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => NoteReaderScreen(
          coupleId: widget.couple.id,
          note: note,
          myUid: widget.me.uid,
          partnerName: widget.partnerName,
          noteService: widget.noteService,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<List<LoveNote>>(
      stream: _notes,
      builder: (context, snapshot) {
        final now = DateTime.now();
        final notes = snapshot.data ?? const <LoveNote>[];
        final received =
            notes.where((n) => n.recipientId == widget.me.uid).toList();
        final sent = notes.where((n) => n.senderId == widget.me.uid).toList();

        final waiting = received
            .where((n) => n.isScheduled(now))
            .toList()
          ..sort((a, b) => a.deliverAt.compareTo(b.deliverAt));
        final envelopes = received
            .where((n) => n.kind == NoteKind.openWhen && n.isDelivered(now))
            .toList();
        final letters = received
            .where((n) => n.kind == NoteKind.letter && n.isDelivered(now))
            .toList();

        return Scaffold(
          floatingActionButton: FloatingActionButton.extended(
            heroTag: 'write-note',
            onPressed: () => _compose(),
            icon: const Icon(Icons.edit_outlined),
            label: const Text('Write a note'),
          ),
          body: !snapshot.hasData && !snapshot.hasError
              ? const Center(child: CircularProgressIndicator())
              : ListView(
                  padding: const EdgeInsets.fromLTRB(16, 12, 16, 96),
                  children: [
                    if (notes.isEmpty)
                      _Intro(
                        partnerName: widget.partnerName,
                        onTemplate: (t) => _compose(template: t),
                      ),
                    if (waiting.isNotEmpty) ...[
                      _Header('On its way to you'),
                      for (final n in waiting)
                        _NoteTile(
                          note: n,
                          subtitle: 'From ${widget.partnerName} · '
                              '${_arrives(n.deliverAt, now)}',
                          sealed: true,
                          onTap: () => _open(n),
                        ),
                    ],
                    if (envelopes.isNotEmpty) ...[
                      _Header('Open when…'),
                      _EnvelopeGrid(notes: envelopes, onOpen: _open),
                    ],
                    if (letters.isNotEmpty) ...[
                      _Header('For you'),
                      for (final n in letters)
                        _NoteTile(
                          note: n,
                          subtitle: 'From ${widget.partnerName} · '
                              '${DateFormat.yMMMd().format(n.deliverAt)}',
                          unread: !n.isOpened,
                          onTap: () => _open(n),
                        ),
                    ],
                    if (sent.isNotEmpty) ...[
                      _Header('Sent by you'),
                      for (final n in sent)
                        _NoteTile(
                          note: n,
                          subtitle: _sentStatus(n, now),
                          onTap: () => _open(n),
                        ),
                    ],
                    if (notes.isNotEmpty) ...[
                      _Header('Write an “Open when…” note'),
                      _TemplateRow(onTemplate: (t) => _compose(template: t)),
                    ],
                  ],
                ),
        );
      },
    );
  }

  static String _arrives(DateTime at, DateTime now) {
    final days = DateTime(at.year, at.month, at.day)
        .difference(DateTime(now.year, now.month, now.day))
        .inDays;
    if (days <= 0) return 'arrives at ${DateFormat.jm().format(at)}';
    if (days == 1) return 'arrives tomorrow';
    if (days < 7) return 'arrives in $days days';
    return 'arrives ${DateFormat.MMMd().format(at)}';
  }

  String _sentStatus(LoveNote n, DateTime now) {
    if (n.isScheduled(now)) {
      return 'To ${widget.partnerName} · ${_arrives(n.deliverAt, now)}';
    }
    if (n.isOpened) {
      return 'Opened ${DateFormat.MMMd().format(n.openedAt!)}';
    }
    return n.kind == NoteKind.openWhen
        ? 'Waiting for the right moment'
        : 'Delivered · not opened yet';
  }
}

class _Header extends StatelessWidget {
  const _Header(this.label);

  final String label;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Padding(
      padding: const EdgeInsets.fromLTRB(4, 16, 4, 8),
      child: Text(
        label,
        style: theme.textTheme.titleSmall?.copyWith(
          fontWeight: FontWeight.w700,
          color: theme.colorScheme.primary,
        ),
      ),
    );
  }
}

class _Intro extends StatelessWidget {
  const _Intro({required this.partnerName, required this.onTemplate});

  final String partnerName;
  final ValueChanged<OpenWhen> onTemplate;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: theme.colorScheme.primaryContainer.withValues(alpha: .6),
            borderRadius: BorderRadius.circular(24),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('💌', style: TextStyle(fontSize: 36)),
              const SizedBox(height: 8),
              Text(
                'Leave $partnerName a love note',
                style: theme.textTheme.titleLarge
                    ?.copyWith(fontWeight: FontWeight.w700),
              ),
              const SizedBox(height: 6),
              Text(
                'Send it now, schedule it for a special day, or leave an '
                '“Open when…” envelope for when they need it. Scheduled '
                'notes stay sealed until they arrive.',
                style: theme.textTheme.bodyMedium,
              ),
            ],
          ),
        ),
        const SizedBox(height: 8),
        _TemplateRow(onTemplate: onTemplate),
      ],
    );
  }
}

class _TemplateRow extends StatelessWidget {
  const _TemplateRow({required this.onTemplate});

  final ValueChanged<OpenWhen> onTemplate;

  @override
  Widget build(BuildContext context) {
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: [
        for (final t in OpenWhen.values)
          ActionChip(
            avatar: Text(t.emoji),
            label: Text(t.label),
            onPressed: () => onTemplate(t),
          ),
      ],
    );
  }
}

class _NoteTile extends StatelessWidget {
  const _NoteTile({
    required this.note,
    required this.subtitle,
    required this.onTap,
    this.sealed = false,
    this.unread = false,
  });

  final LoveNote note;
  final String subtitle;
  final VoidCallback onTap;
  final bool sealed;
  final bool unread;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;

    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Material(
        color: unread
            ? scheme.primaryContainer.withValues(alpha: .7)
            : scheme.surfaceContainerHighest.withValues(alpha: .5),
        borderRadius: BorderRadius.circular(18),
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(18),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 12, 12, 12),
            child: Row(
              children: [
                Text(sealed ? '🔒' : note.emoji,
                    style: const TextStyle(fontSize: 26)),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        note.envelopeTitle,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: theme.textTheme.titleSmall?.copyWith(
                          fontWeight: unread ? FontWeight.w800 : FontWeight.w600,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        subtitle,
                        style: theme.textTheme.bodySmall?.copyWith(
                          color: scheme.onSurfaceVariant,
                        ),
                      ),
                    ],
                  ),
                ),
                if (note.hasVoice)
                  Padding(
                    padding: const EdgeInsets.only(left: 8),
                    child: Icon(Icons.mic_none, size: 18, color: scheme.primary),
                  ),
                if (unread)
                  Container(
                    margin: const EdgeInsets.only(left: 8),
                    width: 10,
                    height: 10,
                    decoration: BoxDecoration(
                      color: scheme.primary,
                      shape: BoxShape.circle,
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

/// Sealed "Open when…" envelopes, two per row.
class _EnvelopeGrid extends StatelessWidget {
  const _EnvelopeGrid({required this.notes, required this.onOpen});

  final List<LoveNote> notes;
  final ValueChanged<LoveNote> onOpen;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;
    return GridView.count(
      crossAxisCount: 2,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      mainAxisSpacing: 10,
      crossAxisSpacing: 10,
      childAspectRatio: 1.25,
      children: [
        for (final n in notes)
          Material(
            color: n.isOpened
                ? scheme.surfaceContainerHighest.withValues(alpha: .5)
                : scheme.primaryContainer,
            borderRadius: BorderRadius.circular(20),
            child: InkWell(
              onTap: () => onOpen(n),
              borderRadius: BorderRadius.circular(20),
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Text(n.emoji, style: const TextStyle(fontSize: 26)),
                        const Spacer(),
                        Icon(
                          n.isOpened ? Icons.drafts_outlined : Icons.mail,
                          size: 18,
                          color: scheme.primary,
                        ),
                      ],
                    ),
                    const Spacer(),
                    Text(
                      n.envelopeTitle,
                      maxLines: 3,
                      overflow: TextOverflow.ellipsis,
                      style: theme.textTheme.titleSmall
                          ?.copyWith(fontWeight: FontWeight.w600),
                    ),
                  ],
                ),
              ),
            ),
          ),
      ],
    );
  }
}
