import 'package:flutter/material.dart';

import '../../models/app_user.dart';
import '../../models/couple.dart';
import '../../services/event_service.dart';
import '../../services/love_note_service.dart';
import 'calendar_screen.dart';
import 'love_notes_screen.dart';

/// The Together tab: planning your life as a couple. Calendar and love
/// notes today; the date planner, bucket list, places and expenses join
/// here later.
class TogetherScreen extends StatefulWidget {
  const TogetherScreen({
    super.key,
    required this.couple,
    required this.me,
    required this.partner,
    required this.partnerName,
    required this.eventService,
    required this.noteService,
    this.initialTab = 0,
  });

  final Couple couple;
  final AppUser me;
  final AppUser? partner;
  final String partnerName;
  final EventService eventService;
  final LoveNoteService noteService;
  final int initialTab;

  @override
  State<TogetherScreen> createState() => TogetherScreenState();
}

class TogetherScreenState extends State<TogetherScreen>
    with SingleTickerProviderStateMixin {
  late final TabController _tabs = TabController(
    length: 2,
    vsync: this,
    initialIndex: widget.initialTab,
  );

  /// Lets the shell jump straight to a sub-tab (e.g. from Home).
  void showTab(int index) => _tabs.animateTo(index);

  @override
  void dispose() {
    _tabs.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Together'),
        bottom: TabBar(
          controller: _tabs,
          tabs: const [
            Tab(icon: Icon(Icons.calendar_month_outlined), text: 'Calendar'),
            Tab(icon: Icon(Icons.mail_outline), text: 'Love notes'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabs,
        children: [
          CalendarScreen(
            couple: widget.couple,
            me: widget.me,
            partner: widget.partner,
            partnerName: widget.partnerName,
            eventService: widget.eventService,
          ),
          LoveNotesScreen(
            couple: widget.couple,
            me: widget.me,
            partner: widget.partner,
            partnerName: widget.partnerName,
            noteService: widget.noteService,
          ),
        ],
      ),
    );
  }
}
