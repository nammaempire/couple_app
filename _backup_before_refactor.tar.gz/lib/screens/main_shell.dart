import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../models/app_user.dart';
import '../models/calendar_event.dart';
import '../models/call_session.dart';
import '../models/couple.dart';
import '../models/love_note.dart';
import '../services/auth_service.dart';
import '../services/call_service.dart';
import '../services/couple_service.dart';
import '../services/daily_question_service.dart';
import '../services/event_service.dart';
import '../services/love_note_service.dart';
import '../services/memory_service.dart';
import '../services/mood_service.dart';
import '../services/nudge_service.dart';
import '../services/reminder_service.dart';
import 'chat_screen.dart';
import 'home_screen.dart';
import 'incoming_call_screen.dart';
import 'memories/memories_screen.dart';
import 'together/together_screen.dart';
import 'us_screen.dart';

/// Bottom-navigation shell: Home, Chat, Memories, Together and Us.
///
/// It owns the couple stream, the incoming-nudge and call listeners, and
/// the calendar/notes subscriptions that drive on-device reminders, so all
/// of them work no matter which tab is on screen.
class MainShell extends StatefulWidget {
  const MainShell({
    super.key,
    required this.authService,
    required this.me,
    required this.coupleId,
  });

  final AuthService authService;
  final AppUser me;
  final String coupleId;

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  final _couples = CoupleService();
  final _moods = MoodService();
  final _questions = DailyQuestionService();
  final _nudges = NudgeService();
  final _calls = CallService();
  final _memoryService = MemoryService();
  final _eventService = EventService();
  final _noteService = LoveNoteService();

  static const _homeTab = 0;
  static const _chatTab = 1;
  static const _memoriesTab = 2;
  static const _togetherTab = 3;

  int _tabIndex = _homeTab;
  final _togetherKey = GlobalKey<TogetherScreenState>();

  /// Calendar events this user can see, and love notes addressed to them.
  /// Used by Home's "Coming up" and to schedule reminders on this phone.
  List<CalendarEvent> _events = const [];
  List<LoveNote> _incomingNotes = const [];
  StreamSubscription<List<CalendarEvent>>? _eventsSub;
  StreamSubscription<List<LoveNote>>? _notesSub;
  Couple? _latestCouple;
  Timer? _reminderDebounce;
  String? _lastReminderSignature;

  /// Created once; building it inside `build` would open a new Firestore
  /// listener on every tab switch.
  late final Stream<Couple?> _coupleStream =
      _couples.watchCouple(widget.coupleId);

  /// The partner's live profile. A nickname set by this user overrides
  /// their display name.
  AppUser? _partner;
  String? _watchingPartner;
  StreamSubscription<AppUser?>? _partnerSub;

  String get _partnerRealName => _partner?.displayName ?? 'Your partner';

  /// The name last rendered, so the nudge listener can use it outside build.
  String _shownPartnerName = 'Your partner';

  /// What this user should see their partner called.
  String _displayNameFor(Couple couple) =>
      couple.nicknameChosenBy(widget.me.uid) ?? _partnerRealName;

  StreamSubscription<Nudge?>? _nudgeSub;
  String? _lastNudgeId;

  StreamSubscription<CallSession?>? _callSub;

  /// True while an incoming-call screen is on top, so a rebuild of the
  /// stream does not push a second copy of it.
  bool _showingIncomingCall = false;

  @override
  void initState() {
    super.initState();
    _listenForNudges();
    _listenForCalls();
    _listenForPlans();
  }

  @override
  void didUpdateWidget(covariant MainShell oldWidget) {
    super.didUpdateWidget(oldWidget);
    // Notification preferences or birthdays may have changed.
    _scheduleReminderSync();
  }

  void _listenForPlans() {
    _eventsSub = _eventService
        .watchEvents(widget.coupleId, widget.me.uid)
        .listen((events) {
      if (!mounted) return;
      setState(() => _events = events);
      _scheduleReminderSync();
    }, onError: (_) {});

    _notesSub = _noteService.watchNotes(widget.coupleId).listen((notes) {
      if (!mounted) return;
      setState(() {
        _incomingNotes =
            notes.where((n) => n.recipientId == widget.me.uid).toList();
      });
      _scheduleReminderSync();
    }, onError: (_) {});
  }

  /// Re-plans this phone's reminders shortly after anything they depend on
  /// changes, batching bursts of updates.
  void _scheduleReminderSync() {
    _reminderDebounce?.cancel();
    _reminderDebounce = Timer(const Duration(seconds: 2), _syncReminders);
  }

  Future<void> _syncReminders() async {
    final couple = _latestCouple;
    if (!mounted || couple == null) return;

    final reminders = ReminderPlanner.plan(
      now: DateTime.now(),
      events: [
        ..._events,
        ...EventService.automaticEvents(
          couple: couple,
          me: widget.me,
          partner: _partner,
          partnerName: _shownPartnerName,
        ),
      ],
      incomingNotes: _incomingNotes,
      prefs: widget.me.notificationPrefs,
      partnerName: _shownPartnerName,
    );

    // Skip the platform work when nothing changed.
    final signature = reminders
        .map((r) => '${r.id}@${r.at.millisecondsSinceEpoch}:${r.title}')
        .join('|');
    if (signature == _lastReminderSignature) return;
    final ok = await ReminderService.instance.sync(reminders);
    // Remembered only once applied, so a failed sync is retried next time.
    if (ok) _lastReminderSignature = signature;
  }

  @override
  void dispose() {
    _nudgeSub?.cancel();
    _callSub?.cancel();
    _partnerSub?.cancel();
    _eventsSub?.cancel();
    _notesSub?.cancel();
    _reminderDebounce?.cancel();
    super.dispose();
  }

  void _listenForCalls() {
    _callSub = _calls.watchCall(widget.coupleId).listen((session) async {
      if (!mounted || session == null) return;

      // Only the callee gets the incoming screen, and only while it is still
      // ringing and has not sat unanswered past the timeout.
      if (!session.isIncomingFor(widget.me.uid)) return;
      if (_showingIncomingCall || session.hasRungOut) return;

      _showingIncomingCall = true;
      await Navigator.of(context).push(
        MaterialPageRoute(
          fullscreenDialog: true,
          builder: (_) => IncomingCallScreen(
            coupleId: widget.coupleId,
            myUid: widget.me.uid,
            partnerName: _shownPartnerName,
            session: session,
            callService: _calls,
          ),
        ),
      );
      _showingIncomingCall = false;
    });
  }

  void _listenForNudges() {
    _nudgeSub = _nudges.watchLatest(widget.coupleId).listen((nudge) {
      if (nudge == null || !mounted) return;

      // Ignore the first value on start-up and our own nudges, and only react
      // to ones that arrived just now rather than replaying history.
      final isFirstEmission = _lastNudgeId == null;
      final isNew = nudge.id != _lastNudgeId;
      _lastNudgeId = nudge.id;

      if (isFirstEmission || !isNew) return;
      if (nudge.senderId == widget.me.uid) return;
      if (!nudge.isFresh) return;

      _playNudge(nudge.kind);
    });
  }

  Future<void> _playNudge(LoveTap kind) async {
    await HapticFeedback.heavyImpact();
    await Future<void>.delayed(const Duration(milliseconds: 140));
    await HapticFeedback.heavyImpact();

    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        behavior: SnackBarBehavior.floating,
        content: Text('${kind.emoji}  $_shownPartnerName ${kind.receivedText}'),
        duration: const Duration(seconds: 4),
      ),
    );
  }

  void _ensurePartnerName(Couple couple) {
    final partnerId = couple.partnerIdFor(widget.me.uid);
    if (partnerId == null || _watchingPartner == partnerId) return;

    _watchingPartner = partnerId;
    _partnerSub?.cancel();
    _partnerSub = _couples.watchUser(partnerId).listen(
      (user) {
        if (mounted && user != null) {
          setState(() => _partner = user);
          _scheduleReminderSync();
        }
      },
      onError: (_) {},
    );
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<Couple?>(
      stream: _coupleStream,
      builder: (context, snapshot) {
        final couple = snapshot.data;

        if (couple == null) {
          return const Scaffold(
            body: Center(child: CircularProgressIndicator()),
          );
        }

        _ensurePartnerName(couple);
        final partnerName = _displayNameFor(couple);
        _shownPartnerName = partnerName;
        if (_latestCouple?.startDate != couple.startDate ||
            _latestCouple?.nextMeetup != couple.nextMeetup ||
            _latestCouple == null) {
          _scheduleReminderSync();
        }
        _latestCouple = couple;

        final tabs = [
          HomeScreen(
            me: widget.me,
            couple: couple,
            partnerName: partnerName,
            coupleService: _couples,
            moodService: _moods,
            questionService: _questions,
            nudgeService: _nudges,
            memoryService: _memoryService,
            eventService: _eventService,
            noteService: _noteService,
            partner: _partner,
            events: _events,
            incomingNotes: _incomingNotes,
            onOpenChat: () => setState(() => _tabIndex = _chatTab),
            onOpenMemories: () => setState(() => _tabIndex = _memoriesTab),
            onOpenCalendar: () {
              setState(() => _tabIndex = _togetherTab);
              _togetherKey.currentState?.showTab(0);
            },
          ),
          ChatScreen(
            authService: widget.authService,
            me: widget.me,
            coupleId: widget.coupleId,
            partnerName: partnerName,
            partnerUid: couple.partnerIdFor(widget.me.uid),
            callService: _calls,
            isActive: _tabIndex == _chatTab,
          ),
          MemoriesScreen(
            coupleId: widget.coupleId,
            myUid: widget.me.uid,
            memoryService: _memoryService,
          ),
          TogetherScreen(
            key: _togetherKey,
            couple: couple,
            me: widget.me,
            partner: _partner,
            partnerName: partnerName,
            eventService: _eventService,
            noteService: _noteService,
          ),
          UsScreen(
            me: widget.me,
            couple: couple,
            partnerName: partnerName,
            authService: widget.authService,
            coupleService: _couples,
            questionService: _questions,
          ),
        ];

        return Scaffold(
          body: IndexedStack(index: _tabIndex, children: tabs),
          bottomNavigationBar: NavigationBar(
            selectedIndex: _tabIndex,
            onDestinationSelected: (index) =>
                setState(() => _tabIndex = index),
            destinations: const [
              NavigationDestination(
                icon: Icon(Icons.home_outlined),
                selectedIcon: Icon(Icons.home),
                label: 'Home',
              ),
              NavigationDestination(
                icon: Icon(Icons.chat_bubble_outline),
                selectedIcon: Icon(Icons.chat_bubble),
                label: 'Chat',
              ),
              NavigationDestination(
                icon: Icon(Icons.photo_album_outlined),
                selectedIcon: Icon(Icons.photo_album),
                label: 'Memories',
              ),
              NavigationDestination(
                icon: Icon(Icons.calendar_month_outlined),
                selectedIcon: Icon(Icons.calendar_month),
                label: 'Together',
              ),
              NavigationDestination(
                icon: Icon(Icons.favorite_outline),
                selectedIcon: Icon(Icons.favorite),
                label: 'Us',
              ),
            ],
          ),
        );
      },
    );
  }
}
