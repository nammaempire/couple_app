import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../../models/memory.dart';
import '../../services/memory_service.dart';
import 'memory_detail_screen.dart';
import 'memory_editor_screen.dart';
import 'memory_recap_screen.dart';

/// The Memories tab: a timeline of shared moments, with albums, favourites,
/// search and a monthly recap.
class MemoriesScreen extends StatefulWidget {
  const MemoriesScreen({
    super.key,
    required this.coupleId,
    required this.myUid,
    required this.memoryService,
  });

  final String coupleId;
  final String myUid;
  final MemoryService memoryService;

  @override
  State<MemoriesScreen> createState() => _MemoriesScreenState();
}

/// Special filter values alongside album names.
const _allFilter = '__all__';
const _favouritesFilter = '__favourites__';

class _MemoriesScreenState extends State<MemoriesScreen> {
  late final Stream<List<Memory>> _memories =
      widget.memoryService.watchMemories(widget.coupleId);

  String _filter = _allFilter;
  DateTimeRange? _range;
  bool _searching = false;
  final _search = TextEditingController();

  @override
  void initState() {
    super.initState();
    _search.addListener(() => setState(() {}));
  }

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  List<Memory> _apply(List<Memory> all) {
    return all.where((m) {
      if (_filter == _favouritesFilter && !m.favorite) return false;
      if (_filter != _allFilter &&
          _filter != _favouritesFilter &&
          m.album != _filter) {
        return false;
      }
      final range = _range;
      if (range != null) {
        final day = DateTime(m.date.year, m.date.month, m.date.day);
        if (day.isBefore(range.start) || day.isAfter(range.end)) return false;
      }
      return m.matches(_search.text);
    }).toList();
  }

  Future<void> _pickRange(List<Memory> all) async {
    final now = DateTime.now();
    final earliest = all.isEmpty
        ? DateTime(now.year - 5)
        : all.map((m) => m.date).reduce((a, b) => a.isBefore(b) ? a : b);
    final picked = await showDateRangePicker(
      context: context,
      firstDate: DateTime(earliest.year - 1),
      lastDate: DateTime(now.year + 1),
      initialDateRange: _range,
      helpText: 'Show memories between',
    );
    if (picked != null) setState(() => _range = picked);
  }

  void _openEditor({Memory? memory, List<String> albums = const []}) {
    Navigator.of(context).push(
      MaterialPageRoute(
        fullscreenDialog: true,
        builder: (_) => MemoryEditorScreen(
          coupleId: widget.coupleId,
          myUid: widget.myUid,
          memoryService: widget.memoryService,
          memory: memory,
          existingAlbums: albums,
        ),
      ),
    );
  }

  void _openDetail(Memory memory, List<String> albums) {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => MemoryDetailScreen(
          coupleId: widget.coupleId,
          myUid: widget.myUid,
          memoryId: memory.id,
          initial: memory,
          memoryService: widget.memoryService,
          albums: albums,
        ),
      ),
    );
  }

  void _openRecap(List<Memory> all) {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => MemoryRecapScreen(memories: all)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<List<Memory>>(
      stream: _memories,
      builder: (context, snapshot) {
        final all = snapshot.data ?? const <Memory>[];
        final albums = MemoryAlbums.all(all);
        final shown = _apply(all);
        final filtering = _filter != _allFilter ||
            _range != null ||
            _search.text.trim().isNotEmpty;

        return Scaffold(
          appBar: AppBar(
            title: _searching
                ? TextField(
                    controller: _search,
                    autofocus: true,
                    decoration: const InputDecoration(
                      hintText: 'Search title, place, caption',
                      filled: false,
                      border: InputBorder.none,
                    ),
                  )
                : const Text('Memories'),
            actions: [
              IconButton(
                tooltip: _searching ? 'Close search' : 'Search',
                icon: Icon(_searching ? Icons.close : Icons.search),
                onPressed: () => setState(() {
                  _searching = !_searching;
                  if (!_searching) _search.clear();
                }),
              ),
              IconButton(
                tooltip: 'Filter by date',
                icon: Icon(
                  _range == null ? Icons.date_range_outlined : Icons.date_range,
                ),
                onPressed: () => _pickRange(all),
              ),
            ],
          ),
          floatingActionButton: FloatingActionButton.extended(
            onPressed: () => _openEditor(albums: albums),
            icon: const Icon(Icons.add_photo_alternate_outlined),
            label: const Text('New memory'),
          ),
          body: !snapshot.hasData && !snapshot.hasError
              ? const Center(child: CircularProgressIndicator())
              : CustomScrollView(
                  slivers: [
                    SliverToBoxAdapter(
                      child: _FilterChips(
                        albums: albums,
                        selected: _filter,
                        onSelected: (f) => setState(() => _filter = f),
                      ),
                    ),
                    if (_range != null)
                      SliverToBoxAdapter(
                        child: Padding(
                          padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
                          child: InputChip(
                            avatar: const Icon(Icons.date_range, size: 18),
                            label: Text(
                              '${DateFormat.yMMMd().format(_range!.start)} – '
                              '${DateFormat.yMMMd().format(_range!.end)}',
                            ),
                            onDeleted: () => setState(() => _range = null),
                          ),
                        ),
                      ),
                    if (!filtering && all.isNotEmpty)
                      SliverToBoxAdapter(
                        child: _Highlights(
                          all: all,
                          onOpenRecap: () => _openRecap(all),
                          onOpenMemory: (m) => _openDetail(m, albums),
                        ),
                      ),
                    if (shown.isEmpty)
                      SliverFillRemaining(
                        hasScrollBody: false,
                        child: _EmptyState(
                          filtering: filtering,
                          onCreate: () => _openEditor(albums: albums),
                        ),
                      )
                    else
                      ..._timeline(context, shown, albums),
                    const SliverToBoxAdapter(child: SizedBox(height: 96)),
                  ],
                ),
        );
      },
    );
  }

  /// Month headers followed by that month's memory cards.
  List<Widget> _timeline(
    BuildContext context,
    List<Memory> memories,
    List<String> albums,
  ) {
    final theme = Theme.of(context);
    final groups = <String, List<Memory>>{};
    for (final m in memories) {
      groups.putIfAbsent(DateFormat.yMMMM().format(m.date), () => []).add(m);
    }

    return [
      for (final entry in groups.entries) ...[
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 16, 20, 8),
            child: Row(
              children: [
                Text(
                  entry.key,
                  style: theme.textTheme.titleMedium
                      ?.copyWith(fontWeight: FontWeight.w700),
                ),
                const SizedBox(width: 8),
                Text(
                  '${entry.value.length}',
                  style: theme.textTheme.labelMedium?.copyWith(
                    color: theme.colorScheme.onSurfaceVariant,
                  ),
                ),
              ],
            ),
          ),
        ),
        SliverList.builder(
          itemCount: entry.value.length,
          itemBuilder: (context, i) {
            final memory = entry.value[i];
            return MemoryCard(
              memory: memory,
              onTap: () => _openDetail(memory, albums),
              onToggleFavourite: () => widget.memoryService.setFavorite(
                coupleId: widget.coupleId,
                memoryId: memory.id,
                favorite: !memory.favorite,
              ),
            );
          },
        ),
      ],
    ];
  }
}

class _FilterChips extends StatelessWidget {
  const _FilterChips({
    required this.albums,
    required this.selected,
    required this.onSelected,
  });

  final List<String> albums;
  final String selected;
  final ValueChanged<String> onSelected;

  @override
  Widget build(BuildContext context) {
    Widget chip(String value, String label) => Padding(
          padding: const EdgeInsets.only(right: 8),
          child: ChoiceChip(
            label: Text(label),
            selected: selected == value,
            onSelected: (_) => onSelected(value),
          ),
        );

    return SizedBox(
      height: 56,
      child: ListView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.fromLTRB(16, 8, 8, 8),
        children: [
          chip(_allFilter, 'All'),
          chip(_favouritesFilter, '♥ Favourites'),
          for (final album in albums)
            chip(album, '${MemoryAlbums.emojiFor(album)} $album'),
        ],
      ),
    );
  }
}

/// "On this day" and the monthly recap entry, above the timeline.
class _Highlights extends StatelessWidget {
  const _Highlights({
    required this.all,
    required this.onOpenRecap,
    required this.onOpenMemory,
  });

  final List<Memory> all;
  final VoidCallback onOpenRecap;
  final ValueChanged<Memory> onOpenMemory;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final now = DateTime.now();
    final onThisDay = MemoryRecap.onThisDay(all, now);
    final thisMonth = MemoryRecap.month(all, now.year, now.month);

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 4),
      child: Column(
        children: [
          if (onThisDay.isNotEmpty)
            _BannerCard(
              imageUrl: onThisDay.first.coverUrl,
              eyebrow: 'ON THIS DAY',
              title: onThisDay.first.title,
              subtitle: _yearsAgo(now.year - onThisDay.first.date.year),
              onTap: () => onOpenMemory(onThisDay.first),
            ),
          if (onThisDay.isNotEmpty) const SizedBox(height: 10),
          Material(
            color: theme.colorScheme.primaryContainer.withValues(alpha: .6),
            borderRadius: BorderRadius.circular(20),
            child: InkWell(
              onTap: onOpenRecap,
              borderRadius: BorderRadius.circular(20),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Row(
                  children: [
                    Icon(Icons.auto_awesome, color: theme.colorScheme.primary),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Our Memories recap',
                            style: theme.textTheme.titleSmall
                                ?.copyWith(fontWeight: FontWeight.w600),
                          ),
                          Text(
                            thisMonth.isEmpty
                                ? 'Look back at any month or year'
                                : '${thisMonth.memories.length} so far in '
                                    '${thisMonth.label}',
                            style: theme.textTheme.bodySmall?.copyWith(
                              color: theme.colorScheme.onSurfaceVariant,
                            ),
                          ),
                        ],
                      ),
                    ),
                    const Icon(Icons.chevron_right),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  static String _yearsAgo(int years) =>
      years == 1 ? '1 year ago today' : '$years years ago today';
}

class _BannerCard extends StatelessWidget {
  const _BannerCard({
    required this.imageUrl,
    required this.eyebrow,
    required this.title,
    required this.subtitle,
    required this.onTap,
  });

  final String? imageUrl;
  final String eyebrow;
  final String title;
  final String subtitle;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return GestureDetector(
      onTap: onTap,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(20),
        child: SizedBox(
          height: 140,
          width: double.infinity,
          child: Stack(
            fit: StackFit.expand,
            children: [
              if (imageUrl != null)
                CachedNetworkImage(imageUrl: imageUrl!, fit: BoxFit.cover)
              else
                Container(color: theme.colorScheme.primary),
              const DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [Colors.transparent, Color(0xB3000000)],
                  ),
                ),
              ),
              Positioned(
                left: 16,
                right: 16,
                bottom: 14,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      eyebrow,
                      style: const TextStyle(
                        color: Colors.white70,
                        fontSize: 11,
                        letterSpacing: 1.2,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    Text(
                      title,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    Text(
                      subtitle,
                      style: const TextStyle(color: Colors.white70),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// A memory in the timeline: cover, title, date and place.
class MemoryCard extends StatelessWidget {
  const MemoryCard({
    super.key,
    required this.memory,
    required this.onTap,
    required this.onToggleFavourite,
  });

  final Memory memory;
  final VoidCallback onTap;
  final VoidCallback onToggleFavourite;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final cover = memory.coverUrl;

    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
      child: Material(
        color: theme.colorScheme.surfaceContainerHighest.withValues(alpha: .5),
        borderRadius: BorderRadius.circular(20),
        clipBehavior: Clip.antiAlias,
        child: InkWell(
          onTap: onTap,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              if (cover != null)
                AspectRatio(
                  aspectRatio: 16 / 10,
                  child: Stack(
                    fit: StackFit.expand,
                    children: [
                      CachedNetworkImage(
                        imageUrl: cover,
                        fit: BoxFit.cover,
                        placeholder: (_, _) => Container(
                          color: theme.colorScheme.surfaceContainerHighest,
                        ),
                        errorWidget: (_, _, _) => Container(
                          color: theme.colorScheme.surfaceContainerHighest,
                          child: const Icon(Icons.broken_image_outlined),
                        ),
                      ),
                      if (memory.media.length > 1)
                        Positioned(
                          right: 10,
                          top: 10,
                          child: _CountBadge(memory: memory),
                        ),
                    ],
                  ),
                ),
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 12, 4, 12),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            memory.title.isEmpty ? 'Untitled' : memory.title,
                            style: theme.textTheme.titleMedium
                                ?.copyWith(fontWeight: FontWeight.w600),
                          ),
                          const SizedBox(height: 2),
                          Text(
                            [
                              DateFormat.yMMMd().format(memory.date),
                              if (memory.place != null) memory.place!,
                              '${MemoryAlbums.emojiFor(memory.album)} '
                                  '${memory.album}',
                            ].join(' · '),
                            maxLines: 1,
                            overflow: TextOverflow.ellipsis,
                            style: theme.textTheme.bodySmall?.copyWith(
                              color: theme.colorScheme.onSurfaceVariant,
                            ),
                          ),
                          if (memory.caption.isNotEmpty) ...[
                            const SizedBox(height: 6),
                            Text(
                              memory.caption,
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              style: theme.textTheme.bodyMedium,
                            ),
                          ],
                        ],
                      ),
                    ),
                    IconButton(
                      tooltip: memory.favorite
                          ? 'Remove from favourites'
                          : 'Add to favourites',
                      icon: Icon(
                        memory.favorite ? Icons.favorite : Icons.favorite_border,
                        color: memory.favorite ? theme.colorScheme.primary : null,
                      ),
                      onPressed: onToggleFavourite,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _CountBadge extends StatelessWidget {
  const _CountBadge({required this.memory});

  final Memory memory;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: Colors.black.withValues(alpha: .5),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (memory.photoCount > 0) ...[
            const Icon(Icons.photo, size: 14, color: Colors.white),
            const SizedBox(width: 3),
            Text('${memory.photoCount}',
                style: const TextStyle(color: Colors.white, fontSize: 12)),
          ],
          if (memory.photoCount > 0 && memory.videoCount > 0)
            const SizedBox(width: 8),
          if (memory.videoCount > 0) ...[
            const Icon(Icons.videocam, size: 14, color: Colors.white),
            const SizedBox(width: 3),
            Text('${memory.videoCount}',
                style: const TextStyle(color: Colors.white, fontSize: 12)),
          ],
        ],
      ),
    );
  }
}

class _EmptyState extends StatelessWidget {
  const _EmptyState({required this.filtering, required this.onCreate});

  final bool filtering;
  final VoidCallback onCreate;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Padding(
      padding: const EdgeInsets.all(32),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            filtering ? Icons.search_off : Icons.photo_album_outlined,
            size: 56,
            color: theme.colorScheme.primary,
          ),
          const SizedBox(height: 16),
          Text(
            filtering ? 'No memories match' : 'Your story starts here',
            style: theme.textTheme.titleMedium
                ?.copyWith(fontWeight: FontWeight.w600),
          ),
          const SizedBox(height: 6),
          Text(
            filtering
                ? 'Try another album, date or search.'
                : 'Add your first memory: a first date, a trip, or any '
                    'moment worth keeping.',
            textAlign: TextAlign.center,
            style: theme.textTheme.bodyMedium?.copyWith(
              color: theme.colorScheme.onSurfaceVariant,
            ),
          ),
          if (!filtering) ...[
            const SizedBox(height: 20),
            FilledButton.tonalIcon(
              onPressed: onCreate,
              icon: const Icon(Icons.add),
              label: const Text('Add a memory'),
            ),
          ],
        ],
      ),
    );
  }
}
