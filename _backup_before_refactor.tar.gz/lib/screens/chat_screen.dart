import 'dart:async';
import 'dart:io';
import 'dart:math' as math;

import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:video_player/video_player.dart';

import '../models/app_user.dart';
import '../models/call_session.dart';
import '../models/couple.dart';
import '../models/message.dart';
import '../services/auth_service.dart';
import '../services/call_launcher.dart';
import '../services/call_service.dart';
import '../services/chat_service.dart';
import '../services/couple_service.dart';
import '../services/voice_playback.dart';
import '../widgets/chat_input.dart';
import '../widgets/message_bubble.dart';
import 'chat_search_screen.dart';
import 'media_gallery_screen.dart';

enum _MenuAction { search, media, pinned }

/// The conversation between the two partners.
class ChatScreen extends StatefulWidget {
  const ChatScreen({
    super.key,
    required this.authService,
    required this.me,
    required this.coupleId,
    required this.partnerName,
    required this.partnerUid,
    this.chatService,
    this.coupleService,
    this.callService,
    this.isActive = true,
  });

  final AuthService authService;
  final AppUser me;
  final String coupleId;

  /// Already resolved by the shell, nickname applied.
  final String partnerName;

  /// Null until the couple is complete.
  final String? partnerUid;

  final ChatService? chatService;
  final CoupleService? coupleService;
  final CallService? callService;

  /// Whether the Chat tab is the one on screen. The shell keeps every tab
  /// alive, so without this, messages would be marked seen from Home.
  final bool isActive;

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> with WidgetsBindingObserver {
  static const _pageSize = 60;

  /// Jumping to a message pages back at most this far.
  static const _maxJumpPages = ChatService.searchWindow ~/ _pageSize + 1;

  late final ChatService _chat = widget.chatService ?? ChatService();
  late final CoupleService _couples = widget.coupleService ?? CoupleService();
  late final CallService _calls = widget.callService ?? CallService();
  final _picker = ImagePicker();
  final _scroll = ScrollController();

  late final Stream<Couple?> _coupleStream =
      _couples.watchCouple(widget.coupleId);
  late final Stream<List<Message>> _pinnedStream =
      _chat.watchPinned(widget.coupleId);

  /// How many of the newest messages are loaded. Grows as the user scrolls
  /// back; Firestore keeps the whole window live.
  int _limit = _pageSize;
  late Stream<({List<Message> messages, bool fromCache})> _messagesStream =
      _chat.watchMessagePage(widget.coupleId, limit: _limit);

  List<Message> _loaded = const [];
  bool get _hasMore => _loaded.length >= _limit;
  bool _loadingMore = false;
  Completer<void>? _pageLoaded;

  /// False while the last requested page has only been answered from the
  /// device cache (or not at all), e.g. when offline.
  bool _pageConfirmed = true;

  /// Keys for message rows, so a message can be scrolled into view.
  final _rowKeys = <String, GlobalKey>{};

  double? _uploadProgress;
  String? _uploadLabel;

  Message? _replyingTo;
  String? _highlightId;
  Timer? _highlightTimer;

  /// Id of the newest message we have already run a seen-sweep for, so
  /// rebuilds don't trigger repeated Firestore reads.
  String? _lastSeenSweepId;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _markSeen();
  }

  @override
  void didUpdateWidget(covariant ChatScreen oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.isActive && !oldWidget.isActive) {
      _markSeen();
    } else if (!widget.isActive && oldWidget.isActive) {
      // Leaving the Chat tab: don't keep a voice message playing.
      VoicePlayback.instance.stop();
      if (_replyingTo != null) setState(() => _replyingTo = null);
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) _markSeen();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _highlightTimer?.cancel();
    _scroll.dispose();
    super.dispose();
  }

  /// Marks the partner's messages read, but only while the chat is actually
  /// on screen and the app is in the foreground.
  void _markSeen() {
    final partnerId = widget.partnerUid;
    if (partnerId == null || !widget.isActive) return;
    final lifecycle = WidgetsBinding.instance.lifecycleState;
    if (lifecycle != null && lifecycle != AppLifecycleState.resumed) return;
    _chat
        .markSeen(coupleId: widget.coupleId, partnerId: partnerId)
        .catchError((_) {});
  }

  String _nameFor(String uid) =>
      uid == widget.me.uid ? 'You' : widget.partnerName;

  void _showError(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(message)));
  }

  // ---- Paging -------------------------------------------------------------

  void _loadMore() {
    if (_loadingMore || !_hasMore) return;
    _loadingMore = true;
    _pageConfirmed = false;
    _pageLoaded = Completer<void>();
    setState(() {
      _limit += _pageSize;
      _messagesStream = _chat.watchMessagePage(widget.coupleId, limit: _limit);
    });
  }

  Future<void> _loadMoreAndWait() async {
    if (!_hasMore) return;
    _loadMore();
    await (_pageLoaded?.future ?? Future<void>.value()).timeout(
      const Duration(seconds: 8),
      // Offline or slow: give up on this page but let paging try again.
      onTimeout: _finishPage,
    );
  }

  void _finishPage() {
    _loadingMore = false;
    final pending = _pageLoaded;
    _pageLoaded = null;
    if (pending != null && !pending.isCompleted) pending.complete();
  }

  /// Called from the list's builder with each result of the current query.
  void _onMessages(
    List<Message> messages, {
    required bool fromCache,
    required bool isCurrentQuery,
  }) {
    // Right after the limit grows, StreamBuilder replays the previous
    // query's result; ignore that for paging purposes.
    if (!isCurrentQuery) return;
    _loaded = messages;

    if (!_loadingMore) return;
    // A cache-only answer may be missing older messages the server has, so
    // only a short server answer means "no more".
    final pageFilled = messages.length >= _limit;
    if (pageFilled || !fromCache) {
      _pageConfirmed = true;
      _finishPage();
    }
  }

  // ---- Jumping to a message ----------------------------------------------

  /// Scrolls [messageId] into view and flashes it, loading older pages if
  /// needed. Used by search results, pins and reply quotes.
  Future<void> _jumpTo(String messageId) async {
    bool isLoaded() => _loaded.any((m) => m.id == messageId);

    for (var page = 0;
        page < _maxJumpPages && !isLoaded() && _hasMore;
        page++) {
      await _loadMoreAndWait();
      if (!mounted) return;
    }
    if (!isLoaded()) {
      _showError(!_pageConfirmed
          ? 'Could not load older messages. Check your connection.'
          : _hasMore
              ? 'That message is too far back to jump to.'
              : 'That message is no longer in the conversation.');
      return;
    }

    // Rows are built lazily, so walk up the list until the row exists.
    if (_scroll.hasClients && _rowKeys[messageId]?.currentContext == null) {
      _scroll.jumpTo(0);
      await WidgetsBinding.instance.endOfFrame;
    }
    for (var step = 0; step < 200; step++) {
      final rowContext = _rowKeys[messageId]?.currentContext;
      if (rowContext != null) {
        if (!rowContext.mounted) return;
        await Scrollable.ensureVisible(
          rowContext,
          alignment: .4,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
        _flash(messageId);
        return;
      }
      if (!_scroll.hasClients) return;
      final position = _scroll.position;
      if (position.pixels >= position.maxScrollExtent) return;
      _scroll.jumpTo(math.min(
        position.pixels + position.viewportDimension * .8,
        position.maxScrollExtent,
      ));
      await WidgetsBinding.instance.endOfFrame;
    }
  }

  void _flash(String messageId) {
    _highlightTimer?.cancel();
    setState(() => _highlightId = messageId);
    _highlightTimer = Timer(const Duration(milliseconds: 1600), () {
      if (mounted) setState(() => _highlightId = null);
    });
  }

  // ---- Sending ------------------------------------------------------------

  ReplyPreview? _takeReply() {
    final reply = _replyingTo == null ? null : ReplyPreview.of(_replyingTo!);
    if (_replyingTo != null) setState(() => _replyingTo = null);
    return reply;
  }

  Future<void> _sendText(String text) async {
    final reply = _takeReply();
    try {
      await _chat.sendText(
        coupleId: widget.coupleId,
        senderId: widget.me.uid,
        text: text,
        replyTo: reply,
      );
    } catch (e) {
      _showError('Message not sent. Check your connection.');
    }
  }

  /// Runs an upload with the progress bar showing, mapping common failures
  /// to messages.
  Future<void> _upload(
    String label,
    Future<void> Function(void Function(double) onProgress) send,
  ) async {
    setState(() {
      _uploadProgress = 0;
      _uploadLabel = label;
    });
    try {
      await send((p) {
        if (mounted) setState(() => _uploadProgress = p);
      });
    } on ChatException catch (e) {
      _showError(e.message);
    } on FirebaseException catch (e) {
      // Storage is optional: the app is usable for text before it is enabled.
      _showError(e.plugin == 'firebase_storage'
          ? 'Sending media needs Firebase Storage enabled on this project.'
          : 'Could not send. Check your connection.');
    } catch (e) {
      _showError('Could not send. Check your connection.');
    } finally {
      if (mounted) {
        setState(() {
          _uploadProgress = null;
          _uploadLabel = null;
        });
      }
    }
  }

  Future<void> _sendPhoto(ImageSource source) async {
    final XFile? picked;
    try {
      picked = await _picker.pickImage(
        source: source,
        imageQuality: 82,
        maxWidth: 2000,
      );
    } catch (e) {
      _showError('Could not open ${source == ImageSource.camera ? 'the camera' : 'your photos'}.');
      return;
    }
    if (picked == null) return;

    final reply = _takeReply();
    await _upload('Sending photo…', (onProgress) {
      return _chat.sendImage(
        coupleId: widget.coupleId,
        senderId: widget.me.uid,
        file: File(picked!.path),
        onProgress: onProgress,
        replyTo: reply,
      );
    });
  }

  Future<void> _sendVideo(ImageSource source) async {
    final XFile? picked;
    try {
      picked = await _picker.pickVideo(
        source: source,
        maxDuration: const Duration(minutes: 3),
      );
    } catch (e) {
      _showError('Could not open ${source == ImageSource.camera ? 'the camera' : 'your videos'}.');
      return;
    }
    if (picked == null) return;

    final file = File(picked.path);
    final duration = await _videoDuration(file);
    final reply = _takeReply();

    await _upload('Sending video…', (onProgress) {
      return _chat.sendVideo(
        coupleId: widget.coupleId,
        senderId: widget.me.uid,
        file: file,
        duration: duration,
        onProgress: onProgress,
        replyTo: reply,
      );
    });
  }

  Future<Duration?> _videoDuration(File file) async {
    final controller = VideoPlayerController.file(file);
    try {
      await controller.initialize();
      return controller.value.duration;
    } catch (_) {
      return null;
    } finally {
      await controller.dispose();
    }
  }

  Future<void> _sendVoice(File file, Duration duration) async {
    final reply = _takeReply();
    await _upload('Sending voice message…', (_) {
      return _chat.sendVoice(
        coupleId: widget.coupleId,
        senderId: widget.me.uid,
        file: file,
        duration: duration,
        replyTo: reply,
      );
    });
  }

  Future<void> _openAttachSheet() async {
    await showModalBottomSheet<void>(
      context: context,
      showDragHandle: true,
      builder: (sheetContext) {
        void pick(Future<void> Function() action) {
          Navigator.pop(sheetContext);
          action();
        }

        return SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ListTile(
                leading: const Icon(Icons.image_outlined),
                title: const Text('Photo from gallery'),
                onTap: () => pick(() => _sendPhoto(ImageSource.gallery)),
              ),
              ListTile(
                leading: const Icon(Icons.video_library_outlined),
                title: const Text('Video from gallery'),
                subtitle: const Text('Up to 3 minutes, 100 MB'),
                onTap: () => pick(() => _sendVideo(ImageSource.gallery)),
              ),
              ListTile(
                leading: const Icon(Icons.videocam_outlined),
                title: const Text('Record a video'),
                onTap: () => pick(() => _sendVideo(ImageSource.camera)),
              ),
              const SizedBox(height: 8),
            ],
          ),
        );
      },
    );
  }

  // ---- Message actions ----------------------------------------------------

  Future<void> _openMessageActions(Message message) async {
    final isMine = message.senderId == widget.me.uid;
    final theme = Theme.of(context);

    await showModalBottomSheet<void>(
      context: context,
      builder: (sheetContext) {
        void run(VoidCallback action) {
          Navigator.pop(sheetContext);
          action();
        }

        return SafeArea(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(8, 16, 8, 12),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: CoupleReaction.values.map((reaction) {
                    final isActive =
                        message.reactions[widget.me.uid] == reaction.emoji;
                    return InkWell(
                      borderRadius: BorderRadius.circular(16),
                      onTap: () => run(() => _react(message, reaction.emoji)),
                      child: Padding(
                        padding: const EdgeInsets.all(4),
                        child: Column(
                          children: [
                            AnimatedContainer(
                              duration: const Duration(milliseconds: 150),
                              padding: const EdgeInsets.all(8),
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                color: isActive
                                    ? theme.colorScheme.primary
                                        .withValues(alpha: .18)
                                    : Colors.transparent,
                              ),
                              child: Text(
                                reaction.emoji,
                                style: const TextStyle(fontSize: 28),
                              ),
                            ),
                            Text(
                              reaction.label,
                              style: theme.textTheme.labelSmall,
                            ),
                          ],
                        ),
                      ),
                    );
                  }).toList(),
                ),
              ),
              const Divider(height: 1),
              ListTile(
                leading: const Icon(Icons.reply),
                title: const Text('Reply'),
                onTap: () => run(() => setState(() => _replyingTo = message)),
              ),
              if (message.type == MessageType.text)
                ListTile(
                  leading: const Icon(Icons.copy),
                  title: const Text('Copy text'),
                  onTap: () => run(() {
                    Clipboard.setData(ClipboardData(text: message.text));
                    _showError('Copied');
                  }),
                ),
              ListTile(
                leading: Icon(
                  message.pinned ? Icons.push_pin_outlined : Icons.push_pin,
                ),
                title: Text(message.pinned ? 'Unpin' : 'Pin'),
                onTap: () => run(() => _setPinned(message, !message.pinned)),
              ),
              if (isMine)
                ListTile(
                  leading: Icon(
                    Icons.delete_outline,
                    color: theme.colorScheme.error,
                  ),
                  title: Text(
                    'Delete for both of you',
                    style: TextStyle(color: theme.colorScheme.error),
                  ),
                  onTap: () => run(() => _confirmDelete(message)),
                ),
            ],
          ),
        );
      },
    );
  }

  Future<void> _react(Message message, String emoji) async {
    await HapticFeedback.selectionClick();
    try {
      await _chat.toggleReaction(
        coupleId: widget.coupleId,
        message: message,
        uid: widget.me.uid,
        emoji: emoji,
      );
    } catch (e) {
      _showError('Could not add that reaction.');
    }
  }

  Future<void> _setPinned(Message message, bool pinned) async {
    try {
      await _chat.setPinned(
        coupleId: widget.coupleId,
        message: message,
        pinned: pinned,
      );
    } catch (_) {
      _showError('Could not ${pinned ? 'pin' : 'unpin'} that message.');
    }
  }

  Future<void> _confirmDelete(Message message) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Delete message?'),
        content: const Text(
          'It will be removed for both of you. This cannot be undone.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext, false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(dialogContext, true),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
    if (ok != true) return;
    try {
      await _chat.deleteMessage(coupleId: widget.coupleId, message: message);
    } catch (e) {
      _showError('Could not delete that message.');
    }
  }

  // ---- Menus --------------------------------------------------------------

  Future<void> _onMenu(_MenuAction action) async {
    switch (action) {
      case _MenuAction.search:
        final id = await Navigator.of(context).push<String>(
          MaterialPageRoute(
            builder: (_) => ChatSearchScreen(
              coupleId: widget.coupleId,
              myUid: widget.me.uid,
              partnerName: widget.partnerName,
              chatService: _chat,
            ),
          ),
        );
        if (id != null) await _jumpTo(id);
      case _MenuAction.media:
        await Navigator.of(context).push(
          MaterialPageRoute(
            builder: (_) => MediaGalleryScreen(
              coupleId: widget.coupleId,
              chatService: _chat,
            ),
          ),
        );
      case _MenuAction.pinned:
        await _openPinnedSheet();
    }
  }

  Future<void> _openPinnedSheet() async {
    final id = await showModalBottomSheet<String>(
      context: context,
      showDragHandle: true,
      isScrollControlled: true,
      // A fresh stream: Firestore streams are broadcast, so a second listener
      // on the pinned bar's stream would get nothing until the next change.
      builder: (sheetContext) => StreamBuilder<List<Message>>(
        stream: _chat.watchPinned(widget.coupleId),
        builder: (context, snapshot) {
          final pinned = snapshot.data ?? const <Message>[];
          final theme = Theme.of(context);
          return ConstrainedBox(
            constraints: BoxConstraints(
              maxHeight: MediaQuery.sizeOf(context).height * .7,
            ),
            child: pinned.isEmpty
                ? Padding(
                    padding: const EdgeInsets.fromLTRB(24, 8, 24, 40),
                    child: Text(
                      'Nothing pinned yet. Long-press a message and choose '
                      'Pin to keep it here.',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: theme.colorScheme.onSurfaceVariant,
                      ),
                    ),
                  )
                : ListView(
                    shrinkWrap: true,
                    children: [
                      Padding(
                        padding: const EdgeInsets.fromLTRB(20, 0, 20, 8),
                        child: Text(
                          'Pinned messages',
                          style: theme.textTheme.titleMedium,
                        ),
                      ),
                      for (final m in pinned)
                        ListTile(
                          leading: const Icon(Icons.push_pin),
                          title: Text(
                            m.previewText,
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                          ),
                          subtitle: Text(
                            '${_nameFor(m.senderId)}'
                            '${m.sentAt == null ? '' : ' · ${DateFormat.yMMMd().format(m.sentAt!)}'}',
                          ),
                          trailing: IconButton(
                            tooltip: 'Unpin',
                            icon: const Icon(Icons.close),
                            onPressed: () => _setPinned(m, false),
                          ),
                          onTap: () => Navigator.pop(sheetContext, m.id),
                        ),
                      const SizedBox(height: 16),
                    ],
                  ),
          );
        },
      ),
    );
    if (id != null) await _jumpTo(id);
  }

  // ---- Build --------------------------------------------------------------

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: StreamBuilder<Couple?>(
          stream: _coupleStream,
          builder: (context, snap) {
            final couple = snap.data;

            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(widget.partnerName),
                if (couple != null && !couple.isComplete)
                  Text(
                    'Waiting for your partner · code ${couple.inviteCode}',
                    style: Theme.of(context).textTheme.bodySmall,
                  ),
              ],
            );
          },
        ),
        actions: [
          IconButton(
            tooltip: 'Voice call',
            icon: const Icon(Icons.call_outlined),
            onPressed: () => _call(CallType.voice),
          ),
          IconButton(
            tooltip: 'Video call',
            icon: const Icon(Icons.videocam_outlined),
            onPressed: () => _call(CallType.video),
          ),
          PopupMenuButton<_MenuAction>(
            tooltip: 'More',
            onSelected: _onMenu,
            itemBuilder: (_) => const [
              PopupMenuItem(
                value: _MenuAction.search,
                child: ListTile(
                  leading: Icon(Icons.search),
                  title: Text('Search'),
                  contentPadding: EdgeInsets.zero,
                ),
              ),
              PopupMenuItem(
                value: _MenuAction.media,
                child: ListTile(
                  leading: Icon(Icons.photo_library_outlined),
                  title: Text('Photos & videos'),
                  contentPadding: EdgeInsets.zero,
                ),
              ),
              PopupMenuItem(
                value: _MenuAction.pinned,
                child: ListTile(
                  leading: Icon(Icons.push_pin_outlined),
                  title: Text('Pinned messages'),
                  contentPadding: EdgeInsets.zero,
                ),
              ),
            ],
          ),
        ],
      ),
      body: Column(
        children: [
          StreamBuilder<List<Message>>(
            stream: _pinnedStream,
            builder: (context, snap) {
              final pinned = snap.data ?? const <Message>[];
              if (pinned.isEmpty) return const SizedBox.shrink();
              return _PinnedBar(
                latest: pinned.first,
                count: pinned.length,
                onTap: () => _jumpTo(pinned.first.id),
                onShowAll: _openPinnedSheet,
              );
            },
          ),
          if (_uploadProgress != null)
            _UploadBar(
              label: _uploadLabel ?? 'Sending…',
              progress: _uploadProgress == 0 ? null : _uploadProgress,
            ),
          Expanded(child: _buildMessages()),
          ChatInput(
            enabled: _uploadProgress == null,
            onSendText: _sendText,
            onPickCamera: () => _sendPhoto(ImageSource.camera),
            onAttach: _openAttachSheet,
            onSendVoice: _sendVoice,
            replyingTo:
                _replyingTo == null ? null : ReplyPreview.of(_replyingTo!),
            replyingToLabel:
                _replyingTo == null ? null : _nameFor(_replyingTo!.senderId),
            onCancelReply: () => setState(() => _replyingTo = null),
          ),
        ],
      ),
    );
  }

  void _call(CallType type) {
    placeCall(
      context,
      coupleId: widget.coupleId,
      myUid: widget.me.uid,
      partnerUid: widget.partnerUid,
      partnerName: widget.partnerName,
      type: type,
      callService: _calls,
    );
  }

  Widget _buildMessages() {
    return StreamBuilder<({List<Message> messages, bool fromCache})>(
      stream: _messagesStream,
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          // Let paging recover if a bigger page failed.
          if (_loadingMore) _finishPage();
          return Center(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const _CenteredNote(
                  icon: Icons.cloud_off,
                  text: 'Could not load messages.',
                ),
                const SizedBox(height: 8),
                TextButton.icon(
                  icon: const Icon(Icons.refresh),
                  label: const Text('Try again'),
                  onPressed: () => setState(() {
                    _messagesStream =
                        _chat.watchMessagePage(widget.coupleId, limit: _limit);
                  }),
                ),
              ],
            ),
          );
        }
        if (!snapshot.hasData) {
          return const Center(child: CircularProgressIndicator());
        }

        final page = snapshot.data!;
        final messages = page.messages;
        _onMessages(
          messages,
          fromCache: page.fromCache,
          isCurrentQuery: snapshot.connectionState == ConnectionState.active,
        );

        if (messages.isEmpty) {
          return const _CenteredNote(
            icon: Icons.favorite_border,
            text: 'Say something sweet to start.',
          );
        }

        // Mark incoming messages read, but only once per new arrival.
        final newest = messages.first;
        if (newest.id != _lastSeenSweepId && widget.isActive) {
          _lastSeenSweepId = newest.id;
          _markSeen();
        }

        final hasMore = _hasMore;

        return ListView.builder(
          controller: _scroll,
          reverse: true,
          padding: const EdgeInsets.symmetric(vertical: 12),
          itemCount: messages.length + (hasMore ? 1 : 0),
          itemBuilder: (context, index) {
            // The top of the list: fetch the next page when it comes into view.
            if (index == messages.length) {
              // With a timeout, so paging can retry after an offline spell.
              WidgetsBinding.instance
                  .addPostFrameCallback((_) => _loadMoreAndWait());
              return const Padding(
                padding: EdgeInsets.all(16),
                child: Center(
                  child: SizedBox(
                    width: 22,
                    height: 22,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  ),
                ),
              );
            }

            final message = messages[index];
            final isMine = message.senderId == widget.me.uid;

            // messages is newest-first, so "older" is the next index.
            final older =
                index + 1 < messages.length ? messages[index + 1] : null;
            final showDate = _needsDateDivider(message, older);

            final Widget row = message.type == MessageType.call
                ? CallLogTile(message: message, myUid: widget.me.uid)
                : MessageBubble(
                    message: message,
                    isMine: isMine,
                    myUid: widget.me.uid,
                    partnerName: widget.partnerName,
                    highlighted: _highlightId == message.id,
                    onLongPress: () => _openMessageActions(message),
                    onDoubleTap: () =>
                        _react(message, CoupleReaction.love.emoji),
                    onSwipeReply: () =>
                        setState(() => _replyingTo = message),
                    onTapQuote: _jumpTo,
                  );

            return KeyedSubtree(
              key: _rowKeys.putIfAbsent(message.id, GlobalKey.new),
              child: Column(
                children: [
                  if (showDate) _DateDivider(date: message.sentAt),
                  row,
                ],
              ),
            );
          },
        );
      },
    );
  }

  bool _needsDateDivider(Message current, Message? older) {
    final currentDate = current.sentAt;
    if (currentDate == null) return false;
    if (older?.sentAt == null) return true;

    final previousDate = older!.sentAt!;
    return currentDate.year != previousDate.year ||
        currentDate.month != previousDate.month ||
        currentDate.day != previousDate.day;
  }
}

/// Strip under the app bar showing the latest pinned message.
class _PinnedBar extends StatelessWidget {
  const _PinnedBar({
    required this.latest,
    required this.count,
    required this.onTap,
    required this.onShowAll,
  });

  final Message latest;
  final int count;
  final VoidCallback onTap;
  final VoidCallback onShowAll;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Material(
      color: theme.colorScheme.surfaceContainerHighest.withValues(alpha: .6),
      child: InkWell(
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 8, 4, 8),
          child: Row(
            children: [
              Icon(Icons.push_pin, size: 18, color: theme.colorScheme.primary),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      count == 1 ? 'Pinned' : 'Pinned · $count',
                      style: theme.textTheme.labelMedium?.copyWith(
                        color: theme.colorScheme.primary,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    Text(
                      latest.previewText,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: theme.textTheme.bodyMedium,
                    ),
                  ],
                ),
              ),
              if (count > 1)
                IconButton(
                  tooltip: 'All pinned messages',
                  icon: const Icon(Icons.list),
                  onPressed: onShowAll,
                ),
            ],
          ),
        ),
      ),
    );
  }
}

class _UploadBar extends StatelessWidget {
  const _UploadBar({required this.label, required this.progress});

  final String label;
  final double? progress;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Column(
      children: [
        LinearProgressIndicator(value: progress),
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 4),
          child: Text(
            progress == null ? label : '$label ${(progress! * 100).round()}%',
            style: theme.textTheme.labelSmall?.copyWith(
              color: theme.colorScheme.onSurfaceVariant,
            ),
          ),
        ),
      ],
    );
  }
}

class _DateDivider extends StatelessWidget {
  const _DateDivider({required this.date});

  final DateTime? date;

  @override
  Widget build(BuildContext context) {
    if (date == null) return const SizedBox.shrink();

    final now = DateTime.now();
    final isToday = date!.year == now.year &&
        date!.month == now.month &&
        date!.day == now.day;
    final label = isToday ? 'Today' : DateFormat.yMMMd().format(date!);

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 12),
      child: Text(
        label,
        style: Theme.of(context).textTheme.labelSmall?.copyWith(
              color: Theme.of(context).colorScheme.onSurfaceVariant,
            ),
      ),
    );
  }
}

class _CenteredNote extends StatelessWidget {
  const _CenteredNote({required this.icon, required this.text});

  final IconData icon;
  final String text;

  @override
  Widget build(BuildContext context) {
    final color = Theme.of(context).colorScheme.onSurfaceVariant;
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 44, color: color),
          const SizedBox(height: 12),
          Text(text, style: TextStyle(color: color)),
        ],
      ),
    );
  }
}
