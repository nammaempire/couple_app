import 'dart:async';

import 'package:agora_rtc_engine/agora_rtc_engine.dart';
import 'package:flutter/material.dart';

import '../models/call_session.dart';
import '../models/message.dart';
import '../services/agora_service.dart';
import '../services/call_service.dart';
import '../services/chat_service.dart';
import '../services/voice_playback.dart';

/// The in-call screen, for both the caller and the callee.
///
/// It owns the Agora engine for the duration of the call and watches the
/// signalling document so a hang-up on either side closes both screens.
class CallScreen extends StatefulWidget {
  const CallScreen({
    super.key,
    required this.coupleId,
    required this.myUid,
    required this.partnerName,
    required this.session,
    required this.callService,
    required this.isOutgoing,
  });

  final String coupleId;
  final String myUid;
  final String partnerName;
  final CallSession session;
  final CallService callService;

  /// True when this user placed the call and is waiting for an answer.
  final bool isOutgoing;

  @override
  State<CallScreen> createState() => _CallScreenState();
}

class _CallScreenState extends State<CallScreen> {
  final _agora = AgoraService();

  StreamSubscription<CallSession?>? _callSub;
  Timer? _ticker;
  Duration _elapsed = Duration.zero;

  bool _joining = false;
  bool _hasJoined = false;
  String? _error;

  /// Set once this screen starts closing, so the back-button handler does
  /// not treat our own pop as a hang-up.
  bool _closing = false;

  /// Caller side: gives up when nobody answers in time.
  Timer? _ringTimer;

  /// When the call connected, for the talk time in the call log.
  DateTime? _acceptedAt;

  /// How the call ended, as last seen on the signalling document.
  CallStatus? _finalStatus;

  bool _logged = false;

  @override
  void initState() {
    super.initState();
    VoicePlayback.instance.stop();
    _agora.addListener(_onAgoraChanged);
    _watchSignalling();

    if (widget.session.isActive) {
      // The callee already accepted before this screen opened, so connect
      // and start the timer now.
      _acceptedAt = DateTime.now();
      _startTicker(widget.session);
      _connect();
    } else if (widget.isOutgoing) {
      // The caller waits for the accept, but not forever.
      _ringTimer = Timer(CallSession.ringTimeout, _onRingTimeout);
    }
  }

  @override
  void dispose() {
    _logCall();
    _ringTimer?.cancel();
    _callSub?.cancel();
    _ticker?.cancel();
    _agora.removeListener(_onAgoraChanged);
    _agora.dispose();
    super.dispose();
  }

  void _onAgoraChanged() {
    if (mounted) setState(() {});
  }

  void _watchSignalling() {
    _callSub = widget.callService.watchCall(widget.coupleId).listen((session) {
      if (!mounted) return;

      // The other side hung up, declined, it rang out, or the document
      // was cleared.
      if (session == null || session.isFinished) {
        _finalStatus = session?.status;
        _close(
          message: switch (session?.status) {
            CallStatus.declined => '${widget.partnerName} declined',
            CallStatus.missed when widget.isOutgoing => 'No answer',
            _ => null,
          },
        );
        return;
      }

      // Caller side: the callee just accepted, so join the channel.
      if (session.isActive && !_hasJoined && !_joining) {
        _ringTimer?.cancel();
        _acceptedAt ??= DateTime.now();
        _startTicker(session);
        _connect();
      }
    });
  }

  Future<void> _onRingTimeout() async {
    if (_acceptedAt != null || _closing) return;
    try {
      // The signalling listener closes the screen once this lands.
      await widget.callService.markMissed(widget.coupleId);
    } catch (_) {
      _finalStatus = CallStatus.missed;
      _close(message: 'No answer');
    }
  }

  /// The caller records the call in the chat once, however it ended.
  void _logCall() {
    if (!widget.isOutgoing || _logged) return;
    _logged = true;

    final acceptedAt = _acceptedAt;
    final CallOutcome outcome;
    if (acceptedAt != null) {
      outcome = CallOutcome.completed;
    } else if (_finalStatus == CallStatus.declined) {
      outcome = CallOutcome.declined;
    } else {
      outcome = CallOutcome.missed;
    }

    ChatService()
        .logCall(
          coupleId: widget.coupleId,
          callerId: widget.myUid,
          video: widget.session.isVideo,
          outcome: outcome,
          talkTime: acceptedAt == null
              ? null
              : DateTime.now().difference(acceptedAt),
        )
        .catchError((_) {});
  }

  /// Times the call from this phone's own clock, so a phone whose clock
  /// disagrees with the server never shows a negative duration.
  void _startTicker(CallSession session) {
    _ticker?.cancel();
    final from = _acceptedAt ?? DateTime.now();
    _ticker = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!mounted) return;
      final elapsed = DateTime.now().difference(from);
      setState(() => _elapsed = elapsed.isNegative ? Duration.zero : elapsed);
    });
  }

  Future<void> _connect() async {
    if (_joining || _hasJoined) return;
    setState(() => _joining = true);

    try {
      await _agora.join(
        channelName: widget.session.channelName,
        video: widget.session.isVideo,
      );
      if (mounted) setState(() => _hasJoined = true);
    } on CallSetupException catch (e) {
      if (mounted) setState(() => _error = e.message);
      await widget.callService.endCall(widget.coupleId);
    } catch (e) {
      if (mounted) setState(() => _error = 'Could not connect the call.');
      await widget.callService.endCall(widget.coupleId);
    } finally {
      if (mounted) setState(() => _joining = false);
    }
  }

  Future<void> _hangUp() async {
    if (_closing) return;
    _finalStatus ??= CallStatus.ended;
    try {
      await widget.callService.endCall(widget.coupleId);
    } catch (_) {
      // Close locally even if the network write failed.
    }
    _close();
  }

  void _close({String? message}) {
    if (!mounted || _closing) return;
    _closing = true;
    _ticker?.cancel();
    _ringTimer?.cancel();
    _logCall();
    // A direct pop: maybePop would be blocked by this screen's PopScope and
    // re-enter the hang-up handler.
    Navigator.of(context).pop();
    if (message != null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(message)),
      );
    }
  }

  String get _statusLabel {
    if (_error != null) return 'Call failed';
    if (!_hasJoined) {
      return widget.isOutgoing ? 'Ringing…' : 'Connecting…';
    }
    if (_agora.remoteUid == null) {
      return _agora.partnerHasJoined ? 'Reconnecting…' : 'Connecting…';
    }
    return _formatDuration(_elapsed);
  }

  String _formatDuration(Duration d) {
    final minutes = d.inMinutes.toString().padLeft(2, '0');
    final seconds = (d.inSeconds % 60).toString().padLeft(2, '0');
    return '$minutes:$seconds';
  }

  @override
  Widget build(BuildContext context) {
    final isVideo = widget.session.isVideo;
    final connected = _agora.remoteUid != null;

    return PopScope(
      // Leaving by back-swipe should hang up, not silently orphan the call.
      canPop: false,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop && !_closing) _hangUp();
      },
      child: Scaffold(
        backgroundColor: const Color(0xFF14100F),
        body: Stack(
          children: [
            if (isVideo && connected)
              _RemoteVideo(
                agora: _agora,
                uid: _agora.remoteUid!,
                channelName: widget.session.channelName,
              )
            else
              _AvatarBackdrop(name: widget.partnerName),

            if (isVideo && _hasJoined && !_agora.cameraOff)
              Positioned(
                top: 60,
                right: 16,
                width: 110,
                height: 160,
                child: _LocalVideo(agora: _agora),
              ),

            Positioned(
              top: 60,
              left: 0,
              right: 0,
              child: Column(
                children: [
                  Text(
                    widget.partnerName,
                    style: const TextStyle(
                      color: Colors.white,
                      fontSize: 26,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    _statusLabel,
                    style: TextStyle(
                      color: Colors.white.withValues(alpha: .7),
                      fontSize: 15,
                    ),
                  ),
                  if (_error != null) ...[
                    const SizedBox(height: 12),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 32),
                      child: Text(
                        _error!,
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          color: Color(0xFFFF9B9B),
                          fontSize: 14,
                        ),
                      ),
                    ),
                  ],
                ],
              ),
            ),

            Positioned(
              left: 0,
              right: 0,
              bottom: 48,
              child: _CallControls(
                agora: _agora,
                isVideo: isVideo,
                onHangUp: _hangUp,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _RemoteVideo extends StatelessWidget {
  const _RemoteVideo({
    required this.agora,
    required this.uid,
    required this.channelName,
  });

  final AgoraService agora;
  final int uid;
  final String channelName;

  @override
  Widget build(BuildContext context) {
    final engine = agora.engine;
    if (engine == null) return const SizedBox.shrink();

    return AgoraVideoView(
      controller: VideoViewController.remote(
        rtcEngine: engine,
        canvas: VideoCanvas(uid: uid),
        connection: RtcConnection(channelId: channelName),
      ),
    );
  }
}

class _LocalVideo extends StatelessWidget {
  const _LocalVideo({required this.agora});

  final AgoraService agora;

  @override
  Widget build(BuildContext context) {
    final engine = agora.engine;
    if (engine == null) return const SizedBox.shrink();

    return ClipRRect(
      borderRadius: BorderRadius.circular(16),
      child: AgoraVideoView(
        controller: VideoViewController(
          rtcEngine: engine,
          canvas: const VideoCanvas(uid: 0),
        ),
      ),
    );
  }
}

/// Shown for voice calls, and for video before the far side connects.
class _AvatarBackdrop extends StatelessWidget {
  const _AvatarBackdrop({required this.name});

  final String name;

  @override
  Widget build(BuildContext context) {
    final initial = name.isEmpty ? '?' : name.characters.first.toUpperCase();

    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [Color(0xFF3B2229), Color(0xFF14100F)],
        ),
      ),
      child: Center(
        child: Container(
          width: 132,
          height: 132,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: const Color(0xFFE05C7B).withValues(alpha: .25),
          ),
          child: Center(
            child: Text(
              initial,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 52,
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _CallControls extends StatelessWidget {
  const _CallControls({
    required this.agora,
    required this.isVideo,
    required this.onHangUp,
  });

  final AgoraService agora;
  final bool isVideo;
  final VoidCallback onHangUp;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        _ControlButton(
          icon: agora.micMuted ? Icons.mic_off : Icons.mic,
          active: agora.micMuted,
          tooltip: agora.micMuted ? 'Unmute' : 'Mute',
          onPressed: agora.isReady ? agora.toggleMic : null,
        ),
        const SizedBox(width: 14),

        if (isVideo) ...[
          _ControlButton(
            icon: agora.cameraOff ? Icons.videocam_off : Icons.videocam,
            active: agora.cameraOff,
            tooltip: agora.cameraOff ? 'Camera on' : 'Camera off',
            onPressed: agora.isReady ? agora.toggleCamera : null,
          ),
          const SizedBox(width: 14),
          _ControlButton(
            icon: Icons.cameraswitch,
            tooltip: 'Flip camera',
            onPressed: agora.isReady ? agora.switchCamera : null,
          ),
        ] else
          _ControlButton(
            icon: agora.speakerOn ? Icons.volume_up : Icons.phone_in_talk,
            active: agora.speakerOn,
            tooltip: agora.speakerOn ? 'Speaker off' : 'Speaker on',
            onPressed: agora.isReady ? agora.toggleSpeaker : null,
          ),

        const SizedBox(width: 14),
        _ControlButton(
          icon: Icons.call_end,
          background: const Color(0xFFE23D50),
          iconColor: Colors.white,
          tooltip: 'End call',
          onPressed: onHangUp,
        ),
      ],
    );
  }
}

class _ControlButton extends StatelessWidget {
  const _ControlButton({
    required this.icon,
    required this.tooltip,
    required this.onPressed,
    this.active = false,
    this.background,
    this.iconColor,
  });

  final IconData icon;
  final String tooltip;
  final VoidCallback? onPressed;
  final bool active;
  final Color? background;
  final Color? iconColor;

  @override
  Widget build(BuildContext context) {
    final bg = background ??
        (active ? Colors.white : Colors.white.withValues(alpha: .16));
    final fg = iconColor ?? (active ? Colors.black87 : Colors.white);

    return Tooltip(
      message: tooltip,
      child: Material(
        color: bg,
        shape: const CircleBorder(),
        child: InkWell(
          customBorder: const CircleBorder(),
          onTap: onPressed,
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Icon(icon, color: fg, size: 26),
          ),
        ),
      ),
    );
  }
}
