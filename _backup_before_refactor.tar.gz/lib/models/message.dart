import 'package:cloud_firestore/cloud_firestore.dart';

enum MessageType {
  text,
  image,
  video,
  voice,

  /// A record of a voice or video call, written when the call ends.
  call;

  static MessageType fromId(String? id) {
    for (final type in values) {
      if (type.name == id) return type;
    }
    return MessageType.text;
  }
}

/// How a logged call ended.
enum CallOutcome {
  /// Connected; [Message.durationMs] holds the talk time.
  completed,

  /// Rang out, or the caller hung up before an answer.
  missed,

  /// The callee declined.
  declined;

  static CallOutcome fromId(String? id) {
    for (final outcome in values) {
      if (outcome.name == id) return outcome;
    }
    return CallOutcome.missed;
  }
}

/// The couple's reaction set, from the product spec.
enum CoupleReaction {
  love('❤️', 'Love'),
  missYou('🥺', 'Miss you'),
  hug('🤗', 'Hug'),
  kiss('😘', 'Kiss'),
  laugh('😂', 'Laugh');

  const CoupleReaction(this.emoji, this.label);
  final String emoji;
  final String label;
}

/// A snapshot of the message being replied to, stored on the reply so the
/// quote still shows if the original is later deleted.
class ReplyPreview {
  final String messageId;
  final String senderId;
  final MessageType type;
  final String text;

  const ReplyPreview({
    required this.messageId,
    required this.senderId,
    required this.type,
    required this.text,
  });

  factory ReplyPreview.of(Message message) => ReplyPreview(
        messageId: message.id,
        senderId: message.senderId,
        type: message.type,
        text: message.previewText,
      );

  static ReplyPreview? fromMap(Object? raw) {
    if (raw is! Map<String, dynamic>) return null;
    return ReplyPreview(
      messageId: (raw['messageId'] as String?) ?? '',
      senderId: (raw['senderId'] as String?) ?? '',
      type: MessageType.fromId(raw['type'] as String?),
      text: (raw['text'] as String?) ?? '',
    );
  }

  Map<String, dynamic> toMap() => {
        'messageId': messageId,
        'senderId': senderId,
        'type': type.name,
        'text': text,
      };
}

/// A single chat message inside a couple's conversation.
class Message {
  final String id;
  final String senderId;
  final MessageType type;

  /// Text body for [MessageType.text]; empty for media.
  final String text;

  /// Download URL of the photo, or of a video's thumbnail.
  final String? imageUrl;

  /// Aspect ratio (width / height) so bubbles can reserve space before load.
  final double? imageAspectRatio;

  /// Download URL of the video or voice recording.
  final String? mediaUrl;

  /// Length of a video, voice message or connected call.
  final int? durationMs;

  final DateTime? sentAt;
  final bool seen;

  /// Emoji reactions keyed by the uid that left them. One each.
  final Map<String, String> reactions;

  final ReplyPreview? replyTo;

  final bool pinned;
  final DateTime? pinnedAt;

  /// For [MessageType.call]: whether it was a video call, and how it ended.
  final bool isVideoCall;
  final CallOutcome? callOutcome;

  const Message({
    required this.id,
    required this.senderId,
    required this.type,
    this.text = '',
    this.imageUrl,
    this.imageAspectRatio,
    this.mediaUrl,
    this.durationMs,
    this.sentAt,
    this.seen = false,
    this.reactions = const {},
    this.replyTo,
    this.pinned = false,
    this.pinnedAt,
    this.isVideoCall = false,
    this.callOutcome,
  });

  Duration? get duration =>
      durationMs == null ? null : Duration(milliseconds: durationMs!);

  bool get isMedia =>
      type == MessageType.image || type == MessageType.video;

  /// Distinct emoji on this message, in a stable order.
  List<String> get reactionEmoji {
    final alreadyAdded = <String>{};
    final ordered = <String>[];
    for (final emoji in reactions.values) {
      if (alreadyAdded.add(emoji)) ordered.add(emoji);
    }
    return ordered;
  }

  /// One-line summary for reply quotes, pins, search and the chat preview.
  String get previewText {
    switch (type) {
      case MessageType.text:
        return text;
      case MessageType.image:
        return '📷 Photo';
      case MessageType.video:
        return '🎥 Video';
      case MessageType.voice:
        final d = duration;
        return d == null
            ? '🎤 Voice message'
            : '🎤 Voice message (${formatDuration(d)})';
      case MessageType.call:
        final kind = isVideoCall ? 'video call' : 'voice call';
        return switch (callOutcome ?? CallOutcome.missed) {
          CallOutcome.completed => '📞 ${_capitalise(kind)}',
          CallOutcome.missed => '📞 Missed $kind',
          CallOutcome.declined => '📞 Declined $kind',
        };
    }
  }

  static String _capitalise(String s) =>
      s.isEmpty ? s : s[0].toUpperCase() + s.substring(1);

  /// m:ss, or h:mm:ss for an hour or more.
  static String formatDuration(Duration d) {
    final hours = d.inHours;
    final minutes = d.inMinutes % 60;
    final seconds = (d.inSeconds % 60).toString().padLeft(2, '0');
    if (hours > 0) {
      return '$hours:${minutes.toString().padLeft(2, '0')}:$seconds';
    }
    return '$minutes:$seconds';
  }

  factory Message.fromDoc(DocumentSnapshot<Map<String, dynamic>> doc) {
    final data = doc.data() ?? <String, dynamic>{};
    return Message(
      id: doc.id,
      senderId: (data['senderId'] as String?) ?? '',
      type: MessageType.fromId(data['type'] as String?),
      text: (data['text'] as String?) ?? '',
      imageUrl: data['imageUrl'] as String?,
      imageAspectRatio: (data['imageAspectRatio'] as num?)?.toDouble(),
      mediaUrl: data['mediaUrl'] as String?,
      durationMs: (data['durationMs'] as num?)?.toInt(),
      sentAt: (data['sentAt'] as Timestamp?)?.toDate(),
      seen: (data['seen'] as bool?) ?? false,
      reactions: Map<String, String>.from(
        (data['reactions'] as Map<String, dynamic>?) ?? <String, dynamic>{},
      ),
      replyTo: ReplyPreview.fromMap(data['replyTo']),
      pinned: (data['pinned'] as bool?) ?? false,
      pinnedAt: (data['pinnedAt'] as Timestamp?)?.toDate(),
      isVideoCall: (data['callType'] as String?) == 'video',
      callOutcome: data['callOutcome'] == null
          ? null
          : CallOutcome.fromId(data['callOutcome'] as String?),
    );
  }

  Map<String, dynamic> toMap() => {
        'senderId': senderId,
        'type': type.name,
        'text': text,
        'imageUrl': imageUrl,
        'imageAspectRatio': imageAspectRatio,
        'sentAt': FieldValue.serverTimestamp(),
        'seen': seen,
        'reactions': reactions,
        if (mediaUrl != null) 'mediaUrl': mediaUrl,
        if (durationMs != null) 'durationMs': durationMs,
        if (replyTo != null) 'replyTo': replyTo!.toMap(),
        if (type == MessageType.call) ...{
          'callType': isVideoCall ? 'video' : 'voice',
          'callOutcome': (callOutcome ?? CallOutcome.missed).name,
        },
      };
}
