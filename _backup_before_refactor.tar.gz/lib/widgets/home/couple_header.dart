import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';

/// Top of Home: greeting plus the couple photo, or both partners' avatars
/// side by side when no couple photo is set.
class CoupleHeader extends StatelessWidget {
  const CoupleHeader({
    super.key,
    required this.greeting,
    required this.subtitle,
    required this.myName,
    required this.partnerName,
    this.myPhotoUrl,
    this.partnerPhotoUrl,
    this.couplePhotoUrl,
  });

  final String greeting;
  final String subtitle;
  final String myName;
  final String partnerName;
  final String? myPhotoUrl;
  final String? partnerPhotoUrl;
  final String? couplePhotoUrl;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final couplePhoto = couplePhotoUrl;

    final text = Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          greeting,
          style: theme.textTheme.headlineSmall?.copyWith(
            fontWeight: FontWeight.w700,
            color: couplePhoto == null ? null : Colors.white,
          ),
        ),
        const SizedBox(height: 2),
        Text(
          subtitle,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: theme.textTheme.bodyMedium?.copyWith(
            color: couplePhoto == null
                ? theme.colorScheme.onSurfaceVariant
                : Colors.white.withValues(alpha: .85),
          ),
        ),
      ],
    );

    if (couplePhoto == null) {
      return Row(
        children: [
          Expanded(child: text),
          const SizedBox(width: 12),
          _AvatarPair(
            myName: myName,
            partnerName: partnerName,
            myPhotoUrl: myPhotoUrl,
            partnerPhotoUrl: partnerPhotoUrl,
          ),
        ],
      );
    }

    return ClipRRect(
      borderRadius: BorderRadius.circular(24),
      child: SizedBox(
        height: 168,
        child: Stack(
          fit: StackFit.expand,
          children: [
            CachedNetworkImage(
              imageUrl: couplePhoto,
              fit: BoxFit.cover,
              errorWidget: (_, _, _) =>
                  Container(color: theme.colorScheme.primary),
            ),
            const DecoratedBox(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [Colors.transparent, Color(0xB3000000)],
                  stops: [.35, 1],
                ),
              ),
            ),
            Positioned(left: 20, right: 20, bottom: 16, child: text),
          ],
        ),
      ),
    );
  }
}

class _AvatarPair extends StatelessWidget {
  const _AvatarPair({
    required this.myName,
    required this.partnerName,
    this.myPhotoUrl,
    this.partnerPhotoUrl,
  });

  final String myName;
  final String partnerName;
  final String? myPhotoUrl;
  final String? partnerPhotoUrl;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 84,
      height: 52,
      child: Stack(
        children: [
          Positioned(
            left: 0,
            child: _Avatar(name: myName, photoUrl: myPhotoUrl),
          ),
          Positioned(
            right: 0,
            child: _Avatar(name: partnerName, photoUrl: partnerPhotoUrl),
          ),
        ],
      ),
    );
  }
}

class _Avatar extends StatelessWidget {
  const _Avatar({required this.name, this.photoUrl});

  final String name;
  final String? photoUrl;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final url = photoUrl;
    final initial = name.isEmpty ? '?' : name.characters.first.toUpperCase();

    return Container(
      padding: const EdgeInsets.all(2.5),
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: theme.scaffoldBackgroundColor,
      ),
      child: CircleAvatar(
        radius: 23.5,
        backgroundColor: theme.colorScheme.primaryContainer,
        backgroundImage: url == null ? null : CachedNetworkImageProvider(url),
        child: url == null
            ? Text(
                initial,
                style: theme.textTheme.titleMedium?.copyWith(
                  color: theme.colorScheme.onPrimaryContainer,
                  fontWeight: FontWeight.w600,
                ),
              )
            : null,
      ),
    );
  }
}
