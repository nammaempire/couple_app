import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:path_provider/path_provider.dart';
import 'package:record/record.dart';

import '../models/message.dart';
import '../services/voice_playback.dart';
import 'voice_message_player.dart';

/// A recorded clip ready to attach.
class RecordedVoice {
  const RecordedVoice(this.file, this.duration);
  final File file;
  final Duration duration;
}

/// Record, preview and discard a short voice letter.
class VoiceNoteRecorder extends StatefulWidget {
  const VoiceNoteRecorder({
    super.key,
    required this.onChanged,
    this.onRecordingChanged,
    this.maxLength = const Duration(minutes: 5),
  });

  /// Called with the recording, or null when it is discarded.
  final ValueChanged<RecordedVoice?> onChanged;

  /// Called when recording starts and stops, so the parent can hold off
  /// sending until the clip is finished.
  final ValueChanged<bool>? onRecordingChanged;
  final Duration maxLength;

  @override
  State<VoiceNoteRecorder> createState() => _VoiceNoteRecorderState();
}

class _VoiceNoteRecorderState extends State<VoiceNoteRecorder> {
  AudioRecorder? _recorder;
  bool _starting = false;
  bool _recording = false;
  DateTime? _startedAt;
  Duration _elapsed = Duration.zero;
  Timer? _ticker;
  RecordedVoice? _clip;

  @override
  void dispose() {
    _ticker?.cancel();
    if (_recording) _recorder?.cancel();
    _recorder?.dispose();
    if (_clip != null) VoicePlayback.instance.stop();
    super.dispose();
  }

  void _toast(String text) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  }

  Future<void> _start() async {
    if (_starting || _recording) return;
    _starting = true;
    try {
      final recorder = _recorder ??= AudioRecorder();
      if (!await recorder.hasPermission()) {
        _toast('Voice letters need microphone access. Enable it in Settings.');
        return;
      }
      final dir = await getTemporaryDirectory();
      await recorder.start(
        const RecordConfig(
          encoder: AudioEncoder.aacLc,
          bitRate: 64000,
          sampleRate: 44100,
          numChannels: 1,
        ),
        path: '${dir.path}/letter_${DateTime.now().millisecondsSinceEpoch}.m4a',
      );
      if (!mounted) {
        await recorder.cancel();
        return;
      }
      await HapticFeedback.mediumImpact();
      setState(() {
        _recording = true;
        _startedAt = DateTime.now();
        _elapsed = Duration.zero;
      });
      widget.onRecordingChanged?.call(true);
      _ticker = Timer.periodic(const Duration(milliseconds: 250), (_) {
        final from = _startedAt;
        if (from == null || !mounted) return;
        setState(() => _elapsed = DateTime.now().difference(from));
        if (_elapsed >= widget.maxLength) _stop();
      });
    } catch (_) {
      _toast('Could not start recording.');
    } finally {
      _starting = false;
    }
  }

  Future<void> _stop() async {
    if (!_recording) return;
    _ticker?.cancel();
    final duration = _elapsed;
    setState(() => _recording = false);
    widget.onRecordingChanged?.call(false);
    final path = await _recorder?.stop();
    if (path == null || !mounted) return;
    if (duration < const Duration(seconds: 1)) {
      _toast('Too short. Try again.');
      return;
    }
    final clip = RecordedVoice(File(path), duration);
    setState(() => _clip = clip);
    widget.onChanged(clip);
  }

  void _discard() {
    VoicePlayback.instance.stop();
    setState(() => _clip = null);
    widget.onChanged(null);
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final scheme = theme.colorScheme;
    final clip = _clip;

    Widget body;
    if (_recording) {
      body = Row(
        children: [
          Icon(Icons.fiber_manual_record, color: scheme.error),
          const SizedBox(width: 8),
          Text(
            Message.formatDuration(_elapsed),
            style: theme.textTheme.titleMedium?.copyWith(
              fontFeatures: const [FontFeature.tabularFigures()],
            ),
          ),
          const SizedBox(width: 12),
          const Expanded(child: Text('Recording…')),
          FilledButton.icon(
            onPressed: _stop,
            icon: const Icon(Icons.stop_rounded),
            label: const Text('Stop'),
            style: FilledButton.styleFrom(minimumSize: const Size(0, 44)),
          ),
        ],
      );
    } else if (clip != null) {
      body = Row(
        children: [
          Expanded(
            child: VoiceClipPlayer(
              clipId: 'letter-preview-${clip.file.path}',
              url: Uri.file(clip.file.path).toString(),
              duration: clip.duration,
              color: scheme.onSurface,
              maxWidth: 400,
            ),
          ),
          IconButton(
            tooltip: 'Discard recording',
            icon: Icon(Icons.delete_outline, color: scheme.error),
            onPressed: _discard,
          ),
        ],
      );
    } else {
      body = Row(
        children: [
          Icon(Icons.mic_none_rounded, color: scheme.primary),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              'Add a voice letter (optional)',
              style: theme.textTheme.bodyMedium,
            ),
          ),
          FilledButton.tonal(
            onPressed: _start,
            style: FilledButton.styleFrom(minimumSize: const Size(0, 44)),
            child: const Text('Record'),
          ),
        ],
      );
    }

    return Container(
      padding: const EdgeInsets.fromLTRB(14, 8, 8, 8),
      decoration: BoxDecoration(
        color: scheme.surfaceContainerHighest.withValues(alpha: .5),
        borderRadius: BorderRadius.circular(18),
      ),
      child: body,
    );
  }
}
