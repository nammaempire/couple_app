import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';

import '../models/message.dart';
import '../screens/photo_viewer.dart';
import '../screens/video_player_screen.dart';
import '../theme.dart';
import 'voice_message_player.dart';

/// One chat message, aligned left (partner) or right (me).
///
/// Swipe right to reply, long-press for actions, double-tap to heart.
class MessageBubble extends StatefulWidget {
  const MessageBubble({
    super.key,
    required this.message,
    required this.isMine,
    required this.myUid,
    required this.partnerName,
    this.onLongPress,
    this.onDoubleTap,
    this.onSwipeReply,
    this.onTapQuote,
    this.highlighted = false,
  });

  final Message message;
  final bool isMine;
  final String myUid;
  final String partnerName;
  final VoidCallback? onLongPress;
  final VoidCallback? onDoubleTap;

  /// Called when the bubble is swiped far enough to start a reply.
  final VoidCallback? onSwipeReply;

  /// Called with the quoted message's id when the reply quote is tapped.
  final ValueChanged<String>? onTapQuote;

  /// Briefly tinted after jumping to this message from search, a pin or a
  /// reply quote.
  final bool highlighted;

  @override
  State<MessageBubble> createState() => _MessageBubbleState();
}

class _MessageBubbleState extends State<MessageBubble> {
  static const _replyThreshold = 64.0;

  double _dragX = 0;
  bool _armed = false;

  void _onDragUpdate(DragUpdateDetails details) {
    if (widget.onSwipeReply == null) return;
    setState(() {
      _dragX = (_dragX + details.delta.dx).clamp(0.0, _replyThreshold * 1.4);
    });
    final armed = _dragX >= _replyThreshold;
    if (armed && !_armed) HapticFeedback.selectionClick();
    _armed = armed;
  }

  void _onDragEnd(DragEndDetails _) {
    if (_armed) widget.onSwipeReply?.call();
    _resetDrag();
  }

  /// Also used when the gesture is cancelled, so a bubble never stays
  /// half-swiped.
  void _resetDrag() {
    if (_dragX == 0 && !_armed) return;
    setState(() {
      _dragX = 0;
      _armed = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final message = widget.message;
    final isMine = widget.isMine;
    final isDark = theme.brightness == Brightness.dark;

    final bg = isMine
        ? theme.colorScheme.primary
        : (isDark ? AppTheme.bubbleTheirsDark : AppTheme.bubbleTheirsLight);
    final fg = isMine ? theme.colorScheme.onPrimary : theme.colorScheme.onSurface;

    final radius = BorderRadius.only(
      topLeft: const Radius.circular(20),
      topRight: const Radius.circular(20),
      bottomLeft: Radius.circular(isMine ? 20 : 4),
      bottomRight: Radius.circular(isMine ? 4 : 20),
    );

    final quote = message.replyTo == null
        ? null
        : _ReplyQuote(
            reply: message.replyTo!,
            label: message.replyTo!.senderId == widget.myUid
                ? 'You'
                : widget.partnerName,
            onMine: isMine,
            onTap: widget.onTapQuote == null
                ? null
                : () => widget.onTapQuote!(message.replyTo!.messageId),
          );

    Widget content;
    switch (message.type) {
      case MessageType.image:
      case MessageType.video:
        content = Column(
          crossAxisAlignment:
              isMine ? CrossAxisAlignment.end : CrossAxisAlignment.start,
          children: [
            if (quote != null) ...[quote, const SizedBox(height: 4)],
            _VisualContent(message: message, radius: radius, isMine: isMine),
          ],
        );
      case MessageType.voice:
      case MessageType.text:
      case MessageType.call:
        content = Container(
          padding: EdgeInsets.fromLTRB(
            message.type == MessageType.voice ? 8 : 16,
            quote == null ? 10 : 8,
            message.type == MessageType.voice ? 12 : 16,
            8,
          ),
          decoration: BoxDecoration(color: bg, borderRadius: radius),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            mainAxisSize: MainAxisSize.min,
            children: [
              if (quote != null) ...[quote, const SizedBox(height: 6)],
              if (message.type == MessageType.voice)
                VoiceMessagePlayer(message: message, color: fg)
              else
                Align(
                  alignment: Alignment.centerLeft,
                  widthFactor: 1,
                  child: Text(
                    message.text,
                    style: TextStyle(color: fg, fontSize: 16),
                  ),
                ),
              const SizedBox(height: 2),
              _MetaRow(
                message: message,
                isMine: isMine,
                color: fg.withValues(alpha: .7),
              ),
            ],
          ),
        );
    }

    final bubble = ConstrainedBox(
      constraints: BoxConstraints(
        maxWidth: MediaQuery.sizeOf(context).width * 0.75,
      ),
      child: Stack(
        clipBehavior: Clip.none,
        children: [
          Padding(
            padding: EdgeInsets.only(
              bottom: message.reactions.isEmpty ? 0 : 12,
            ),
            child: content,
          ),
          if (message.reactions.isNotEmpty)
            Positioned(
              bottom: 0,
              left: isMine ? 12 : null,
              right: isMine ? null : 12,
              child: _ReactionPill(emoji: message.reactionEmoji),
            ),
        ],
      ),
    );

    return AnimatedContainer(
      duration: const Duration(milliseconds: 400),
      color: widget.highlighted
          ? theme.colorScheme.primary.withValues(alpha: .14)
          : Colors.transparent,
      child: GestureDetector(
        behavior: HitTestBehavior.translucent,
        onHorizontalDragUpdate: _onDragUpdate,
        onHorizontalDragEnd: _onDragEnd,
        onHorizontalDragCancel: _resetDrag,
        child: Stack(
          alignment: Alignment.centerLeft,
          children: [
            // Reply arrow revealed while swiping.
            Positioned(
              left: 12,
              child: Opacity(
                opacity: (_dragX / _replyThreshold).clamp(0.0, 1.0),
                child: Icon(
                  Icons.reply,
                  color: _armed
                      ? theme.colorScheme.primary
                      : theme.colorScheme.onSurfaceVariant,
                ),
              ),
            ),
            AnimatedContainer(
              duration: _dragX == 0
                  ? const Duration(milliseconds: 180)
                  : Duration.zero,
              transform: Matrix4.translationValues(_dragX, 0, 0),
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 3),
              child: Row(
                mainAxisAlignment:
                    isMine ? MainAxisAlignment.end : MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  if (message.pinned && isMine) const _PinMark(),
                  Flexible(
                    child: GestureDetector(
                      onLongPress: widget.onLongPress,
                      onDoubleTap: widget.onDoubleTap,
                      child: bubble,
                    ),
                  ),
                  if (message.pinned && !isMine) const _PinMark(),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _PinMark extends StatelessWidget {
  const _PinMark();

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 6),
      child: Icon(
        Icons.push_pin,
        size: 14,
        color: Theme.of(context).colorScheme.onSurfaceVariant,
      ),
    );
  }
}

/// The quoted message at the top of a reply.
class _ReplyQuote extends StatelessWidget {
  const _ReplyQuote({
    required this.reply,
    required this.label,
    required this.onMine,
    this.onTap,
  });

  final ReplyPreview reply;
  final String label;

  /// Drawn inside one of my (coloured) bubbles.
  final bool onMine;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final accent = onMine ? theme.colorScheme.onPrimary : theme.colorScheme.primary;
    final textColor = onMine
        ? theme.colorScheme.onPrimary.withValues(alpha: .85)
        : theme.colorScheme.onSurfaceVariant;

    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.fromLTRB(10, 6, 10, 6),
        decoration: BoxDecoration(
          color: onMine
              ? Colors.black.withValues(alpha: .12)
              : theme.colorScheme.primary.withValues(alpha: .08),
          borderRadius: BorderRadius.circular(10),
          border: Border(left: BorderSide(color: accent, width: 3)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              label,
              style: theme.textTheme.labelMedium?.copyWith(
                color: accent,
                fontWeight: FontWeight.w700,
              ),
            ),
            Text(
              reply.text.isEmpty ? 'Message' : reply.text,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: theme.textTheme.bodySmall?.copyWith(color: textColor),
            ),
          ],
        ),
      ),
    );
  }
}

/// The small floating cluster of emoji beneath a reacted-to message.
class _ReactionPill extends StatelessWidget {
  const _ReactionPill({required this.emoji});

  final List<String> emoji;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
      decoration: BoxDecoration(
        color: theme.colorScheme.surface,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: theme.dividerColor.withValues(alpha: .4),
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: .08),
            blurRadius: 4,
            offset: const Offset(0, 1),
          ),
        ],
      ),
      child: Text(
        emoji.join(' '),
        style: const TextStyle(fontSize: 12),
      ),
    );
  }
}

/// Photo, or video thumbnail with a play button and length.
class _VisualContent extends StatelessWidget {
  const _VisualContent({
    required this.message,
    required this.radius,
    required this.isMine,
  });

  final Message message;
  final BorderRadius radius;
  final bool isMine;

  bool get _isVideo => message.type == MessageType.video;

  void _open(BuildContext context) {
    if (_isVideo) {
      final url = message.mediaUrl;
      if (url == null) return;
      Navigator.of(context).push(
        MaterialPageRoute(builder: (_) => VideoPlayerScreen(videoUrl: url)),
      );
    } else {
      final url = message.imageUrl;
      if (url == null) return;
      Navigator.of(context).push(
        MaterialPageRoute(builder: (_) => PhotoViewer(imageUrl: url)),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final thumb = message.imageUrl;
    if (!_isVideo && thumb == null) return const SizedBox.shrink();

    final placeholder = Container(
      color: _isVideo
          ? const Color(0xFF2A2124)
          : theme.colorScheme.surfaceContainerHighest,
    );

    Widget image = thumb == null
        ? placeholder
        : CachedNetworkImage(
            imageUrl: thumb,
            fit: BoxFit.cover,
            placeholder: (context, _) => Container(
              color: theme.colorScheme.surfaceContainerHighest,
              child: const Center(
                child: SizedBox(
                  width: 22,
                  height: 22,
                  child: CircularProgressIndicator(strokeWidth: 2),
                ),
              ),
            ),
            errorWidget: (context, _, _) => Container(
              color: theme.colorScheme.surfaceContainerHighest,
              child: const Center(child: Icon(Icons.broken_image_outlined)),
            ),
          );
    if (!_isVideo && thumb != null) image = Hero(tag: thumb, child: image);

    final duration = message.duration;

    return Stack(
      alignment: Alignment.bottomRight,
      children: [
        ClipRRect(
          borderRadius: radius,
          child: AspectRatio(
            aspectRatio: (message.imageAspectRatio ?? (_isVideo ? 16 / 9 : 1.0))
                .clamp(0.5, 1.8)
                .toDouble(),
            child: GestureDetector(
              onTap: () => _open(context),
              child: Stack(
                fit: StackFit.expand,
                children: [
                  image,
                  if (_isVideo)
                    Center(
                      child: Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: Colors.black.withValues(alpha: .45),
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(
                          Icons.play_arrow_rounded,
                          color: Colors.white,
                          size: 36,
                        ),
                      ),
                    ),
                  if (_isVideo && duration != null)
                    Positioned(
                      left: 8,
                      bottom: 8,
                      child: _Chip(
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const Icon(Icons.videocam, size: 13,
                                color: Colors.white),
                            const SizedBox(width: 4),
                            Text(
                              Message.formatDuration(duration),
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 11,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.all(8),
          child: _Chip(
            child: _MetaRow(
              message: message,
              isMine: isMine,
              color: Colors.white,
            ),
          ),
        ),
      ],
    );
  }
}

class _Chip extends StatelessWidget {
  const _Chip({required this.child});

  final Widget child;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: Colors.black.withValues(alpha: .45),
        borderRadius: BorderRadius.circular(12),
      ),
      child: child,
    );
  }
}

class _MetaRow extends StatelessWidget {
  const _MetaRow({
    required this.message,
    required this.isMine,
    required this.color,
  });

  final Message message;
  final bool isMine;
  final Color color;

  @override
  Widget build(BuildContext context) {
    final sentAt = message.sentAt;
    final label = sentAt == null ? '' : DateFormat.jm().format(sentAt);

    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Text(label, style: TextStyle(fontSize: 11, color: color)),
        if (isMine) ...[
          const SizedBox(width: 4),
          Icon(
            sentAt == null
                ? Icons.schedule
                : message.seen
                    ? Icons.done_all
                    : Icons.done,
            size: 14,
            color: color,
          ),
        ],
      ],
    );
  }
}

/// A call record, shown centred in the conversation rather than as a bubble.
class CallLogTile extends StatelessWidget {
  const CallLogTile({super.key, required this.message, required this.myUid});

  final Message message;
  final String myUid;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final iCalled = message.senderId == myUid;
    final kind = message.isVideoCall ? 'video call' : 'voice call';
    final outcome = message.callOutcome ?? CallOutcome.missed;
    final duration = message.duration;

    final (IconData icon, String label, bool alert) = switch (outcome) {
      CallOutcome.completed => (
          message.isVideoCall ? Icons.videocam : Icons.call,
          '${iCalled ? 'Outgoing' : 'Incoming'} $kind'
              '${duration == null ? '' : ' (${Message.formatDuration(duration)})'}',
          false,
        ),
      CallOutcome.missed => (
          iCalled ? Icons.call_made : Icons.call_missed,
          iCalled ? 'No answer · $kind' : 'Missed $kind',
          !iCalled,
        ),
      CallOutcome.declined => (
          Icons.call_end,
          iCalled ? 'Declined · $kind' : 'You declined a $kind',
          false,
        ),
    };

    final time = message.sentAt == null
        ? ''
        : ' · ${DateFormat.jm().format(message.sentAt!)}';
    final color =
        alert ? theme.colorScheme.error : theme.colorScheme.onSurfaceVariant;

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Center(
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
          decoration: BoxDecoration(
            color: theme.colorScheme.surfaceContainerHighest
                .withValues(alpha: .6),
            borderRadius: BorderRadius.circular(20),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(icon, size: 16, color: color),
              const SizedBox(width: 8),
              Text(
                '$label$time',
                style: theme.textTheme.labelMedium?.copyWith(color: color),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
