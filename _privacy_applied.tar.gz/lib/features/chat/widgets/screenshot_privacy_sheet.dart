import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'package:couple_app/features/chat/providers/chat_providers.dart';

/// Bottom sheet from the chat menu with the shared "block screenshots of
/// our chat" switch, and what screenshot alerts can and can't do.
///
/// The switch reflects the couple document live, so it also moves when the
/// partner flips it.
class ScreenshotPrivacySheet extends ConsumerWidget {
  const ScreenshotPrivacySheet({
    super.key,
    required this.partnerName,
    required this.onChanged,
  });

  final String partnerName;

  /// Called with the new value when the switch is flipped.
  final ValueChanged<bool> onChanged;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);
    final blocked = ref.watch(blockScreenshotsProvider);

    return SafeArea(
      // Scrolls rather than overflowing with large text.
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(24, 0, 24, 8),
              child: Text('Screenshots', style: theme.textTheme.titleLarge),
            ),
            SwitchListTile(
              contentPadding: const EdgeInsets.symmetric(horizontal: 24),
              secondary: const Icon(Icons.screenshot_monitor_outlined),
              title: const Text('Block screenshots of our chat'),
              subtitle: Text(
                'On both phones, screenshots and screen recordings of the chat '
                'come out black, and it is hidden in recent apps. '
                '$partnerName will see that you changed this.',
              ),
              value: blocked,
              onChanged: onChanged,
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(24, 8, 24, 24),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Icon(
                    Icons.info_outline,
                    size: 18,
                    color: theme.colorScheme.onSurfaceVariant,
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      'When blocking is off, a screenshot of the chat tells the '
                      'other person. Only Android 14 and newer can detect '
                      'screenshots, so on older phones blocking is the sure '
                      'way to keep the chat private.',
                      style: theme.textTheme.bodySmall?.copyWith(
                        color: theme.colorScheme.onSurfaceVariant,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
