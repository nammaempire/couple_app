# Us — a private chat app for two

A Flutter app where two partners pair with an invite code and share a single
private conversation: text messages and photos, synced live.

**Built:** onboarding (welcome, email + Google sign-in, profile, create/join a
couple with code, QR or share sheet, setup checklist), real-time chat, photo
sending, voice and video calls, moods, daily question.

---

## What you must do before it runs

The app expects a Firebase project. Nothing in `lib/` needs editing — the setup
is all configuration.

### 1. Install the tooling

```bash
dart pub global activate flutterfire_cli
npm install -g firebase-tools
firebase login
```

### 2. Create a Firebase project

At <https://console.firebase.google.com>, create a project. Then enable:

- **Authentication → Sign-in method → Email/Password**
- **Firestore Database** (start in production mode; rules come from this repo)
- **Storage** (same)

### 3. Connect the app

From the project root:

```bash
flutterfire configure
```

This writes `lib/firebase_options.dart` and `android/app/google-services.json`.

`main.dart` already initialises Firebase with
`DefaultFirebaseOptions.currentPlatform`.

### 4. Add the Google Services Gradle plugin

In `android/settings.gradle.kts`, inside the `plugins { }` block:

```kotlin
id("com.google.gms.google-services") version "4.4.2" apply false
```

In `android/app/build.gradle.kts`, inside its `plugins { }` block:

```kotlin
id("com.google.gms.google-services")
```

### 5. Deploy the security rules

The rules in this repo restrict every message and photo to the two members of a
couple. Deploy them:

```bash
firebase deploy --only firestore:rules,storage:rules
```

You may need a `firebase.json` pointing at the files:

```json
{
  "firestore": { "rules": "firestore.rules" },
  "storage": { "rules": "storage.rules" }
}
```

### 6. Run

```bash
flutter pub get
flutter run
```

---

## Onboarding flow

`AuthGate` moves each person through these steps from Firestore state alone,
so no screen navigates to the next one:

1. **Welcome**: the promise, then *Get started* or *I already have an account*.
2. **Sign in**: Google, or email and password (with password reset).
3. **About you**: photo, name, optional nickname, optional birthday.
4. **Connect**: *Create our space* (optional couple name, start date and
   photo) or *I have an invite* (type the code or scan the QR).
5. **Invite**: the creator sees a QR code, the code and a *Share invite*
   button, and waits. The joiner sees who invited them and taps *Accept and
   connect*.
6. **Setup checklist**: anniversary, birthday, notification preferences and
   privacy. Every item is optional, and each one can be changed later from the
   Us tab.

Accounts created before onboarding existed skip steps 3 and 6 if they are
already paired.

## How pairing works

1. Partner A creates a space. In one batch this writes `couples/{id}`,
   `invites/{code}` and `coupleId` on A's profile.
2. Partner B looks the code up with a single `get` on `invites/{code}`.
   Invites can't be listed, so codes can't be enumerated.
3. B accepts in one transaction: adds themselves to `memberIds`, marks the
   invite `used`, and sets their own `coupleId`.

The security rules only allow step 3 when the couple has exactly one member
and the same write consumes that couple's unused invite. Couples can only be
read by their two members, and nobody can add a third person.

A waiting creator can cancel their space ("My partner already sent me a code")
to join the partner's invite instead.

### Google sign-in setup

1. Firebase console → **Authentication → Sign-in method** → enable **Google**.
2. Add your SHA-1 fingerprints under **Project settings → Your apps →
   Android** (debug: `cd android && ./gradlew signingReport`; also add the
   release keystore's SHA-1, and Play App Signing's if you publish).
3. Download the new `google-services.json` into `android/app/`. It must
   contain an `oauth_client` entry. Without one, the app shows "Google sign-in
   is not set up for this build yet".

## Data model

```
users/{uid}
  displayName, nickname, photoUrl, birthday, coupleId, email, createdAt,
  profileComplete, setupComplete, privacyReviewed,
  notificationPrefs: { messages, mood, dailyQuestion, dates, quietHours }

invites/{code}
  coupleId, createdBy, inviterName, inviterPhotoUrl, coupleName,
  used, usedBy, usedAt, createdAt

couples/{coupleId}
  inviteCode, memberIds[], createdAt, activatedAt, coupleName, photoUrl,
  lastMessagePreview, lastMessageAt, startDate, nextMeetup,
  nicknames: { <setterUid>: "what that person calls their partner" }

couples/{coupleId}/moods/{uid}
  mood, note, updatedAt

couples/{coupleId}/dailyQuestions/{yyyy-MM-dd}
  prompt, date, answers: { <uid>: { text, answeredAt } }

couples/{coupleId}/memories/{memoryId}
  title, caption, date, place, album, favorite, createdBy, createdAt,
  media: [ { type ("image" | "video"), url, thumbUrl, aspectRatio, durationMs } ]

couples/{coupleId}/events/{eventId}
  title, type ("dateNight" | "trip" | "anniversary" | "birthday" | "custom"),
  start, end, allDay, location, notes, budget, repeatYearly,
  private, reminder ("none" | "atTime" | "hour" | "day" | "week"), createdBy

couples/{coupleId}/notes/{noteId}                 (envelope, both can read)
  senderId, recipientId, kind ("letter" | "openWhen"), openWhen, title,
  deliverAt, createdAt, openedAt, hasVoice, voiceDurationMs
couples/{coupleId}/notes/{noteId}/sealed/content  (recipient only from deliverAt)
  body, voiceUrl, deliverAt, senderId, recipientId

couples/{coupleId}/nudges/{nudgeId}
  senderId, sentAt, kind ("thinking" | "love" | "miss" | "hug" | "kiss")

couples/{coupleId}/call/current
  callerId, calleeId, type ("voice" | "video"),
  status ("ringing" | "accepted" | "declined" | "ended" | "missed"),
  channelName, startedAt, answeredAt, endedAt

couples/{coupleId}/messages/{messageId}
  senderId, type ("text" | "image" | "video" | "voice" | "call"), text,
  imageUrl (photo or video thumbnail), imageAspectRatio, mediaUrl (video or
  voice), durationMs, sentAt, seen, reactions: { <uid>: emoji },
  replyTo: { messageId, senderId, type, text }, pinned, pinnedAt,
  callType ("voice" | "video"), callOutcome ("completed" | "missed" | "declined")
```

Either partner may update only `seen`, `reactions`, `pinned` and `pinnedAt`.
Message text and sender can never be edited.

Storage: `couples/{id}/photos/` (chat photos and video thumbnails),
`couples/{id}/videos/`, `couples/{id}/voice/`, `couples/{id}/memories/`,
`couples/{id}/notes/` (voice letters, readable directly only by the sender),
`couples/{id}/profile/`
(couple photo), `users/{uid}/profile/` (profile photo).

## Project layout

Feature-first: each feature keeps its own data (Firestore/Storage services),
models, screens and widgets. Shared pieces live in `core/`. Imports always
use `package:couple_app/...`.

```
lib/
  main.dart                 entry point: Firebase init, runApp
  app.dart                  MaterialApp, theme, AuthGate
  firebase_options.dart     generated by flutterfire (do not edit)
  core/
    config/                 Agora App ID
    theme/                  colour palette and Material 3 theme
    services/               Storage uploads, voice playback, voice recording
    media/                  full-screen photo viewer and video player
    utils/                  snack bars, duration formatting, input formatters
    widgets/                empty state, avatar picker, voice clip player, name dialog
  features/
    auth/                   sign-in, AuthGate (routes onboarding vs app), AppUser
    couple/                 Couple and Invite models, CoupleService (pairing)
    onboarding/             welcome, profile, pairing steps, invite, QR scan, checklist
    shell/                  MainShell: bottom tabs, incoming calls, reminders
    home/                   Home tab: counter, love taps, moods, daily question
    chat/                   chat, search, media gallery, bubbles, composer
    calls/                  Agora voice/video calls and call signalling
    memories/               albums, timeline, editor, recaps
    together/               calendar, love notes, local reminders
    us/                     Us tab: profile, couple settings, question archive
```

Inside a feature:

```
features/<name>/
  data/       services that talk to Firebase or the device
  models/     plain data classes with fromDoc / toMap
  screens/    full-page routes (StatefulWidgets hold the state)
  widgets/    pieces of those screens, stateless where possible
```

## Features

**Onboarding.** Email or Google sign-in, a profile step, pairing by code, QR
or share sheet, and a setup checklist (see *Onboarding flow*).

**Home**
- Couple header with the couple photo, or both partners' avatars
- Quick actions: message, voice call, video call, dates
- Days together, with years/months/days and the next milestone
- Send love: one-tap Thinking of you, Love you, Miss you, Hug and Kiss that
  buzz the partner's phone
- Coming up: countdowns to the anniversary, both birthdays and the next meetup
- Moods for both partners, each with an optional note
- Daily question that unlocks once both have answered, with a gentle streak
  (shown from 2 days)

**Chat**
- Text, photos, videos (up to 3 minutes and 100 MB, with thumbnails) and
  voice messages (tap the mic to record, tap send)
- Replies: swipe a message right, or long-press and choose Reply. Tap the
  quote to jump to the original
- Couple reactions: Love, Miss you, Hug, Kiss, Laugh (double-tap to heart)
- Pin messages; the latest pin shows under the app bar
- Search (on-device, over the latest 1,000 messages) with jump-to-message
- Photos & videos gallery, grouped by month
- Older messages load as you scroll up
- Delivered/seen ticks, marked seen only while the chat is on screen
- Call records in the conversation: completed (with duration), missed or
  declined
- Delete your own messages for both of you, with confirmation

**Calls.** Voice and video over Agora. Unanswered calls stop ringing after
45 seconds.

**Memories** (tab)
- A memory holds up to 20 photos and videos, with a title, caption, date,
  place and album
- Albums: First Date, Trips, Birthdays, Anniversaries, Random Moments, plus any
  you name
- Timeline grouped by month; favourites; search by title, caption, place or
  album; filter by album or date range
- "On this day" from earlier years, and an "Our Memories" recap for any month
  or year
- Share or save a memory's photos and videos through the phone's share sheet
- Either partner can edit a memory; only the person who added it can delete it

**Together** (tab)
- *Calendar*: month view with dots, day list and "Upcoming". Event types are
  date night, trip (multi-day), anniversary, birthday and other. Each event can
  have a time, location, notes, a ₹ budget, a yearly repeat and a reminder.
  *Private* events are visible only to their creator (enforced by the rules).
  Your anniversary, both birthdays and the next meetup appear automatically.
- *Love notes*: a letter delivered now or on a chosen date and time, or an
  "Open when…" envelope (miss me, bad day, can't sleep, need a smile,
  birthday, anniversary). An optional voice letter can be recorded. A
  scheduled note shows your partner a sealed envelope ("arrives in 3 days"),
  and the rules keep its words unreadable until then. The sender can unsend.

**Reminders.** Each phone schedules its own local notifications (no push
server needed): event reminders, the day before and the day of birthdays and
the anniversary, and when a love note arrives. They follow the notification
preferences, and quiet hours move late reminders to 21:30 the evening before.
They are re-planned whenever events change and each time the app opens, 60 days
ahead.

Home adds quick actions (Message, Memory, Event, Note), "Recent memories", and
calendar events and incoming notes in "Coming up".

Light and dark themes follow the system setting.

## Nicknames

Nicknames are one-directional on purpose. `nicknames` on the couple document is
keyed by the uid of the person who *set* the name, and the value is what that
person calls their partner. So you can call her "Bubu" while she calls you
"Chotu", and neither has to agree with the other's choice. Clearing a nickname
falls back to the partner's own display name.

Set both from the **Us** tab, under Names.

## Voice and video calls

Calling uses [Agora](https://console.agora.io) for the media and Firestore for
the signalling, so there is no call server to run.

### Setup

1. Sign up at <https://console.agora.io> and create a project.
2. Set its authentication mode to **Testing mode: APP ID**. This is what lets
   the app connect without a token server.
3. Copy the App ID.
4. Pass it at run or build time:

```bash
flutter run --dart-define=AGORA_APP_ID=your_app_id_here
flutter build apk --release --dart-define=AGORA_APP_ID=your_app_id_here
```

The `--dart-define` keeps the id out of version control. Without it the call
buttons explain that calling is not configured rather than failing obscurely.

The free tier is 10,000 minutes a month, which two people will not exhaust.
Video minutes count more heavily than voice.

### How it works

`couples/{coupleId}/call/current` is the signalling document. The caller writes
`status: ringing`; the callee's `MainShell` listener sees it and pushes the
incoming-call screen; accepting flips the status to `accepted` and both sides
join the same Agora channel. Either side writing `ended` closes both screens.

Channel names are random UUIDs generated per call, so testing mode's lack of
tokens is not a practical exposure — nobody can guess a live channel.

### The limitation

There are no push notifications yet, so **a call only rings if the other
person has the app open.** Android freezes background apps, so a closed app
will not ring. Fixing that needs FCM plus a Cloud Function to send the push on
call creation, which requires the Blaze plan. The call code itself would not
change — only the delivery of the ring.
