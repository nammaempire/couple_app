import 'package:flutter/material.dart';

import 'package:couple_app/core/config/agora_config.dart';
import 'package:couple_app/core/utils/snackbar.dart';
import 'package:couple_app/features/calls/data/call_service.dart';
import 'package:couple_app/features/calls/models/call_session.dart';
import 'package:couple_app/features/calls/screens/call_screen.dart';

/// Places a call and opens the outgoing call screen. Used by the chat app
/// bar. The partner's phone shows the incoming screen from its own
/// signalling listener in `MainShell`.
Future<void> placeCall(
  BuildContext context, {
  required String coupleId,
  required String myUid,
  required String? partnerUid,
  required String partnerName,
  required CallType type,
  CallService? callService,
}) async {
  if (!AgoraConfig.isConfigured) {
    context.showSnackMessage('Calling is not set up yet: no Agora App ID.');
    return;
  }
  if (partnerUid == null) {
    context.showSnackMessage('You need to be paired before you can call.');
    return;
  }

  final calls = callService ?? CallService();
  try {
    final session = await calls.startCall(
      coupleId: coupleId,
      callerId: myUid,
      calleeId: partnerUid,
      type: type,
    );
    if (!context.mounted) return;

    await Navigator.of(context).push(
      MaterialPageRoute(
        fullscreenDialog: true,
        builder: (_) => CallScreen(
          coupleId: coupleId,
          myUid: myUid,
          partnerName: partnerName,
          session: session,
          callService: calls,
          isOutgoing: true,
        ),
      ),
    );
  } catch (_) {
    if (!context.mounted) return;
    context.showSnackMessage('Could not start the call.');
  }
}
