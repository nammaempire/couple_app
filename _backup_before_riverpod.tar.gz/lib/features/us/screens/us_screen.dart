import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart';

import 'package:couple_app/core/utils/snackbar.dart';
import 'package:couple_app/core/widgets/name_edit_dialog.dart';
import 'package:couple_app/features/auth/data/auth_service.dart';
import 'package:couple_app/features/auth/models/app_user.dart';
import 'package:couple_app/features/couple/data/couple_service.dart';
import 'package:couple_app/features/couple/models/couple.dart';
import 'package:couple_app/features/home/data/daily_question_service.dart';
import 'package:couple_app/features/home/models/daily_question.dart';
import 'package:couple_app/features/onboarding/widgets/notification_prefs_sheet.dart';
import 'package:couple_app/features/onboarding/widgets/privacy_sheet.dart';
import 'package:couple_app/features/us/widgets/archived_answer.dart';
import 'package:couple_app/features/us/widgets/settings_section_header.dart';

/// Relationship settings and the archive of answered daily questions.
class UsScreen extends StatelessWidget {
  const UsScreen({
    super.key,
    required this.me,
    required this.couple,
    required this.partnerName,
    required this.authService,
    required this.coupleService,
    required this.questionService,
  });

  final AppUser me;
  final Couple couple;
  final String partnerName;
  final AuthService authService;
  final CoupleService coupleService;
  final DailyQuestionService questionService;

  String? get _partnerUid => couple.partnerIdFor(me.uid);

  Future<void> _editMyName(BuildContext context) async {
    final name = await showNameEditDialog(
      context: context,
      title: 'Your name',
      label: 'Name',
      initialValue: me.displayName,
      helperText: 'This is what your partner sees by default.',
    );
    if (name == null || name.isEmpty) return;
    await authService.updateDisplayName(name);
  }

  Future<void> _editPartnerNickname(BuildContext context) async {
    final nickname = await showNameEditDialog(
      context: context,
      title: 'What you call them',
      label: 'Nickname',
      initialValue: couple.nicknameChosenBy(me.uid),
      helperText:
          'Only changes what you see. They pick their own name for you.',
      allowEmpty: true,
    );
    if (nickname == null) return;
    await coupleService.setPartnerNickname(
      coupleId: couple.id,
      uid: me.uid,
      nickname: nickname,
    );
  }

  Future<void> _editCoupleName(BuildContext context) async {
    final name = await showNameEditDialog(
      context: context,
      title: 'Name your space',
      label: 'Couple name',
      initialValue: couple.coupleName,
      helperText: 'You both see this name.',
      allowEmpty: true,
    );
    if (name == null) return;
    await coupleService.setCoupleName(coupleId: couple.id, name: name);
  }

  Future<void> _editNotifications(BuildContext context) async {
    final prefs = await showNotificationPrefsSheet(
      context,
      me.notificationPrefs,
    );
    if (prefs == null) return;
    await authService.saveNotificationPrefs(prefs);
  }

  Future<void> _showPrivacy(BuildContext context) async {
    final ok = await showPrivacySheet(context);
    if (ok == true && !me.privacyReviewed) {
      await authService.markPrivacyReviewed();
    }
  }

  Future<void> _pickDate(
    BuildContext context, {
    required String helpText,
    required DateTime? initial,
    required DateTime firstDate,
    required DateTime lastDate,
    required Future<void> Function(DateTime?) onPicked,
  }) async {
    final picked = await showDatePicker(
      context: context,
      initialDate: initial ?? DateTime.now(),
      firstDate: firstDate,
      lastDate: lastDate,
      helpText: helpText,
    );
    if (picked == null) return;
    await onPicked(picked);
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final startDate = couple.startDate;
    final meetup = couple.nextMeetup;

    return Scaffold(
      appBar: AppBar(title: const Text('Us')),
      body: ListView(
        padding: const EdgeInsets.symmetric(vertical: 8),
        children: [
          const SettingsSectionHeader(label: 'Our dates'),

          ListTile(
            leading: const Icon(Icons.favorite_outline),
            title: const Text('The day we started'),
            subtitle: Text(
              startDate == null
                  ? 'Not set'
                  : DateFormat.yMMMMd().format(startDate),
            ),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => _pickDate(
              context,
              helpText: 'When did you two start?',
              initial: startDate,
              firstDate: DateTime(1970),
              lastDate: DateTime.now(),
              onPicked: (date) =>
                  coupleService.setStartDate(coupleId: couple.id, date: date),
            ),
          ),

          ListTile(
            leading: const Icon(Icons.flight_takeoff),
            title: const Text('Next time we meet'),
            subtitle: Text(
              meetup == null ? 'Not set' : DateFormat.yMMMMd().format(meetup),
            ),
            trailing: meetup == null
                ? const Icon(Icons.chevron_right)
                : IconButton(
                    icon: const Icon(Icons.clear),
                    tooltip: 'Clear',
                    onPressed: () => coupleService.setNextMeetup(
                      coupleId: couple.id,
                      date: null,
                    ),
                  ),
            onTap: () => _pickDate(
              context,
              helpText: 'When do you see each other next?',
              initial: meetup,
              firstDate: DateTime.now(),
              lastDate: DateTime.now().add(const Duration(days: 365 * 5)),
              onPicked: (date) =>
                  coupleService.setNextMeetup(coupleId: couple.id, date: date),
            ),
          ),

          const Divider(height: 32),
          const SettingsSectionHeader(label: 'Names'),

          ListTile(
            leading: const Icon(Icons.home_outlined),
            title: const Text('Our space'),
            subtitle: Text(couple.coupleName ?? 'Not named yet'),
            trailing: const Icon(Icons.edit_outlined),
            onTap: () => _editCoupleName(context),
          ),

          ListTile(
            leading: const Icon(Icons.favorite),
            title: const Text('What you call them'),
            subtitle: Text(couple.nicknameChosenBy(me.uid) ?? partnerName),
            trailing: const Icon(Icons.edit_outlined),
            enabled: couple.isComplete,
            onTap: () => _editPartnerNickname(context),
          ),

          ListTile(
            leading: const Icon(Icons.local_florist_outlined),
            title: const Text('What they call you'),
            subtitle: Text(
              _partnerUid == null
                  ? 'Not paired yet'
                  : couple.nicknameChosenBy(_partnerUid!) ??
                        'They haven\'t picked one',
            ),
          ),

          const Divider(height: 32),
          const SettingsSectionHeader(label: 'Answered questions'),

          StreamBuilder<List<DailyQuestionEntry>>(
            stream: questionService.watchHistory(couple.id),
            builder: (context, snapshot) {
              final history = snapshot.data ?? const <DailyQuestionEntry>[];
              if (history.isEmpty) {
                return Padding(
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 16),
                  child: Text(
                    'Once you both answer a daily question, it will be kept here.',
                    style: theme.textTheme.bodyMedium?.copyWith(
                      color: theme.colorScheme.onSurfaceVariant,
                    ),
                  ),
                );
              }

              final partnerUid = couple.partnerIdFor(me.uid);
              return Column(
                children: history.map((entry) {
                  return ExpansionTile(
                    title: Text(
                      entry.prompt,
                      style: theme.textTheme.bodyMedium,
                    ),
                    subtitle: Text(
                      entry.dateKey,
                      style: theme.textTheme.labelSmall,
                    ),
                    children: [
                      ArchivedAnswer(
                        label: 'You',
                        text: entry.answerFor(me.uid)?.text ?? '',
                      ),
                      ArchivedAnswer(
                        label: partnerName,
                        text: partnerUid == null
                            ? ''
                            : entry.answerFor(partnerUid)?.text ?? '',
                      ),
                    ],
                  );
                }).toList(),
              );
            },
          ),

          const Divider(height: 32),
          const SettingsSectionHeader(label: 'Account'),

          ListTile(
            leading: const Icon(Icons.person_outline),
            title: const Text('Your name'),
            subtitle: Text(me.displayName),
            trailing: const Icon(Icons.edit_outlined),
            onTap: () => _editMyName(context),
          ),

          ListTile(
            leading: const Icon(Icons.cake_outlined),
            title: const Text('Your birthday'),
            subtitle: Text(
              me.birthday == null
                  ? 'Not set'
                  : DateFormat.MMMMd().format(me.birthday!),
            ),
            trailing: const Icon(Icons.chevron_right),
            onTap: () {
              final now = DateTime.now();
              _pickDate(
                context,
                helpText: 'Your birthday',
                initial:
                    me.birthday ?? DateTime(now.year - 25, now.month, now.day),
                firstDate: DateTime(1920),
                lastDate: now,
                onPicked: authService.setBirthday,
              );
            },
          ),

          ListTile(
            leading: const Icon(Icons.notifications_none),
            title: const Text('Notifications'),
            subtitle: const Text('Choose what you hear about'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => _editNotifications(context),
          ),

          ListTile(
            leading: const Icon(Icons.shield_outlined),
            title: const Text('Privacy'),
            subtitle: const Text('Who can see what'),
            trailing: const Icon(Icons.chevron_right),
            onTap: () => _showPrivacy(context),
          ),

          ListTile(
            leading: const Icon(Icons.qr_code),
            title: const Text('Invite code'),
            subtitle: Text(couple.inviteCode),
            trailing: IconButton(
              icon: const Icon(Icons.copy),
              onPressed: () {
                Clipboard.setData(ClipboardData(text: couple.inviteCode));
                context.showSnackMessage('Code copied');
              },
            ),
          ),

          ListTile(
            leading: Icon(Icons.logout, color: theme.colorScheme.error),
            title: Text(
              'Sign out',
              style: TextStyle(color: theme.colorScheme.error),
            ),
            onTap: authService.signOut,
          ),

          const SizedBox(height: 24),
        ],
      ),
    );
  }
}
