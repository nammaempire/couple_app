import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

import 'package:couple_app/features/auth/data/auth_service.dart';
import 'package:couple_app/features/auth/models/app_user.dart';
import 'package:couple_app/features/auth/screens/sign_in_screen.dart';
import 'package:couple_app/features/couple/data/couple_service.dart';
import 'package:couple_app/features/couple/models/couple.dart';
import 'package:couple_app/features/onboarding/screens/invite_screen.dart';
import 'package:couple_app/features/onboarding/screens/pairing_screen.dart';
import 'package:couple_app/features/onboarding/screens/profile_setup_screen.dart';
import 'package:couple_app/features/onboarding/screens/setup_checklist_screen.dart';
import 'package:couple_app/features/onboarding/screens/welcome_screen.dart';
import 'package:couple_app/features/shell/main_shell.dart';

/// Routes the user through onboarding and into the app, driven entirely by
/// auth, profile and couple state:
///
///   signed out           → welcome → sign in / sign up
///   profile incomplete   → about you
///   no couple            → create or join
///   couple of one        → invite (waiting for partner)
///   setup not finished   → setup checklist
///   otherwise            → main app
///
/// Each step writes to Firestore and the streams move the user on, so no
/// screen needs to navigate to the next one.
class AuthGate extends StatelessWidget {
  const AuthGate({super.key, required this.authService});

  final AuthService authService;

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
      stream: authService.authStateChanges(),
      builder: (context, authSnap) {
        if (authSnap.connectionState == ConnectionState.waiting) {
          return const _Splash();
        }

        final user = authSnap.data;
        if (user == null) {
          return _SignedOutFlow(authService: authService);
        }

        return StreamBuilder<AppUser?>(
          key: ValueKey(user.uid),
          stream: authService.watchProfile(user.uid),
          builder: (context, profileSnap) {
            if (profileSnap.connectionState == ConnectionState.waiting) {
              return const _Splash();
            }

            final profile = profileSnap.data;
            if (profile == null || !profile.profileComplete) {
              return ProfileSetupScreen(
                authService: authService,
                uid: user.uid,
                profile: profile,
              );
            }

            final coupleId = profile.coupleId;
            if (coupleId == null) {
              return PairingScreen(
                authService: authService,
                uid: user.uid,
                me: profile,
              );
            }

            return _CoupleGate(
              key: ValueKey(coupleId),
              authService: authService,
              me: profile,
              coupleId: coupleId,
            );
          },
        );
      },
    );
  }
}

/// Welcome screen, then the sign-in form, without pushing routes.
class _SignedOutFlow extends StatefulWidget {
  const _SignedOutFlow({required this.authService});

  final AuthService authService;

  @override
  State<_SignedOutFlow> createState() => _SignedOutFlowState();
}

class _SignedOutFlowState extends State<_SignedOutFlow> {
  /// null while on the welcome screen; otherwise which form to open.
  bool? _signUp;

  @override
  Widget build(BuildContext context) {
    final signUp = _signUp;

    return PopScope(
      canPop: signUp == null,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop) setState(() => _signUp = null);
      },
      child: AnimatedSwitcher(
        duration: const Duration(milliseconds: 250),
        child: signUp == null
            ? WelcomeScreen(
                key: const ValueKey('welcome'),
                onGetStarted: () => setState(() => _signUp = true),
                onSignIn: () => setState(() => _signUp = false),
              )
            : SignInScreen(
                key: const ValueKey('sign-in'),
                authService: widget.authService,
                initialSignUp: signUp,
                onBack: () => setState(() => _signUp = null),
              ),
      ),
    );
  }
}

/// Decides between the invite screen, the setup checklist and the app once
/// the user belongs to a couple.
class _CoupleGate extends StatefulWidget {
  const _CoupleGate({
    super.key,
    required this.authService,
    required this.me,
    required this.coupleId,
  });

  final AuthService authService;
  final AppUser me;
  final String coupleId;

  @override
  State<_CoupleGate> createState() => _CoupleGateState();
}

class _CoupleGateState extends State<_CoupleGate> {
  final _couples = CoupleService();
  late final Stream<Couple?> _coupleStream = _couples.watchCouple(
    widget.coupleId,
  );

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<Couple?>(
      stream: _coupleStream,
      builder: (context, snap) {
        // A couple that was deleted, or one this user is no longer a member
        // of, is unreadable under the rules. Either way they need a new one.
        final gone =
            snap.hasError ||
            (snap.hasData && snap.data == null) ||
            (snap.data != null &&
                !snap.data!.memberIds.contains(widget.me.uid));
        if (gone) {
          return PairingScreen(
            authService: widget.authService,
            uid: widget.me.uid,
            me: widget.me,
            notice:
                'Your previous space is no longer available. Create a new '
                'one or join your partner.',
          );
        }

        final couple = snap.data;
        if (couple == null) return const _Splash();

        if (!couple.isComplete) {
          return InviteScreen(
            authService: widget.authService,
            me: widget.me,
            couple: couple,
            coupleService: _couples,
          );
        }

        if (!widget.me.setupComplete) {
          return SetupChecklistScreen(
            authService: widget.authService,
            me: widget.me,
            couple: couple,
            coupleService: _couples,
          );
        }

        return MainShell(
          authService: widget.authService,
          me: widget.me,
          coupleId: widget.coupleId,
        );
      },
    );
  }
}

class _Splash extends StatelessWidget {
  const _Splash();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              Icons.favorite,
              size: 56,
              color: Theme.of(context).colorScheme.primary,
            ),
            const SizedBox(height: 24),
            const SizedBox(
              width: 24,
              height: 24,
              child: CircularProgressIndicator(strokeWidth: 2),
            ),
          ],
        ),
      ),
    );
  }
}
