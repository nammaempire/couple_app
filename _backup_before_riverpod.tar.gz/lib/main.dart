import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/widgets.dart';

import 'package:couple_app/app.dart';
import 'package:couple_app/firebase_options.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  runApp(const CoupleApp());
}
